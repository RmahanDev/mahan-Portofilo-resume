<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;
delete_option( 'shainika_sms_settings' );
delete_option( 'shainika_sms_db_version' );
delete_transient( 'shainika_sms_test_codes' );
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'shainika_sms_otp' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
wp_clear_scheduled_hook( 'shainika_sms_cleanup' );
// User accounts and their meta (mobile numbers) are intentionally kept.
