<?php
/**
 * Replaces woocommerce/myaccount/form-login.php for logged-out visitors
 * (when "My account" is set to "replace").
 *
 * Themes can override it by copying this file to:
 * yourtheme/shainika-sms-auth/form-login.php
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_customer_login_form' );
?>
<div class="ssa-account">
	<?php echo Shainika_SMS_Frontend::card( '', null, 'account' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
</div>
<?php
do_action( 'woocommerce_after_customer_login_form' );
