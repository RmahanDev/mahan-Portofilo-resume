<?php
/**
 * Plugin Name:       Shainika SMS Auth
 * Description:       ورود و ثبت‌نام با کد یک‌بارمصرف پیامکی برای هر سایت وردپرسی؛ سازگار با ووکامرس، صفحه‌ی ورود وردپرس، شورت‌کد و پاپ‌آپ. پشتیبانی از ملی‌پیامک، کاوه‌نگار، sms.ir، IPPanel (فراز اس‌ام‌اس) و قاصدک.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            ماهان رضائی (Mahan Rezaei)
 * Author URI:        https://co.shainika.com
 * Plugin URI:        https://co.shainika.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       shainika-sms-auth
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SHAINIKA_SMS_VERSION', '1.0.0' );
define( 'SHAINIKA_SMS_FILE', __FILE__ );
define( 'SHAINIKA_SMS_DIR', plugin_dir_path( __FILE__ ) );
define( 'SHAINIKA_SMS_URL', plugin_dir_url( __FILE__ ) );

foreach ( array( 'settings', 'db', 'providers', 'otp', 'fields', 'users', 'ajax', 'frontend', 'admin' ) as $shainika_sms_file ) {
	require_once SHAINIKA_SMS_DIR . 'includes/' . $shainika_sms_file . '.php';
}
unset( $shainika_sms_file );

register_activation_hook( __FILE__, array( 'Shainika_SMS_DB', 'install' ) );
register_deactivation_hook( __FILE__, array( 'Shainika_SMS_DB', 'deactivate' ) );

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', SHAINIKA_SMS_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', SHAINIKA_SMS_FILE, true );
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		Shainika_SMS_DB::maybe_upgrade();
		Shainika_SMS_Ajax::init();
		Shainika_SMS_Frontend::init();
		Shainika_SMS_Users::init();
		Shainika_SMS_Admin::init();
	}
);

/** True when WooCommerce is active. */
function shainika_sms_has_wc() {
	return class_exists( 'WooCommerce' );
}
