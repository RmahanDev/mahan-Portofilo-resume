<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shainika_SMS_Ajax {

	const NONCE_ACTION = 'shainika_sms';

	public static function init() {
		$map = array(
			'init'     => 'init_form',
			'send'     => 'send',
			'verify'   => 'verify',
			'register' => 'register',
			'reverse'  => 'reverse',
		);
		foreach ( $map as $action => $method ) {
			add_action( 'wp_ajax_nopriv_shainika_sms_' . $action, array( __CLASS__, $method ) );
			add_action( 'wp_ajax_shainika_sms_' . $action, array( __CLASS__, $method ) );
		}
	}

	/* ---------- helpers ---------- */

	private static function fail( $code, $message, $extra = array(), $status = 400 ) {
		nocache_headers();
		wp_send_json_error( array_merge( array( 'code' => $code, 'message' => $message ), $extra ), $status );
	}

	private static function ok( $data = array() ) {
		nocache_headers();
		wp_send_json_success( $data );
	}

	public static function post( $key ) {
		return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
	}

	/** Form token: "<timestamp>.<hmac>". It proves the form was loaded by a real page view a few seconds ago. */
	private static function make_form_token() {
		$ts = time();
		return $ts . '.' . hash_hmac( 'sha256', 'ft|' . $ts, wp_salt( 'nonce' ) );
	}

	private static function form_token_age( $token ) {
		$parts = explode( '.', (string) $token );
		if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) ) {
			return false;
		}
		if ( ! hash_equals( hash_hmac( 'sha256', 'ft|' . $parts[0], wp_salt( 'nonce' ) ), $parts[1] ) ) {
			return false;
		}
		return time() - (int) $parts[0];
	}

	private static function guard() {
		// Requests sent by another website (e.g. a hidden form that logs a visitor into someone else's account) are refused.
		if ( isset( $_SERVER['HTTP_SEC_FETCH_SITE'] ) && 'cross-site' === $_SERVER['HTTP_SEC_FETCH_SITE'] ) {
			self::fail( 'cross_site', 'درخواست نامعتبر است.', array(), 403 );
		}
		if ( is_user_logged_in() ) {
			self::fail( 'logged_in', 'شما قبلاً وارد شده‌اید.', array( 'reload' => true ) );
		}
		if ( ! wp_verify_nonce( self::post( 'nonce' ), self::NONCE_ACTION ) ) {
			self::fail( 'bad_nonce', 'نشست صفحه منقضی شده است. صفحه را دوباره بارگذاری کنید.', array( 'reload' => true ), 403 );
		}
	}

	private static function redirect_url() {
		$wanted = esc_url_raw( self::post( 'redirect' ) );
		$wanted = $wanted ? wp_validate_redirect( $wanted, '' ) : '';
		// Never send a fresh login back to the login/logout screen itself.
		if ( $wanted && false !== strpos( $wanted, 'wp-login.php' ) ) {
			$wanted = '';
		}
		if ( ! $wanted ) {
			$fixed  = Shainika_SMS_Settings::get( 'redirect_after' );
			$wanted = $fixed ? $fixed : ( shainika_sms_has_wc() ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' ) );
		}
		return (string) apply_filters( 'shainika_sms_redirect', $wanted );
	}

	/** Logs a found account in, or fails with a message. Never returns on success. */
	private static function login_existing( $user_id, $phone ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user || ! Shainika_SMS_Users::can_sms_login( $user ) ) {
			self::fail( 'role_blocked', 'ورود پیامکی برای این حساب مجاز نیست. با نام کاربری و رمز عبور وارد شوید.', array(), 403 );
		}
		Shainika_SMS_Users::login( $user_id, $phone );
		self::ok( array( 'status' => 'logged_in', 'redirect' => self::redirect_url() ) );
	}

	private static function create_and_login( $phone, $data, $token = '' ) {
		$user_id = Shainika_SMS_Users::create( $phone, $data );
		if ( is_wp_error( $user_id ) ) {
			error_log( '[shainika-sms] user create failed: ' . $user_id->get_error_message() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
			self::fail( 'create_failed', 'ساخت حساب با مشکل روبه‌رو شد. دوباره تلاش کنید.', array(), 500 );
		}
		if ( $token ) {
			delete_transient( 'shainika_sms_reg_' . $token );
		}
		Shainika_SMS_Users::login( $user_id );
		self::ok( array( 'status' => 'logged_in', 'redirect' => self::redirect_url() ) );
	}

	/* ---------- actions ---------- */

	/** Fresh nonce + form token. Fetched by JS so full-page caching cannot serve a stale nonce. */
	public static function init_form() {
		if ( is_user_logged_in() ) {
			self::ok( array( 'logged_in' => true ) );
		}
		self::ok(
			array(
				'logged_in' => false,
				'nonce'     => wp_create_nonce( self::NONCE_ACTION ),
				'ft'        => self::make_form_token(),
			)
		);
	}

	public static function send() {
		self::guard();

		// Honeypot: real users never fill this hidden field. Bots get a fake success.
		if ( '' !== trim( (string) self::post( 'website' ) ) ) {
			self::ok( array( 'ttl' => 120, 'cooldown' => 60, 'length' => (int) Shainika_SMS_Settings::get( 'code_length' ) ) );
		}

		$age = self::form_token_age( self::post( 'ft' ) );
		if ( false === $age || $age < 2 || $age > 3 * HOUR_IN_SECONDS ) {
			self::fail( 'bad_token', 'درخواست معتبر نبود. صفحه را دوباره بارگذاری کنید.', array( 'reload' => true ) );
		}

		$phone = Shainika_SMS_OTP::normalize_phone( self::post( 'phone' ) );
		if ( ! $phone ) {
			self::fail( 'bad_phone', 'شماره موبایل معتبر نیست. نمونه: 09123456789' );
		}

		// Login-only mode: do not spend SMS credit on numbers that have no account.
		if ( ! Shainika_SMS_Settings::get( 'registration' ) && 0 === Shainika_SMS_Users::find_by_phone( $phone ) ) {
			self::fail( 'no_account', 'حسابی با این شماره پیدا نشد.', array(), 404 );
		}

		$result = Shainika_SMS_OTP::request( $phone, Shainika_SMS_OTP::client_ip() );
		if ( is_wp_error( $result ) ) {
			self::fail( $result->get_error_code(), $result->get_error_message(), (array) $result->get_error_data(), 429 );
		}
		// When registration is open, the answer is identical for registered and new numbers.
		self::ok( $result );
	}

	public static function verify() {
		self::guard();

		$phone = Shainika_SMS_OTP::normalize_phone( self::post( 'phone' ) );
		$code  = Shainika_SMS_OTP::latin_digits( self::post( 'code' ) );
		$len   = (int) Shainika_SMS_Settings::get( 'code_length' );
		if ( ! $phone || ! preg_match( '/^\d{' . $len . '}$/', $code ) ) {
			self::fail( 'bad_code', sprintf( 'کد %d رقمی را کامل وارد کنید.', $len ) );
		}

		$ok = Shainika_SMS_OTP::verify( $phone, $code );
		if ( is_wp_error( $ok ) ) {
			self::fail( $ok->get_error_code(), $ok->get_error_message(), (array) $ok->get_error_data(), 401 );
		}

		$user_id = Shainika_SMS_Users::find_by_phone( $phone );
		if ( is_wp_error( $user_id ) ) {
			self::fail( $user_id->get_error_code(), $user_id->get_error_message(), array(), 409 );
		}
		if ( $user_id ) {
			self::login_existing( $user_id, $phone );
		}

		if ( ! Shainika_SMS_Settings::get( 'registration' ) ) {
			self::fail( 'no_account', 'حسابی با این شماره پیدا نشد.', array(), 404 );
		}

		// No profile fields are asked: the account is created right away.
		if ( ! Shainika_SMS_Fields::enabled() ) {
			self::create_and_login( $phone, array() );
		}

		// Otherwise hand out a one-use registration token bound to this phone (15 minutes).
		$token = bin2hex( random_bytes( 20 ) );
		set_transient( 'shainika_sms_reg_' . $token, array( 'phone' => $phone ), 15 * MINUTE_IN_SECONDS );
		self::ok( array( 'status' => 'register', 'token' => $token ) );
	}

	public static function register() {
		self::guard();

		$token = preg_replace( '/[^a-f0-9]/', '', (string) self::post( 'token' ) );
		$data  = $token ? get_transient( 'shainika_sms_reg_' . $token ) : false;
		if ( ! is_array( $data ) || empty( $data['phone'] ) ) {
			self::fail( 'bad_token', 'زمان تکمیل ثبت‌نام تمام شده است. دوباره با کد پیامکی وارد شوید.', array( 'restart' => true ), 401 );
		}
		$phone = $data['phone'];

		list( $profile, $errors ) = Shainika_SMS_Fields::validate( array( __CLASS__, 'post' ) );
		if ( $errors ) {
			self::fail( 'validation', 'لطفاً خطاهای فرم را اصلاح کنید.', array( 'fields' => $errors ), 422 );
		}

		// Race guard: the number may have been registered in the meantime.
		if ( Shainika_SMS_Users::find_by_phone( $phone ) ) {
			delete_transient( 'shainika_sms_reg_' . $token );
			self::fail( 'exists', 'این شماره قبلاً ثبت شده است. دوباره با کد پیامکی وارد شوید.', array( 'restart' => true ), 409 );
		}

		self::create_and_login( $phone, $profile, $token );
	}

	/** Optional: turns the picked map point into a text address using Neshan's reverse-geocoding service key. */
	public static function reverse() {
		self::guard();

		$token = preg_replace( '/[^a-f0-9]/', '', (string) self::post( 'token' ) );
		$data  = $token ? get_transient( 'shainika_sms_reg_' . $token ) : false;
		$key   = Shainika_SMS_Settings::get( 'neshan_service_key' );
		if ( ! is_array( $data ) || ! $key ) {
			self::fail( 'unavailable', '', array(), 403 );
		}

		// At most 30 lookups per registration token.
		$counter = 'shainika_sms_rev_' . $token;
		$used    = (int) get_transient( $counter );
		if ( $used >= 30 ) {
			self::fail( 'limit', '', array(), 429 );
		}
		set_transient( $counter, $used + 1, 15 * MINUTE_IN_SECONDS );

		$lat = (float) self::post( 'lat' );
		$lng = (float) self::post( 'lng' );
		$res = wp_remote_get(
			add_query_arg( array( 'lat' => $lat, 'lng' => $lng ), 'https://api.neshan.org/v5/reverse' ),
			array( 'timeout' => 8, 'headers' => array( 'Api-Key' => $key ) )
		);
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			self::fail( 'unavailable', '', array(), 502 );
		}
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $body ) || empty( $body['formatted_address'] ) ) {
			self::fail( 'unavailable', '', array(), 502 );
		}
		self::ok( array( 'address' => sanitize_text_field( $body['formatted_address'] ) ) );
	}
}
