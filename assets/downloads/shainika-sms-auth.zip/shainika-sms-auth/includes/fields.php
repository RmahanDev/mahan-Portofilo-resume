<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Registration-step fields: each one can be off, optional or required. */
class Shainika_SMS_Fields {

	public static function labels() {
		return array(
			'first_name' => 'نام',
			'last_name'  => 'نام خانوادگی',
			'email'      => 'ایمیل',
			'phone2'     => 'شماره تماس دوم',
			'address'    => 'آدرس کامل',
			'postcode'   => 'کد پستی',
			'map'        => 'موقعیت روی نقشه (نشان)',
		);
	}

	/** off | optional | required. The map is off while no Neshan key is set. */
	public static function state( $key ) {
		$fields = (array) Shainika_SMS_Settings::get( 'fields' );
		$state  = isset( $fields[ $key ] ) ? $fields[ $key ] : 'off';
		if ( 'map' === $key && ! Shainika_SMS_Settings::get( 'neshan_map_key' ) ) {
			$state = 'off';
		}
		return in_array( $state, Shainika_SMS_Settings::FIELD_STATES, true ) ? $state : 'off';
	}

	/** @return array key => optional|required, only the fields that are shown. */
	public static function enabled() {
		$out = array();
		foreach ( array_keys( self::labels() ) as $key ) {
			$state = self::state( $key );
			if ( 'off' !== $state ) {
				$out[ $key ] = $state;
			}
		}
		return $out;
	}

	/**
	 * Validates the submitted profile.
	 *
	 * @param callable $get Returns the raw (unslashed) value for a key.
	 * @return array{0:array,1:array} array( data, errors )
	 */
	public static function validate( $get ) {
		$enabled = self::enabled();
		$data    = array(
			'first_name' => '',
			'last_name'  => '',
			'email'      => '',
			'phone2'     => '',
			'address'    => '',
			'postcode'   => '',
			'lat'        => '',
			'lng'        => '',
		);
		$errors = array();
		$req    = function ( $key ) use ( $enabled ) {
			return isset( $enabled[ $key ] ) && 'required' === $enabled[ $key ];
		};

		if ( isset( $enabled['first_name'] ) ) {
			$v = trim( sanitize_text_field( call_user_func( $get, 'first_name' ) ) );
			if ( ( '' !== $v || $req( 'first_name' ) ) && ( mb_strlen( $v ) < 2 || mb_strlen( $v ) > 40 ) ) {
				$errors['first_name'] = 'نام را وارد کنید (۲ تا ۴۰ نویسه).';
			}
			$data['first_name'] = $v;
		}

		if ( isset( $enabled['last_name'] ) ) {
			$v = trim( sanitize_text_field( call_user_func( $get, 'last_name' ) ) );
			if ( ( '' !== $v || $req( 'last_name' ) ) && ( mb_strlen( $v ) < 2 || mb_strlen( $v ) > 60 ) ) {
				$errors['last_name'] = 'نام خانوادگی را وارد کنید (۲ تا ۶۰ نویسه).';
			}
			$data['last_name'] = $v;
		}

		if ( isset( $enabled['email'] ) ) {
			$v = trim( sanitize_email( Shainika_SMS_OTP::latin_digits( call_user_func( $get, 'email' ) ) ) );
			if ( '' === $v ) {
				if ( $req( 'email' ) ) {
					$errors['email'] = 'ایمیل را وارد کنید.';
				}
			} elseif ( ! is_email( $v ) ) {
				$errors['email'] = 'ایمیل معتبر نیست.';
			} elseif ( email_exists( $v ) ) {
				$errors['email'] = 'این ایمیل متعلق به حساب دیگری است. ایمیل دیگری وارد کنید' . ( $req( 'email' ) ? '.' : ' یا خالی بگذارید.' );
			}
			$data['email'] = $v;
		}

		if ( isset( $enabled['phone2'] ) ) {
			$v = preg_replace( '/[\s\-]/', '', Shainika_SMS_OTP::latin_digits( call_user_func( $get, 'phone2' ) ) );
			if ( ( '' !== $v || $req( 'phone2' ) ) && ! preg_match( '/^0\d{10}$/', $v ) ) {
				$errors['phone2'] = 'شماره تماس دوم را ۱۱ رقمی و با صفر وارد کنید (ثابت با کد شهر، یا موبایل).';
			}
			$data['phone2'] = $v;
		}

		if ( isset( $enabled['address'] ) ) {
			$v = trim( sanitize_textarea_field( call_user_func( $get, 'address' ) ) );
			if ( ( '' !== $v || $req( 'address' ) ) && ( mb_strlen( $v ) < 10 || mb_strlen( $v ) > 300 ) ) {
				$errors['address'] = 'آدرس را کامل وارد کنید (۱۰ تا ۳۰۰ نویسه).';
			}
			$data['address'] = $v;
		}

		if ( isset( $enabled['postcode'] ) ) {
			$v = preg_replace( '/[\s\-]/', '', Shainika_SMS_OTP::latin_digits( call_user_func( $get, 'postcode' ) ) );
			if ( ( '' !== $v || $req( 'postcode' ) ) && ! preg_match( '/^\d{10}$/', $v ) ) {
				$errors['postcode'] = 'کد پستی باید ۱۰ رقم باشد.';
			}
			$data['postcode'] = $v;
		}

		if ( isset( $enabled['map'] ) ) {
			$lat       = call_user_func( $get, 'lat' );
			$lng       = call_user_func( $get, 'lng' );
			$has_point = '' !== $lat && '' !== $lng && is_numeric( $lat ) && is_numeric( $lng );
			if ( $has_point ) {
				$lat = round( (float) $lat, 6 );
				$lng = round( (float) $lng, 6 );
				// Neshan only covers Iran: reject points outside its rough bounding box.
				if ( $lat < 24 || $lat > 40.5 || $lng < 43.5 || $lng > 64 ) {
					$has_point = false;
				}
			}
			if ( $has_point ) {
				$data['lat'] = (string) $lat;
				$data['lng'] = (string) $lng;
			} elseif ( $req( 'map' ) && '1' !== (string) call_user_func( $get, 'map_unavailable' ) ) {
				// (A visitor whose browser could not load the map sends map_unavailable=1 and may continue without a point.)
				$errors['map'] = 'موقعیت خود را روی نقشه مشخص کنید.';
			}
		}

		$data   = apply_filters( 'shainika_sms_profile_data', $data, $get );
		$errors = apply_filters( 'shainika_sms_profile_errors', $errors, $data );
		return array( $data, $errors );
	}
}
