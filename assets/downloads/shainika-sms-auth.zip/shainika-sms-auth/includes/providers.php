<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base class for SMS providers.
 *
 * Add your own provider:
 *
 *   add_filter( 'shainika_sms_providers', function ( $providers ) {
 *       $providers[] = new My_Provider(); // extends Shainika_SMS_Provider
 *       return $providers;
 *   } );
 */
abstract class Shainika_SMS_Provider {

	/** Unique id, lowercase letters, digits and underscore. */
	abstract public function id();

	/** Name shown in the settings. */
	abstract public function label();

	/**
	 * Settings fields: key => array(
	 *   'label'       => string,
	 *   'desc'        => string (HTML allowed),
	 *   'secret'      => bool   (password input, kept when left empty),
	 *   'required'    => bool,
	 *   'default'     => string,
	 *   'placeholder' => string,
	 * )
	 */
	abstract public function fields();

	/**
	 * Sends one OTP.
	 *
	 * @param string $phone Normalized mobile, 09xxxxxxxxx.
	 * @param string $code  The code.
	 * @param array  $creds Field values (defaults applied).
	 * @return array{ok:bool,ref:string,error:string,message:string}
	 */
	abstract public function send( $phone, $code, array $creds );

	/** Admin-only help about creating the pattern/template in the provider panel. */
	public function help() {
		return '';
	}

	/** Known provider error codes => admin-facing explanation. */
	protected function error_labels() {
		return array();
	}

	public function error_label( $code, $message = '' ) {
		$labels = $this->error_labels();
		if ( isset( $labels[ (string) $code ] ) ) {
			return $labels[ (string) $code ];
		}
		if ( 'connection' === $code ) {
			return 'اتصال به سرور سرویس پیامک برقرار نشد' . ( $message ? ' (' . $message . ')' : '' ) . '.';
		}
		if ( '' !== (string) $message ) {
			return $message . ( '' !== (string) $code ? ' (کد ' . $code . ')' : '' );
		}
		return 'خطای ناشناخته از ' . $this->label() . ( '' !== (string) $code ? ' (کد ' . $code . ')' : '' );
	}

	public function is_configured( array $creds ) {
		foreach ( $this->fields() as $key => $field ) {
			if ( ! empty( $field['required'] ) && ( ! isset( $creds[ $key ] ) || '' === trim( (string) $creds[ $key ] ) ) ) {
				return false;
			}
		}
		return true;
	}

	/* ---------- helpers for implementations ---------- */

	protected static function ok( $ref ) {
		return array( 'ok' => true, 'ref' => substr( (string) $ref, 0, 64 ), 'error' => '', 'message' => '' );
	}

	protected static function fail( $error, $message = '' ) {
		return array( 'ok' => false, 'ref' => '', 'error' => (string) $error, 'message' => (string) $message );
	}

	/** 09121234567 -> +989121234567 */
	protected static function intl( $phone ) {
		return '+98' . substr( $phone, 1 );
	}

	/**
	 * POST helper.
	 *
	 * @param string       $url     Endpoint.
	 * @param array|string $body    Array = form fields, string = raw (JSON) body.
	 * @param array        $headers Extra headers.
	 * @return array{status:int,json:mixed,error:string}
	 */
	protected static function post( $url, $body, array $headers = array() ) {
		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 15,
				'headers' => array_merge( array( 'Accept' => 'application/json' ), $headers ),
				'body'    => $body,
			)
		);
		if ( is_wp_error( $response ) ) {
			return array( 'status' => 0, 'json' => null, 'error' => $response->get_error_message() );
		}
		return array(
			'status' => (int) wp_remote_retrieve_response_code( $response ),
			'json'   => json_decode( wp_remote_retrieve_body( $response ), true ),
			'error'  => '',
		);
	}

	protected static function post_json( $url, array $data, array $headers = array() ) {
		return self::post( $url, wp_json_encode( $data ), array_merge( array( 'Content-Type' => 'application/json' ), $headers ) );
	}
}

/**
 * Melipayamak (ملی‌پیامک) – shared service line with an approved pattern.
 * POST https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber
 */
class Shainika_SMS_Provider_Melipayamak extends Shainika_SMS_Provider {

	public function id() {
		return 'melipayamak';
	}

	public function label() {
		return 'ملی‌پیامک (خط خدماتی اشتراکی)';
	}

	public function fields() {
		return array(
			'username' => array( 'label' => 'نام کاربری پنل', 'required' => true ),
			'password' => array(
				'label'    => 'APIKey یا رمز پنل',
				'secret'   => true,
				'required' => true,
				'desc'     => 'پنل ← توسعه‌دهندگان ← تنظیمات وب‌سرویس.',
			),
			'body_id'  => array(
				'label'       => 'کد الگو (bodyId)',
				'required'    => true,
				'placeholder' => '123456',
				'desc'        => 'کد عددی الگوی تاییدشده در «خط خدماتی اشتراکی».',
			),
			'text'     => array(
				'label'   => 'مقدار پارامتر text',
				'default' => '{code}',
				'desc'    => 'متغیرهای الگو به ترتیب و با <code>;</code> جدا می‌شوند. الگوی تک‌متغیره: <code>{code}</code>. دومتغیره: <code>{code};{site}</code>.',
			),
		);
	}

	public function help() {
		return 'در «خط خدماتی اشتراکی ← درج پترن» یک الگو با یک متغیر بسازید، مثلاً: <code>کد ورود شما به ' . esc_html( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ) . ': {0}</code>. متن و متغیرها نباید لینک داشته باشند (خطای ۱۰-).';
	}

	protected function error_labels() {
		return array(
			'-1'  => 'دسترسی به وب‌سرویس خدماتی در پنل غیرفعال است.',
			'-2'  => 'در هر ارسال فقط یک شماره مجاز است.',
			'-3'  => 'خط ارسالی در سیستم تعریف نشده است.',
			'-4'  => 'کد الگو (bodyId) اشتباه است یا هنوز تایید نشده.',
			'-5'  => 'تعداد متغیرهای ارسالی با {} های متن الگو یکی نیست.',
			'-7'  => 'خطا در شماره‌ی فرستنده.',
			'-10' => 'در متغیرهای ارسالی لینک وجود دارد.',
			'0'   => 'نام کاربری یا رمز/APIKey نادرست است.',
		);
	}

	public function is_configured( array $creds ) {
		return parent::is_configured( $creds ) && preg_match( '/^\d+$/', (string) $creds['body_id'] );
	}

	public function send( $phone, $code, array $creds ) {
		$res = self::post(
			'https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber',
			array(
				'username' => $creds['username'],
				'password' => $creds['password'],
				'text'     => Shainika_SMS_Sender::fill( $creds['text'] ? $creds['text'] : '{code}', $code ),
				'to'       => $phone,
				'bodyId'   => $creds['body_id'],
			)
		);
		if ( $res['error'] ) {
			return self::fail( 'connection', $res['error'] );
		}
		$value = is_array( $res['json'] ) && isset( $res['json']['Value'] ) ? trim( (string) $res['json']['Value'] ) : '';
		// Success returns a long numeric recId; failures return short codes such as -4.
		if ( preg_match( '/^\d{6,}$/', $value ) ) {
			return self::ok( $value );
		}
		$msg = is_array( $res['json'] ) && ! empty( $res['json']['StrRetStatus'] ) ? (string) $res['json']['StrRetStatus'] : '';
		return self::fail( '' !== $value ? $value : (string) $res['status'], $msg );
	}
}

/**
 * Kavenegar (کاوه‌نگار) – Verify Lookup.
 * POST https://api.kavenegar.com/v1/{API-KEY}/verify/lookup.json  (receptor, token, template)
 */
class Shainika_SMS_Provider_Kavenegar extends Shainika_SMS_Provider {

	public function id() {
		return 'kavenegar';
	}

	public function label() {
		return 'کاوه‌نگار (Verify Lookup)';
	}

	public function fields() {
		return array(
			'api_key'  => array( 'label' => 'API Key', 'secret' => true, 'required' => true, 'desc' => 'پنل کاوه‌نگار ← تنظیمات ← API Key.' ),
			'template' => array( 'label' => 'نام الگو (template)', 'required' => true, 'placeholder' => 'verify', 'desc' => 'نام قالب تاییدشده در بخش «سرویس تایید».' ),
		);
	}

	public function help() {
		return 'در پنل کاوه‌نگار ← «سرویس پیام اعتبارسنجی» یک قالب بسازید که متغیر <code>%token</code> را داشته باشد، مثلاً: <code>کد ورود شما: %token</code>، و نام قالب را بالا وارد کنید.';
	}

	protected function error_labels() {
		return array(
			'400' => 'پارامترها ناقص هستند.',
			'401' => 'حساب کاربری غیرفعال شده است.',
			'403' => 'API Key معتبر نیست.',
			'411' => 'شماره‌ی گیرنده نامعتبر است.',
			'418' => 'اعتبار حساب کافی نیست.',
			'422' => 'داده‌ها به دلیل کاراکتر نامناسب قابل پردازش نیستند.',
			'424' => 'الگو (template) پیدا نشد یا هنوز تایید نشده است.',
			'426' => 'این متد به سرویس پیشرفته نیاز دارد.',
			'431' => 'ساختار کد صحیح نیست.',
			'432' => 'پارامتر کد در متن الگو پیدا نشد.',
		);
	}

	public function send( $phone, $code, array $creds ) {
		$res = self::post(
			'https://api.kavenegar.com/v1/' . rawurlencode( trim( $creds['api_key'] ) ) . '/verify/lookup.json',
			array(
				'receptor' => $phone,
				'token'    => $code,
				'template' => $creds['template'],
			)
		);
		if ( $res['error'] ) {
			return self::fail( 'connection', $res['error'] );
		}
		$j      = $res['json'];
		$status = is_array( $j ) && isset( $j['return']['status'] ) ? (int) $j['return']['status'] : (int) $res['status'];
		if ( 200 === $status ) {
			$ref = isset( $j['entries'][0]['messageid'] ) ? $j['entries'][0]['messageid'] : 'ok';
			return self::ok( $ref );
		}
		return self::fail( (string) $status, isset( $j['return']['message'] ) ? (string) $j['return']['message'] : '' );
	}
}

/**
 * SMS.ir – Verify (template) send.
 * POST https://api.sms.ir/v1/send/verify   header X-API-KEY, JSON { mobile, templateId, parameters:[{name,value}] }
 */
class Shainika_SMS_Provider_Smsir extends Shainika_SMS_Provider {

	public function id() {
		return 'smsir';
	}

	public function label() {
		return 'sms.ir (ارسال وریفای)';
	}

	public function fields() {
		return array(
			'api_key'     => array( 'label' => 'کلید API', 'secret' => true, 'required' => true, 'desc' => 'پنل sms.ir ← برنامه‌نویسان ← لیست کلیدهای API.' ),
			'template_id' => array( 'label' => 'شناسه‌ی قالب (templateId)', 'required' => true, 'placeholder' => '123456' ),
			'param_name'  => array( 'label' => 'نام پارامتر کد', 'default' => 'CODE', 'desc' => 'همان نامی که در متن قالب استفاده کرده‌اید، مثلاً برای <code>#CODE#</code> بنویسید <code>CODE</code>.' ),
		);
	}

	public function help() {
		return 'در پنل sms.ir ← «ارسال سریع / قالب‌ها» یک قالب با پارامتر <code>#CODE#</code> بسازید، مثلاً: <code>کد ورود شما: #CODE#</code>، و شناسه‌ی قالب تاییدشده را بالا وارد کنید.';
	}

	public function is_configured( array $creds ) {
		return parent::is_configured( $creds ) && preg_match( '/^\d+$/', (string) $creds['template_id'] );
	}

	public function send( $phone, $code, array $creds ) {
		$res = self::post_json(
			'https://api.sms.ir/v1/send/verify',
			array(
				'mobile'     => $phone,
				'templateId' => (int) $creds['template_id'],
				'parameters' => array(
					array(
						'name'  => $creds['param_name'] ? $creds['param_name'] : 'CODE',
						'value' => (string) $code,
					),
				),
			),
			array( 'X-API-KEY' => trim( $creds['api_key'] ) )
		);
		if ( $res['error'] ) {
			return self::fail( 'connection', $res['error'] );
		}
		$j = $res['json'];
		if ( is_array( $j ) && isset( $j['status'] ) && 1 === (int) $j['status'] ) {
			return self::ok( isset( $j['data']['messageId'] ) ? $j['data']['messageId'] : 'ok' );
		}
		$status = is_array( $j ) && isset( $j['status'] ) ? (string) $j['status'] : (string) $res['status'];
		return self::fail( $status, is_array( $j ) && isset( $j['message'] ) ? (string) $j['message'] : '' );
	}
}

/**
 * IPPanel (also Faraz SMS and other IPPanel-based panels) – pattern send.
 * POST https://edge.ippanel.com/v1/api/send   header Authorization: {key}
 * JSON { sending_type: "pattern", from_number, code, recipients: [..], params: {..} }
 */
class Shainika_SMS_Provider_IPPanel extends Shainika_SMS_Provider {

	public function id() {
		return 'ippanel';
	}

	public function label() {
		return 'IPPanel / فراز اس‌ام‌اس (پترن)';
	}

	public function fields() {
		return array(
			'api_key'      => array( 'label' => 'توکن API', 'secret' => true, 'required' => true, 'desc' => 'پنل ← توسعه‌دهندگان ← کلید دسترسی.' ),
			'pattern_code' => array( 'label' => 'کد پترن', 'required' => true ),
			'sender'       => array( 'label' => 'شماره‌ی فرستنده', 'default' => '+983000505', 'desc' => 'خط خدماتی پترن پنل شما (پیش‌فرض ‎+983000505).' ),
			'param_name'   => array( 'label' => 'نام متغیر کد در پترن', 'default' => 'code', 'desc' => 'برای پترن <code>%code%</code> بنویسید <code>code</code>.' ),
		);
	}

	public function help() {
		return 'در پنل ← «پترن‌ها» یک پترن با متغیر <code>%code%</code> بسازید، مثلاً: <code>کد ورود شما: %code%</code>، و پس از تایید، کد پترن را بالا وارد کنید.';
	}

	/** First scalar found in the response data, used as the delivery reference. */
	private static function first_scalar( $data ) {
		if ( is_scalar( $data ) && '' !== (string) $data ) {
			return (string) $data;
		}
		if ( is_array( $data ) ) {
			foreach ( $data as $v ) {
				$found = self::first_scalar( $v );
				if ( '' !== $found ) {
					return $found;
				}
			}
		}
		return '';
	}

	public function send( $phone, $code, array $creds ) {
		$param = $creds['param_name'] ? $creds['param_name'] : 'code';
		$res   = self::post_json(
			(string) apply_filters( 'shainika_sms_ippanel_endpoint', 'https://edge.ippanel.com/v1/api/send' ),
			array(
				'sending_type' => 'pattern',
				'from_number'  => $creds['sender'] ? $creds['sender'] : '+983000505',
				'code'         => $creds['pattern_code'],
				'recipients'   => array( self::intl( $phone ) ),
				'params'       => array( $param => (string) $code ),
			),
			array( 'Authorization' => trim( $creds['api_key'] ) )
		);
		if ( $res['error'] ) {
			return self::fail( 'connection', $res['error'] );
		}
		$j = $res['json'];
		if ( is_array( $j ) && isset( $j['meta']['status'] ) && true === $j['meta']['status'] ) {
			$ref = isset( $j['data'] ) ? self::first_scalar( $j['data'] ) : '';
			return self::ok( '' !== $ref ? $ref : 'ok' );
		}
		$error = is_array( $j ) && ! empty( $j['meta']['message_code'] ) ? (string) $j['meta']['message_code'] : (string) $res['status'];
		return self::fail( $error, is_array( $j ) && isset( $j['meta']['message'] ) ? (string) $j['meta']['message'] : '' );
	}
}

/**
 * Ghasedak (قاصدک) – OTP template send (new gateway).
 * POST https://gateway.ghasedak.me/Rest/api/v1/WebService/SendOtpSMS   header ApiKey
 */
class Shainika_SMS_Provider_Ghasedak extends Shainika_SMS_Provider {

	public function id() {
		return 'ghasedak';
	}

	public function label() {
		return 'قاصدک (OTP)';
	}

	public function fields() {
		return array(
			'api_key'    => array( 'label' => 'ApiKey', 'secret' => true, 'required' => true ),
			'template'   => array( 'label' => 'نام قالب (templateName)', 'required' => true ),
			'param_name' => array( 'label' => 'نام پارامتر کد', 'default' => 'Code', 'desc' => 'نام پارامتری که در قالب قاصدک تعریف کرده‌اید.' ),
		);
	}

	public function help() {
		return 'در پنل قاصدک یک قالب OTP با یک پارامتر (مثلاً <code>Code</code>) بسازید و نام قالب تاییدشده را بالا وارد کنید.';
	}

	public function send( $phone, $code, array $creds ) {
		$res = self::post_json(
			'https://gateway.ghasedak.me/Rest/api/v1/WebService/SendOtpSMS',
			array(
				'sendDate'     => gmdate( 'c' ),
				'receptors'    => array(
					array(
						'mobile'            => $phone,
						'clientReferenceId' => (string) wp_rand( 100000, 999999999 ),
					),
				),
				'templateName' => $creds['template'],
				'inputs'       => array(
					array(
						'param' => $creds['param_name'] ? $creds['param_name'] : 'Code',
						'value' => (string) $code,
					),
				),
				'udh'          => false,
				'isVoice'      => false,
			),
			array( 'ApiKey' => trim( $creds['api_key'] ) )
		);
		if ( $res['error'] ) {
			return self::fail( 'connection', $res['error'] );
		}
		$j = $res['json'];
		if ( is_array( $j ) && ! empty( $j['isSuccess'] ) && ! empty( $j['data'] ) ) {
			return self::ok( isset( $j['data']['items'][0]['messageId'] ) ? $j['data']['items'][0]['messageId'] : 'ok' );
		}
		$status = is_array( $j ) && isset( $j['statusCode'] ) ? (string) $j['statusCode'] : (string) $res['status'];
		return self::fail( $status, is_array( $j ) && isset( $j['message'] ) ? (string) $j['message'] : '' );
	}
}

/**
 * Developer hook for any other gateway:
 *
 *   add_filter( 'shainika_sms_custom_send', function ( $result, $phone, $code, $text ) {
 *       // send $text to $phone ... then return true, a WP_Error, or array( 'ok' => true, 'ref' => '...' ).
 *       return true;
 *   }, 10, 4 );
 */
class Shainika_SMS_Provider_Custom extends Shainika_SMS_Provider {

	public function id() {
		return 'custom';
	}

	public function label() {
		return 'سرویس دیگر (کد برنامه‌نویس)';
	}

	public function fields() {
		return array(
			'text' => array( 'label' => 'متن پیامک', 'default' => 'کد ورود شما: {code}', 'desc' => 'به فیلتر <code>shainika_sms_custom_send</code> داده می‌شود. متغیرها: <code>{code}</code> و <code>{site}</code>.' ),
		);
	}

	public function help() {
		return 'برای هر سرویس دیگری، در functions.php قالب فرزند یا یک افزونه‌ی کوچک فیلتر <code>shainika_sms_custom_send</code> را پیاده کنید (نمونه در README).';
	}

	public function is_configured( array $creds ) {
		return (bool) has_filter( 'shainika_sms_custom_send' );
	}

	public function send( $phone, $code, array $creds ) {
		$text   = Shainika_SMS_Sender::fill( $creds['text'] ? $creds['text'] : 'کد ورود شما: {code}', $code );
		$result = apply_filters( 'shainika_sms_custom_send', null, $phone, $code, $text );
		if ( true === $result ) {
			return self::ok( 'custom' );
		}
		if ( is_wp_error( $result ) ) {
			return self::fail( $result->get_error_code(), $result->get_error_message() );
		}
		if ( is_array( $result ) && ! empty( $result['ok'] ) ) {
			return self::ok( isset( $result['ref'] ) ? $result['ref'] : 'custom' );
		}
		return self::fail( 'no_handler', 'هیچ کدی برای فیلتر shainika_sms_custom_send پیامک را ارسال نکرد.' );
	}
}

/** Provider registry + test mode. */
class Shainika_SMS_Sender {

	private static $providers = null;

	/** @return Shainika_SMS_Provider[] keyed by id. */
	public static function providers() {
		if ( null === self::$providers ) {
			$list = apply_filters(
				'shainika_sms_providers',
				array(
					new Shainika_SMS_Provider_Melipayamak(),
					new Shainika_SMS_Provider_Kavenegar(),
					new Shainika_SMS_Provider_Smsir(),
					new Shainika_SMS_Provider_IPPanel(),
					new Shainika_SMS_Provider_Ghasedak(),
					new Shainika_SMS_Provider_Custom(),
				)
			);
			self::$providers = array();
			foreach ( (array) $list as $provider ) {
				if ( $provider instanceof Shainika_SMS_Provider && preg_match( '/^[a-z0-9_]+$/', $provider->id() ) ) {
					self::$providers[ $provider->id() ] = $provider;
				}
			}
		}
		return self::$providers;
	}

	public static function get( $id ) {
		$all = self::providers();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/** The selected provider (falls back to the first registered one). */
	public static function current() {
		$provider = self::get( (string) Shainika_SMS_Settings::get( 'provider' ) );
		if ( ! $provider ) {
			$all      = self::providers();
			$provider = $all ? reset( $all ) : null;
		}
		return $provider;
	}

	/** Field values with defaults, from wp-config.php constants or the settings. */
	public static function credentials( Shainika_SMS_Provider $provider ) {
		$out = array();
		foreach ( $provider->fields() as $key => $field ) {
			$out[ $key ] = Shainika_SMS_Settings::cred( $provider->id(), $key, isset( $field['default'] ) ? $field['default'] : '' );
		}
		return $out;
	}

	/** Replaces {code} and {site} in a template. */
	public static function fill( $template, $code ) {
		return str_replace(
			array( '{code}', '{site}' ),
			array( $code, wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
			(string) $template
		);
	}

	/**
	 * @return array{ok:bool,ref:string,error:string,message:string,test:bool}
	 */
	public static function send_otp( $phone, $code ) {
		if ( ! Shainika_SMS_Settings::is_live() ) {
			// Test mode: nothing leaves the server. Admins can read the code on the settings page.
			$list = get_transient( 'shainika_sms_test_codes' );
			$list = is_array( $list ) ? $list : array();
			array_unshift( $list, array( 'phone' => $phone, 'code' => (string) $code, 'time' => time() ) );
			set_transient( 'shainika_sms_test_codes', array_slice( $list, 0, 10 ), 15 * MINUTE_IN_SECONDS );
			if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
				error_log( sprintf( '[shainika-sms] TEST MODE - code for %s is %s', $phone, $code ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
			}
			return array( 'ok' => true, 'ref' => 'test', 'error' => '', 'message' => '', 'test' => true );
		}

		$provider = self::current();
		$result   = $provider->send( $phone, (string) $code, self::credentials( $provider ) );
		$result   = wp_parse_args( is_array( $result ) ? $result : array(), array( 'ok' => false, 'ref' => '', 'error' => 'invalid_result', 'message' => '' ) );
		$result['test'] = false;

		if ( ! $result['ok'] ) {
			error_log( '[shainika-sms] ' . $provider->id() . ' error: ' . $provider->error_label( $result['error'], $result['message'] ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
		}
		do_action( 'shainika_sms_sent', $result, $phone, $provider->id() );
		return $result;
	}
}
