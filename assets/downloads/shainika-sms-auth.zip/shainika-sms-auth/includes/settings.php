<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings storage.
 *
 * Secrets can also be defined in wp-config.php instead of the database:
 *   SHAINIKA_SMS_{PROVIDER}_{FIELD}   e.g. SHAINIKA_SMS_KAVENEGAR_API_KEY, SHAINIKA_SMS_MELIPAYAMAK_PASSWORD
 *   SHAINIKA_SMS_NESHAN_SERVICE_KEY
 */
class Shainika_SMS_Settings {

	const OPTION = 'shainika_sms_settings';

	/** Field statuses for the registration form. */
	const FIELD_STATES = array( 'off', 'optional', 'required' );

	/** Where the visitor IP may be read from. */
	public static function ip_sources() {
		return array(
			'remote_addr'     => 'REMOTE_ADDR (بدون CDN یا پروکسی)',
			'cloudflare'      => 'CF-Connecting-IP (کلادفلر)',
			'x_forwarded_for' => 'X-Forwarded-For، اولین IP (ابرآروان و بیشتر CDNها و پروکسی‌ها)',
			'x_real_ip'       => 'X-Real-IP (پروکسی Nginx)',
		);
	}

	public static function defaults() {
		return array(
			// SMS.
			'mode'                    => 'test', // test = nothing is sent; the code is shown on the settings page.
			'provider'                => 'melipayamak',
			'creds'                   => array(), // provider_id => array( field => value ).

			// Code & limits.
			'code_length'             => 5,
			'code_ttl'                => 120,
			'resend_cooldown'         => 60,
			'max_sends_phone'         => 3,
			'send_window'             => 600,
			'max_sends_day'           => 10,
			'max_sends_ip_hour'       => 10,
			'max_sends_total_hour'    => 300,
			'max_attempts'            => 5,
			'ip_source'               => 'remote_addr',

			// Accounts.
			'registration'            => 1,
			'new_user_role'           => '',
			'allowed_roles'           => array( 'customer', 'subscriber' ),
			'fields'                  => array(
				'first_name' => 'required',
				'last_name'  => 'required',
				'email'      => 'off',
				'phone2'     => 'off',
				'address'    => 'off',
				'postcode'   => 'off',
				'map'        => 'off',
			),
			'legacy_meta_keys'        => '',

			// Neshan map.
			'neshan_map_key'          => '',
			'neshan_service_key'      => '',
			'map_lat'                 => '35.6892',
			'map_lng'                 => '51.3890',
			'map_zoom'                => 12,

			// Placement.
			'wc_myaccount'            => 'replace', // replace | above | off.
			'wc_checkout'             => 1,
			'wp_login'                => 0,
			'modal_selector'          => '.ssa-open > a, a.ssa-open, a[href="#sms-login"]',
			'intercept_account_links' => 0,
			'password_link'           => 1,
			'redirect_after'          => '',

			// Appearance.
			'title'                   => 'ورود یا ثبت‌نام',
			'bg'                      => '#ffffff',
			'text'                    => '#1d2327',
			'title_color'             => '',
			'muted'                   => '',
			'accent'                  => '#2271b1',
			'button_text'             => '',
			'link'                    => '',
			'field_bg'                => '',
			'border'                  => '',
			'radius'                  => 8,
		);
	}

	/**
	 * Login form colors: key => array( label, CSS variable, description ).
	 * An empty value means "automatic" (derived from the other colors), except for the three base colors.
	 */
	public static function colors() {
		return array(
			'bg'          => array( 'پس‌زمینه‌ی کادر', '--ssa-bg', '' ),
			'text'        => array( 'رنگ متن‌ها', '--ssa-text', 'برچسب‌ها و متن داخل فیلدها.' ),
			'title_color' => array( 'رنگ عنوان', '--ssa-title', 'خالی = همان رنگ متن‌ها.' ),
			'muted'       => array( 'رنگ متن‌های توضیحی', '--ssa-muted', 'متن راهنمای بالای فرم. خالی = کم‌رنگ‌شده‌ی رنگ متن.' ),
			'accent'      => array( 'رنگ دکمه', '--ssa-accent', 'پس‌زمینه‌ی دکمه‌ها و حاشیه‌ی فیلد فعال.' ),
			'button_text' => array( 'رنگ متن دکمه', '--ssa-on-accent', 'خالی = خودکار (سفید یا مشکی، هر کدام روی رنگ دکمه خواناتر است).' ),
			'link'        => array( 'رنگ لینک‌ها', '--ssa-link', 'مثل «ارسال مجدد کد». خالی = همان رنگ دکمه.' ),
			'field_bg'    => array( 'پس‌زمینه‌ی فیلدها', '--ssa-field', 'خالی = خودکار.' ),
			'border'      => array( 'رنگ خط دور کادر و فیلدها', '--ssa-line', 'خالی = خودکار.' ),
		);
	}

	/** Colors that can never be empty. */
	const BASE_COLORS = array( 'bg', 'text', 'accent' );

	/** CSS custom properties for the current (or given) settings. */
	public static function css_vars( $s = null ) {
		$s    = is_array( $s ) ? $s : self::all();
		$vars = array();
		foreach ( self::colors() as $key => $color ) {
			$value = isset( $s[ $key ] ) ? sanitize_hex_color( (string) $s[ $key ] ) : '';
			if ( $value ) {
				$vars[ $color[1] ] = $value;
			}
		}
		if ( empty( $vars['--ssa-on-accent'] ) ) {
			$vars['--ssa-on-accent'] = self::readable_on( isset( $vars['--ssa-accent'] ) ? $vars['--ssa-accent'] : self::defaults()['accent'] );
		}
		$vars['--ssa-radius'] = (int) ( isset( $s['radius'] ) ? $s['radius'] : 8 ) . 'px';
		$out = '';
		foreach ( $vars as $name => $value ) {
			$out .= $name . ':' . $value . ';';
		}
		return $out;
	}

	/** White or near-black, whichever reads better on the given hex color (WCAG relative luminance). */
	public static function readable_on( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( ! preg_match( '/^[0-9a-f]{6}$/i', $hex ) ) {
			return '#ffffff';
		}
		$lum = 0;
		foreach ( array( 0.2126, 0.7152, 0.0722 ) as $i => $weight ) {
			$c    = hexdec( substr( $hex, $i * 2, 2 ) ) / 255;
			$c    = $c <= 0.03928 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
			$lum += $weight * $c;
		}
		// Contrast with white = 1.05 / (L + 0.05); with #111 ≈ (L + 0.05) / 0.0555.
		return ( 1.05 / ( $lum + 0.05 ) ) >= ( ( $lum + 0.05 ) / 0.0555 ) ? '#ffffff' : '#111111';
	}

	public static function all() {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}
		$all = wp_parse_args( $stored, self::defaults() );
		// Nested arrays are merged one level deep so new fields get their defaults.
		$all['fields'] = wp_parse_args( is_array( $all['fields'] ) ? $all['fields'] : array(), self::defaults()['fields'] );
		$all['creds']  = is_array( $all['creds'] ) ? $all['creds'] : array();
		return $all;
	}

	public static function get( $key ) {
		if ( 'neshan_service_key' === $key && defined( 'SHAINIKA_SMS_NESHAN_SERVICE_KEY' ) ) {
			return constant( 'SHAINIKA_SMS_NESHAN_SERVICE_KEY' );
		}
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/** Name of the wp-config.php constant that may hold a provider credential. */
	public static function cred_constant( $provider_id, $field ) {
		return strtoupper( 'SHAINIKA_SMS_' . $provider_id . '_' . $field );
	}

	public static function cred( $provider_id, $field, $default = '' ) {
		$const = self::cred_constant( $provider_id, $field );
		if ( defined( $const ) ) {
			return (string) constant( $const );
		}
		$creds = self::get( 'creds' );
		if ( isset( $creds[ $provider_id ][ $field ] ) && '' !== $creds[ $provider_id ][ $field ] ) {
			return (string) $creds[ $provider_id ][ $field ];
		}
		return (string) $default;
	}

	/** True only when the admin switched to live mode AND the selected provider is fully configured. */
	public static function is_live() {
		if ( 'live' !== self::get( 'mode' ) ) {
			return false;
		}
		$provider = Shainika_SMS_Sender::current();
		return $provider && $provider->is_configured( Shainika_SMS_Sender::credentials( $provider ) );
	}

	/** Roles holding any of these capabilities can never log in with SMS only. */
	public static function blocked_caps() {
		return (array) apply_filters(
			'shainika_sms_blocked_caps',
			array( 'manage_options', 'edit_others_posts', 'edit_users', 'create_users', 'delete_users', 'promote_users', 'list_users', 'manage_woocommerce', 'activate_plugins', 'install_plugins', 'edit_theme_options', 'unfiltered_html' )
		);
	}

	public static function role_is_safe( $slug ) {
		$role = get_role( $slug );
		if ( ! $role ) {
			return false;
		}
		foreach ( self::blocked_caps() as $cap ) {
			if ( $role->has_cap( $cap ) ) {
				return false;
			}
		}
		return true;
	}

	/** Role given to accounts created through SMS. */
	public static function new_user_role() {
		$role = (string) self::get( 'new_user_role' );
		if ( '' === $role || ! get_role( $role ) ) {
			$role = ( shainika_sms_has_wc() && get_role( 'customer' ) ) ? 'customer' : (string) get_option( 'default_role', 'subscriber' );
		}
		return self::role_is_safe( $role ) ? $role : 'subscriber';
	}

	private static function hex_color( $value, $fallback ) {
		$value = sanitize_hex_color( is_string( $value ) ? trim( $value ) : '' );
		return $value ? $value : $fallback;
	}

	public static function sanitize( $input ) {
		// options.php has already unslashed the submitted value.
		$input   = is_array( $input ) ? $input : array();
		$current = self::all();
		$d       = self::defaults();
		$out     = array();

		$out['mode'] = ( isset( $input['mode'] ) && 'live' === $input['mode'] ) ? 'live' : 'test';

		$providers       = Shainika_SMS_Sender::providers();
		$out['provider'] = ( isset( $input['provider'] ) && isset( $providers[ $input['provider'] ] ) ) ? $input['provider'] : $current['provider'];

		// Provider credentials. Secret fields keep their stored value when submitted empty.
		$creds      = $current['creds'];
		$post_creds = isset( $input['creds'] ) && is_array( $input['creds'] ) ? $input['creds'] : array();
		foreach ( $providers as $pid => $provider ) {
			if ( ! isset( $post_creds[ $pid ] ) || ! is_array( $post_creds[ $pid ] ) ) {
				continue;
			}
			foreach ( $provider->fields() as $key => $field ) {
				$val = isset( $post_creds[ $pid ][ $key ] ) ? trim( (string) $post_creds[ $pid ][ $key ] ) : '';
				if ( ! empty( $field['secret'] ) && '' === $val ) {
					continue;
				}
				$creds[ $pid ][ $key ] = sanitize_text_field( $val );
			}
		}
		$out['creds'] = $creds;

		$ranges = array(
			'code_length'          => array( 4, 8 ),
			'code_ttl'             => array( 60, 900 ),
			'resend_cooldown'      => array( 30, 600 ),
			'max_sends_phone'      => array( 1, 20 ),
			'send_window'          => array( 60, 3600 ),
			'max_sends_day'        => array( 1, 100 ),
			'max_sends_ip_hour'    => array( 1, 500 ),
			'max_sends_total_hour' => array( 10, 100000 ),
			'max_attempts'         => array( 3, 10 ),
			'map_zoom'             => array( 4, 19 ),
			'radius'               => array( 0, 24 ),
		);
		foreach ( $ranges as $key => $range ) {
			if ( ! isset( $input[ $key ] ) ) {
				$val = (int) $current[ $key ];
			} else {
				$val = '' !== $input[ $key ] ? (int) $input[ $key ] : (int) $d[ $key ];
			}
			$out[ $key ] = max( $range[0], min( $range[1], $val ) );
		}

		$out['ip_source'] = ( isset( $input['ip_source'] ) && isset( self::ip_sources()[ $input['ip_source'] ] ) ) ? $input['ip_source'] : 'remote_addr';

		// Accounts.
		/*
		 * Checkboxes. The settings form lists the ones it printed in "_checkboxes", so an unchecked box
		 * becomes 0 while options that were not on the form (e.g. WooCommerce ones while WooCommerce
		 * is inactive) keep their value.
		 */
		$printed = isset( $input['_checkboxes'] ) && is_array( $input['_checkboxes'] ) ? $input['_checkboxes'] : null;
		foreach ( array( 'registration', 'wc_checkout', 'wp_login', 'intercept_account_links', 'password_link' ) as $key ) {
			if ( null !== $printed ? in_array( $key, $printed, true ) : isset( $input[ $key ] ) ) {
				$out[ $key ] = empty( $input[ $key ] ) ? 0 : 1;
			} else {
				$out[ $key ] = empty( $current[ $key ] ) ? 0 : 1;
			}
		}

		$safe_roles = array();
		foreach ( array_keys( wp_roles()->roles ) as $slug ) {
			if ( self::role_is_safe( $slug ) ) {
				$safe_roles[] = $slug;
			}
		}
		$roles = isset( $input['allowed_roles'] ) && is_array( $input['allowed_roles'] ) ? array_map( 'sanitize_key', $input['allowed_roles'] ) : array();
		$roles = array_values( array_intersect( $roles, $safe_roles ) );
		// Roles of inactive plugins (e.g. "customer" while WooCommerce is off) are not on the form: keep them.
		foreach ( (array) $current['allowed_roles'] as $kept ) {
			if ( ! get_role( $kept ) && ! in_array( $kept, $roles, true ) ) {
				$roles[] = $kept;
			}
		}
		$new_role             = isset( $input['new_user_role'] ) ? sanitize_key( $input['new_user_role'] ) : '';
		$out['new_user_role'] = in_array( $new_role, $safe_roles, true ) ? $new_role : '';

		// New accounts must be able to log in again: their role is always allowed.
		$created_role = $out['new_user_role'] ? $out['new_user_role'] : null;
		if ( null === $created_role ) {
			$created_role = ( shainika_sms_has_wc() && get_role( 'customer' ) ) ? 'customer' : (string) get_option( 'default_role', 'subscriber' );
		}
		if ( in_array( $created_role, $safe_roles, true ) && ! in_array( $created_role, $roles, true ) ) {
			$roles[] = $created_role;
		}
		$out['allowed_roles'] = $roles ? array_values( $roles ) : $d['allowed_roles'];

		$fields        = isset( $input['fields'] ) && is_array( $input['fields'] ) ? $input['fields'] : array();
		$out['fields'] = array();
		foreach ( $d['fields'] as $key => $default_state ) {
			$state                 = isset( $fields[ $key ] ) ? (string) $fields[ $key ] : $current['fields'][ $key ];
			$out['fields'][ $key ] = in_array( $state, self::FIELD_STATES, true ) ? $state : $default_state;
		}

		$keys = isset( $input['legacy_meta_keys'] ) ? preg_split( '/[\s,]+/', (string) $input['legacy_meta_keys'] ) : array();
		$keys = array_filter(
			array_map( 'sanitize_key', $keys ),
			function ( $k ) {
				return '' !== $k && Shainika_SMS_Users::meta_key() !== $k;
			}
		);
		$out['legacy_meta_keys'] = implode( ', ', array_unique( $keys ) );

		// Neshan.
		$out['neshan_map_key'] = isset( $input['neshan_map_key'] ) ? sanitize_text_field( trim( $input['neshan_map_key'] ) ) : $current['neshan_map_key'];
		$service_key           = isset( $input['neshan_service_key'] ) ? trim( (string) $input['neshan_service_key'] ) : '';
		if ( ! empty( $input['neshan_service_key_clear'] ) ) {
			$out['neshan_service_key'] = '';
		} else {
			$out['neshan_service_key'] = '' !== $service_key ? sanitize_text_field( $service_key ) : $current['neshan_service_key'];
		}
		$out['map_lat'] = (string) max( -90, min( 90, (float) ( isset( $input['map_lat'] ) ? $input['map_lat'] : $d['map_lat'] ) ) );
		$out['map_lng'] = (string) max( -180, min( 180, (float) ( isset( $input['map_lng'] ) ? $input['map_lng'] : $d['map_lng'] ) ) );

		// Placement.
		$out['wc_myaccount']            = ( isset( $input['wc_myaccount'] ) && in_array( $input['wc_myaccount'], array( 'replace', 'above', 'off' ), true ) ) ? $input['wc_myaccount'] : $current['wc_myaccount'];
		$out['modal_selector']          = isset( $input['modal_selector'] ) ? trim( wp_strip_all_tags( $input['modal_selector'] ) ) : $current['modal_selector'];
		$out['redirect_after']          = isset( $input['redirect_after'] ) ? esc_url_raw( trim( $input['redirect_after'] ) ) : '';

		// Appearance.
		$title         = isset( $input['title'] ) ? sanitize_text_field( $input['title'] ) : '';
		$out['title']  = '' !== $title ? $title : $d['title'];
		foreach ( array_keys( self::colors() ) as $key ) {
			$fallback    = in_array( $key, self::BASE_COLORS, true ) ? $d[ $key ] : '';
			$out[ $key ] = self::hex_color( isset( $input[ $key ] ) ? $input[ $key ] : '', $fallback );
		}

		return $out;
	}
}
