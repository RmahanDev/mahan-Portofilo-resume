<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shainika_SMS_Users {

	const PLACEHOLDER_SUFFIX = '.invalid';

	public static function init() {
		// Admin: mobile number on the user profile and in the users list.
		add_action( 'show_user_profile', array( __CLASS__, 'profile_box' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'profile_box' ) );
		add_action( 'user_profile_update_errors', array( __CLASS__, 'profile_validate' ), 10, 3 );
		add_action( 'personal_options_update', array( __CLASS__, 'profile_save' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'profile_save' ) );
		add_filter( 'manage_users_columns', array( __CLASS__, 'users_column' ) );
		add_filter( 'manage_users_custom_column', array( __CLASS__, 'users_column_value' ), 10, 3 );

		if ( shainika_sms_has_wc() ) {
			// Never show the technical placeholder address as the customer's email (classic and block checkout).
			add_filter( 'woocommerce_customer_get_billing_email', array( __CLASS__, 'hide_placeholder' ) );
			add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'copy_extra_to_order' ) );
			add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( __CLASS__, 'copy_extra_to_order' ) );
			add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'adopt_order_email_classic' ), 10, 3 );
			add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'adopt_order_email' ) );
			add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'show_extra_in_order' ) );
		}
	}

	/** User meta key holding the verified mobile (09xxxxxxxxx). */
	public static function meta_key() {
		return (string) apply_filters( 'shainika_sms_phone_meta_key', 'shainika_mobile' );
	}

	public static function is_placeholder( $email ) {
		return is_string( $email ) && '' !== $email && str_ends_with( strtolower( $email ), self::PLACEHOLDER_SUFFIX );
	}

	/** Extra meta keys that may already hold mobiles of existing users (e.g. billing_phone). */
	public static function legacy_keys() {
		$keys = preg_split( '/[\s,]+/', (string) Shainika_SMS_Settings::get( 'legacy_meta_keys' ) );
		return array_values( array_filter( array_map( 'sanitize_key', (array) $keys ) ) );
	}

	/** Common spellings of the same mobile, for matching numbers stored by other plugins. */
	private static function variants( $phone ) {
		$n = substr( $phone, 1 ); // 9xxxxxxxxx
		return array( $phone, $n, '+98' . $n, '98' . $n, '0098' . $n, '+98 ' . $n );
	}

	/**
	 * Finds the account of a verified mobile.
	 *
	 * @return int|WP_Error User ID, 0 when there is none, WP_Error when several accounts match.
	 */
	public static function find_by_phone( $phone ) {
		$ambiguous = new WP_Error( 'ambiguous', 'چند حساب با این شماره وجود دارد. با نام کاربری و رمز عبور وارد شوید یا با پشتیبانی تماس بگیرید.' );

		$ids = get_users(
			array(
				'meta_key'    => self::meta_key(), // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'  => $phone, // phpcs:ignore WordPress.DB.SlowDBQuery
				'number'      => 2,
				'fields'      => 'ID',
				'count_total' => false,
			)
		);
		if ( count( $ids ) > 1 ) {
			return $ambiguous;
		}
		if ( $ids ) {
			return (int) $ids[0];
		}

		$keys = self::legacy_keys();
		if ( ! $keys ) {
			return 0;
		}
		$meta_query = array( 'relation' => 'OR' );
		foreach ( $keys as $key ) {
			$meta_query[] = array(
				'key'     => $key,
				'value'   => self::variants( $phone ),
				'compare' => 'IN',
			);
		}
		$ids = get_users(
			array(
				'meta_query'  => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery
				'number'      => 5,
				'fields'      => 'ID',
				'count_total' => false,
			)
		);
		// Accounts that already have their own verified mobile are not matched through other fields.
		$meta_key = self::meta_key();
		$ids      = array_values(
			array_filter(
				$ids,
				function ( $id ) use ( $meta_key ) {
					return '' === (string) get_user_meta( $id, $meta_key, true );
				}
			)
		);
		if ( count( $ids ) > 1 ) {
			return $ambiguous;
		}
		return $ids ? (int) $ids[0] : 0;
	}

	/** SMS login is only allowed for allowed roles and never for accounts that can manage the site. */
	public static function can_sms_login( $user ) {
		$allowed   = (array) Shainika_SMS_Settings::get( 'allowed_roles' );
		$allowed[] = Shainika_SMS_Settings::new_user_role(); // Accounts created by SMS can always come back.
		$ok      = ! empty( $user->roles ) && 0 === count( array_diff( (array) $user->roles, $allowed ) );
		if ( $ok ) {
			foreach ( Shainika_SMS_Settings::blocked_caps() as $cap ) {
				if ( user_can( $user, $cap ) ) {
					$ok = false;
					break;
				}
			}
		}
		return (bool) apply_filters( 'shainika_sms_can_login', $ok, $user );
	}

	public static function login( $user_id, $phone = '' ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return false;
		}
		// An account found through another field (e.g. billing_phone) is now linked to the verified number.
		if ( $phone && '' === (string) get_user_meta( $user_id, self::meta_key(), true ) ) {
			update_user_meta( $user_id, self::meta_key(), $phone );
			update_user_meta( $user_id, 'shainika_mobile_verified', time() );
		}
		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, (bool) apply_filters( 'shainika_sms_remember', true, $user ) );
		do_action( 'wp_login', $user->user_login, $user );
		return true;
	}

	/**
	 * @param string $phone Verified mobile (09xxxxxxxxx).
	 * @param array  $d     Output of Shainika_SMS_Fields::validate().
	 * @return int|WP_Error
	 */
	public static function create( $phone, $d ) {
		$d = wp_parse_args(
			$d,
			array( 'first_name' => '', 'last_name' => '', 'email' => '', 'phone2' => '', 'address' => '', 'postcode' => '', 'lat' => '', 'lng' => '' )
		);

		$base  = sanitize_user( (string) apply_filters( 'shainika_sms_username', $phone, $phone, $d ), true );
		$base  = '' !== $base ? $base : $phone;
		$login = $base;
		$i     = 1;
		while ( username_exists( $login ) ) {
			$login = $base . '-' . $i++;
		}

		$placeholder = '' === $d['email'];
		if ( $placeholder ) {
			$host  = preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
			$email = apply_filters( 'shainika_sms_placeholder_email', $phone . '@' . ( $host ? $host : 'example' ) . self::PLACEHOLDER_SUFFIX, $phone );
		} else {
			$email = $d['email'];
		}

		$name = trim( $d['first_name'] . ' ' . $d['last_name'] );
		$id   = wp_insert_user(
			array(
				'user_login'   => $login,
				'user_pass'    => wp_generate_password( 32, true, true ),
				'user_email'   => $email,
				'first_name'   => $d['first_name'],
				'last_name'    => $d['last_name'],
				'display_name' => '' !== $name ? $name : $phone,
				'nickname'     => '' !== $name ? $name : $login,
				'role'         => Shainika_SMS_Settings::new_user_role(),
			)
		);
		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$meta = array(
			self::meta_key()         => $phone,
			'shainika_mobile_verified' => time(),
			'shainika_phone2'          => $d['phone2'],
			'shainika_lat'             => $d['lat'],
			'shainika_lng'             => $d['lng'],
		);
		if ( $placeholder ) {
			$meta['shainika_placeholder_mail'] = 1;
		}
		if ( shainika_sms_has_wc() ) {
			$meta += array(
				'billing_first_name'  => $d['first_name'],
				'billing_last_name'   => $d['last_name'],
				'billing_phone'       => $phone,
				'billing_email'       => $placeholder ? '' : $email,
				'billing_address_1'   => $d['address'],
				'billing_postcode'    => $d['postcode'],
				'shipping_first_name' => $d['first_name'],
				'shipping_last_name'  => $d['last_name'],
				'shipping_address_1'  => $d['address'],
				'shipping_postcode'   => $d['postcode'],
			);
			if ( '' !== $d['address'] || '' !== $d['postcode'] ) {
				$meta['billing_country']  = 'IR';
				$meta['shipping_country'] = 'IR';
			}
		}
		foreach ( $meta as $key => $value ) {
			if ( '' !== (string) $value ) {
				update_user_meta( $id, $key, $value );
			}
		}
		do_action( 'shainika_sms_user_created', $id, $phone, $d );
		return $id;
	}

	/* ---------- WooCommerce ---------- */

	public static function hide_placeholder( $email ) {
		return self::is_placeholder( $email ) ? '' : $email;
	}

	public static function copy_extra_to_order( $order ) {
		$uid = get_current_user_id();
		if ( ! $uid || ! is_object( $order ) ) {
			return;
		}
		foreach ( array( 'shainika_phone2', 'shainika_lat', 'shainika_lng' ) as $key ) {
			$val = (string) get_user_meta( $uid, $key, true );
			if ( '' !== $val ) {
				$order->update_meta_data( '_' . $key, $val );
			}
		}
	}

	public static function adopt_order_email_classic( $order_id, $posted = array(), $order = null ) {
		self::adopt_order_email( $order ? $order : wc_get_order( $order_id ) );
	}

	/** An account created without email takes the first real email the customer enters at checkout. */
	public static function adopt_order_email( $order ) {
		if ( ! $order || ! is_callable( array( $order, 'get_customer_id' ) ) || ! apply_filters( 'shainika_sms_adopt_checkout_email', true ) ) {
			return;
		}
		$uid  = (int) $order->get_customer_id();
		$user = $uid ? get_userdata( $uid ) : false;
		if ( ! $user || $uid !== get_current_user_id() || ! self::is_placeholder( $user->user_email ) ) {
			return;
		}
		$email = sanitize_email( $order->get_billing_email() );
		if ( ! is_email( $email ) || self::is_placeholder( $email ) || email_exists( $email ) ) {
			return;
		}
		add_filter( 'send_email_change_email', '__return_false', 99 );
		$res = wp_update_user( array( 'ID' => $uid, 'user_email' => $email ) );
		remove_filter( 'send_email_change_email', '__return_false', 99 );
		if ( ! is_wp_error( $res ) ) {
			delete_user_meta( $uid, 'shainika_placeholder_mail' );
			update_user_meta( $uid, 'billing_email', $email );
		}
	}

	public static function show_extra_in_order( $order ) {
		$phone2 = $order->get_meta( '_shainika_phone2' );
		$lat    = $order->get_meta( '_shainika_lat' );
		$lng    = $order->get_meta( '_shainika_lng' );
		if ( $phone2 ) {
			echo '<p><strong>شماره دوم:</strong> <span dir="ltr">' . esc_html( $phone2 ) . '</span></p>';
		}
		if ( $lat && $lng ) {
			$url = 'https://www.google.com/maps?q=' . rawurlencode( $lat . ',' . $lng );
			echo '<p><strong>موقعیت روی نقشه:</strong> <a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $lat . ', ' . $lng ) . '</a></p>';
		}
	}

	/* ---------- admin: profile + users list ---------- */

	public static function profile_box( $user ) {
		if ( ! current_user_can( 'edit_users' ) ) {
			return;
		}
		$mobile = (string) get_user_meta( $user->ID, self::meta_key(), true );
		echo '<h2>ورود پیامکی</h2><table class="form-table" role="presentation">';
		echo '<tr><th><label for="shainika_mobile_field">موبایل ورود پیامکی</label></th><td>';
		echo '<input type="tel" id="shainika_mobile_field" name="shainika_mobile_field" value="' . esc_attr( $mobile ) . '" class="regular-text" dir="ltr" placeholder="09123456789" />';
		echo '<p class="description">با این شماره و کد پیامکی وارد می‌شود. خالی = بدون ورود پیامکی.';
		if ( ! self::can_sms_login( $user ) ) {
			echo ' <strong>نقش یا دسترسی‌های این کاربر اجازه‌ی ورود پیامکی نمی‌دهد.</strong>';
		}
		echo '</p></td></tr>';
		$rows = array(
			'شماره دوم'   => get_user_meta( $user->ID, 'shainika_phone2', true ),
			'مختصات نقشه' => trim( get_user_meta( $user->ID, 'shainika_lat', true ) . ', ' . get_user_meta( $user->ID, 'shainika_lng', true ), ' ,' ),
		);
		foreach ( $rows as $label => $value ) {
			if ( '' !== (string) $value ) {
				echo '<tr><th>' . esc_html( $label ) . '</th><td dir="ltr" style="text-align:right">' . esc_html( $value ) . '</td></tr>';
			}
		}
		echo '</table>';
	}

	/** @param WP_Error $errors */
	public static function profile_validate( $errors, $update, $user ) {
		if ( ! current_user_can( 'edit_users' ) || ! isset( $_POST['shainika_mobile_field'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$raw = trim( sanitize_text_field( wp_unslash( $_POST['shainika_mobile_field'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( '' === $raw ) {
			return;
		}
		$phone = Shainika_SMS_OTP::normalize_phone( $raw );
		if ( ! $phone ) {
			$errors->add( 'shainika_mobile', '<strong>خطا:</strong> موبایل ورود پیامکی معتبر نیست (نمونه: 09123456789).' );
			return;
		}
		$owner = get_users(
			array(
				'meta_key'   => self::meta_key(), // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => $phone, // phpcs:ignore WordPress.DB.SlowDBQuery
				'exclude'    => isset( $user->ID ) ? array( (int) $user->ID ) : array(),
				'number'     => 1,
				'fields'     => 'ID',
			)
		);
		if ( $owner ) {
			$errors->add( 'shainika_mobile', '<strong>خطا:</strong> این موبایل به حساب دیگری متصل است.' );
		}
	}

	public static function profile_save( $user_id ) {
		if ( ! current_user_can( 'edit_users' ) || ! isset( $_POST['shainika_mobile_field'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$raw = trim( sanitize_text_field( wp_unslash( $_POST['shainika_mobile_field'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( '' === $raw ) {
			delete_user_meta( $user_id, self::meta_key() );
			return;
		}
		$phone = Shainika_SMS_OTP::normalize_phone( $raw );
		// Validation errors stop the save before this hook runs; this check is a second guard.
		if ( $phone && ! Shainika_SMS_Users::taken_by_other( $phone, $user_id ) ) {
			update_user_meta( $user_id, self::meta_key(), $phone );
		}
	}

	public static function taken_by_other( $phone, $user_id ) {
		$ids = get_users(
			array(
				'meta_key'   => self::meta_key(), // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value' => $phone, // phpcs:ignore WordPress.DB.SlowDBQuery
				'exclude'    => array( (int) $user_id ),
				'number'     => 1,
				'fields'     => 'ID',
			)
		);
		return ! empty( $ids );
	}

	public static function users_column( $columns ) {
		$columns['shainika_mobile'] = 'موبایل';
		return $columns;
	}

	public static function users_column_value( $output, $column, $user_id ) {
		if ( 'shainika_mobile' !== $column ) {
			return $output;
		}
		$mobile = (string) get_user_meta( $user_id, self::meta_key(), true );
		return '' !== $mobile ? '<span dir="ltr">' . esc_html( $mobile ) . '</span>' : '—';
	}
}
