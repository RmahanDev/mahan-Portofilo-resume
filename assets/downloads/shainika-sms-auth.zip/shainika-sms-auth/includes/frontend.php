<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shainika_SMS_Frontend {

	public static function init() {
		add_shortcode( 'shainika_sms_auth', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_footer', array( __CLASS__, 'modal' ) );

		// wp-login.php.
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'login_assets' ) );
		add_filter( 'login_message', array( __CLASS__, 'login_box' ) );

		if ( ! shainika_sms_has_wc() ) {
			return;
		}
		$myaccount = Shainika_SMS_Settings::get( 'wc_myaccount' );
		if ( 'replace' === $myaccount ) {
			add_filter( 'wc_get_template', array( __CLASS__, 'swap_login_template' ), 20, 2 );
		} elseif ( 'above' === $myaccount ) {
			add_action( 'woocommerce_before_customer_login_form', array( __CLASS__, 'account_box' ) );
		}
		if ( Shainika_SMS_Settings::get( 'wc_checkout' ) ) {
			// Classic checkout: replace the "returning customer" toggle with our box.
			add_action( 'wp_loaded', array( __CLASS__, 'detach_checkout_login' ) );
			add_action( 'woocommerce_before_checkout_form', array( __CLASS__, 'checkout_box' ), 5 );
			add_filter( 'woocommerce_checkout_must_be_logged_in_message', array( __CLASS__, 'must_login_message' ) );
			// Block checkout.
			add_filter( 'render_block_woocommerce/checkout', array( __CLASS__, 'checkout_block' ), 10, 1 );
		}
	}

	private static function active() {
		return ! is_user_logged_in();
	}

	/** Script config + styles, shared by the front end and wp-login.php. */
	private static function enqueue() {
		$s = Shainika_SMS_Settings::all();

		wp_enqueue_style( 'shainika-sms-auth', SHAINIKA_SMS_URL . 'assets/css/auth.css', array(), SHAINIKA_SMS_VERSION . '.' . filemtime( SHAINIKA_SMS_DIR . 'assets/css/auth.css' ) );
		wp_add_inline_style( 'shainika-sms-auth', '.ssa-card,.ssa-auth,.ssa-modal{' . Shainika_SMS_Settings::css_vars( $s ) . '}' );

		wp_enqueue_script( 'shainika-sms-auth', SHAINIKA_SMS_URL . 'assets/js/auth.js', array(), SHAINIKA_SMS_VERSION . '.' . filemtime( SHAINIKA_SMS_DIR . 'assets/js/auth.js' ), true );

		$fields   = Shainika_SMS_Fields::enabled();
		$accounts = array();
		if ( $s['intercept_account_links'] ) {
			$accounts[] = wp_login_url();
			if ( shainika_sms_has_wc() ) {
				$accounts[] = wc_get_page_permalink( 'myaccount' );
			}
		}
		// wp_json_encode keeps booleans and numbers typed (wp_localize_script would turn them into strings).
		$config = array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'codeLength'  => (int) $s['code_length'],
			'fields'      => (object) $fields,
			'register'    => (bool) $s['registration'],
			'mapKey'      => isset( $fields['map'] ) ? $s['neshan_map_key'] : '',
			'hasReverse'  => isset( $fields['map'] ) && (bool) Shainika_SMS_Settings::get( 'neshan_service_key' ),
			'center'      => array( (float) $s['map_lng'], (float) $s['map_lat'] ),
			'zoom'        => (int) $s['map_zoom'],
			'triggers'    => (string) $s['modal_selector'],
			'accountUrls' => array_values( array_filter( $accounts ) ),
			'passwordUrl' => $s['password_link'] ? wp_login_url() : '',
		);
		wp_add_inline_script( 'shainika-sms-auth', 'var ShainikaSMS = ' . wp_json_encode( apply_filters( 'shainika_sms_js_config', $config ) ) . ';', 'before' );
	}

	public static function assets() {
		if ( self::active() ) {
			self::enqueue();
		}
	}

	public static function login_assets() {
		if ( self::active() && Shainika_SMS_Settings::get( 'wp_login' ) && self::is_plain_login() ) {
			self::enqueue();
		}
	}

	/** The bare widget. JavaScript renders the steps inside it. */
	private static function widget( $redirect = '', $context = '' ) {
		return '<div class="ssa-auth" data-redirect="' . esc_attr( $redirect ) . '" data-context="' . esc_attr( $context ) . '">'
			. '<noscript>برای ورود با پیامک، جاوااسکریپت مرورگر را فعال کنید.</noscript></div>';
	}

	/** Widget inside a card with an optional title. */
	public static function card( $redirect = '', $title = null, $context = '' ) {
		$title = null === $title ? (string) Shainika_SMS_Settings::get( 'title' ) : (string) $title;
		$html  = '<div class="ssa-card' . ( $context ? ' ssa-card--' . esc_attr( $context ) : '' ) . '">';
		if ( '' !== $title ) {
			$html .= '<h2 class="ssa-title">' . esc_html( $title ) . '</h2>';
		}
		return $html . self::widget( $redirect, $context ) . '</div>';
	}

	/**
	 * [shainika_sms_auth]                      card with the default title
	 * [shainika_sms_auth title=""]             without title
	 * [shainika_sms_auth redirect="https://…"] where to go after login
	 */
	public static function shortcode( $atts ) {
		if ( ! self::active() ) {
			return '';
		}
		$atts = shortcode_atts(
			array(
				'redirect' => '',
				'title'    => (string) Shainika_SMS_Settings::get( 'title' ),
			),
			$atts,
			'shainika_sms_auth'
		);
		return self::card( esc_url_raw( $atts['redirect'] ), $atts['title'], 'shortcode' );
	}

	public static function modal() {
		if ( ! self::active() ) {
			return;
		}
		$title = (string) Shainika_SMS_Settings::get( 'title' );
		echo '<div class="ssa-modal" hidden>'
			. '<div class="ssa-backdrop" data-ssa-close></div>'
			. '<div class="ssa-dialog" role="dialog" aria-modal="true" aria-label="' . esc_attr( $title ) . '">'
			. '<button type="button" class="ssa-close" data-ssa-close aria-label="بستن">&times;</button>'
			. ( '' !== $title ? '<h2 class="ssa-title">' . esc_html( $title ) . '</h2>' : '' )
			. self::widget( '', 'modal' ) // phpcs:ignore WordPress.Security.EscapeOutput
			. '</div></div>';
	}

	/* ---------- wp-login.php ---------- */

	/** Only the normal login screen (not register, lost password, reauth popups…). */
	private static function is_plain_login() {
		// phpcs:disable WordPress.Security.NonceVerification
		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : 'login';
		return in_array( $action, array( 'login', '' ), true ) && empty( $_REQUEST['interim-login'] );
		// phpcs:enable
	}

	public static function login_box( $message ) {
		if ( ! self::active() || ! Shainika_SMS_Settings::get( 'wp_login' ) || ! self::is_plain_login() ) {
			return $message;
		}
		$redirect = isset( $_REQUEST['redirect_to'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ), '' ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		return $message . self::card( $redirect, null, 'wp-login' )
			. '<p class="ssa-sep"><span>یا با نام کاربری و رمز عبور</span></p>';
	}

	/* ---------- WooCommerce ---------- */

	public static function swap_login_template( $template, $name ) {
		if ( 'myaccount/form-login.php' === $name && self::active() ) {
			$theme = locate_template( 'shainika-sms-auth/form-login.php' );
			return $theme ? $theme : SHAINIKA_SMS_DIR . 'templates/form-login.php';
		}
		return $template;
	}

	public static function account_box() {
		if ( self::active() ) {
			echo self::card( '', null, 'account' ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	public static function detach_checkout_login() {
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
	}

	private static function checkout_card() {
		return self::card( wc_get_checkout_url(), 'ورود یا ثبت‌نام برای ادامه‌ی خرید', 'checkout' );
	}

	public static function checkout_box() {
		if ( ! self::active() || is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) {
			return;
		}
		echo self::checkout_card(); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/** WooCommerce escapes this message, so it stays plain text; the box itself is printed just above it. */
	public static function must_login_message( $message ) {
		return self::active() ? 'برای ادامه‌ی خرید، ابتدا با شماره موبایل خود وارد شوید.' : $message;
	}

	public static function checkout_block( $content ) {
		if ( ! self::active() || is_admin() || ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url() ) ) {
			return $content;
		}
		return self::checkout_card() . $content;
	}
}
