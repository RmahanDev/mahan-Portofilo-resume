<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shainika_SMS_Admin {

	const PAGE = 'shainika-sms-auth';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_post_shainika_sms_test', array( __CLASS__, 'test_send' ) );
		add_action( 'admin_notices', array( __CLASS__, 'test_mode_notice' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( SHAINIKA_SMS_FILE ), array( __CLASS__, 'links' ) );
	}

	private static function url() {
		return admin_url( 'options-general.php?page=' . self::PAGE );
	}

	public static function links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">تنظیمات</a>' );
		return $links;
	}

	public static function menu() {
		add_options_page( 'ورود پیامکی', 'ورود پیامکی', 'manage_options', self::PAGE, array( __CLASS__, 'render' ) );
	}

	public static function assets( $hook ) {
		if ( 'settings_page_' . self::PAGE !== $hook ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'shainika-sms-auth', SHAINIKA_SMS_URL . 'assets/css/auth.css', array(), SHAINIKA_SMS_VERSION . '.' . filemtime( SHAINIKA_SMS_DIR . 'assets/css/auth.css' ) );
		wp_enqueue_script( 'shainika-sms-admin', SHAINIKA_SMS_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker' ), SHAINIKA_SMS_VERSION . '.' . filemtime( SHAINIKA_SMS_DIR . 'assets/js/admin.js' ), true );
	}

	public static function register() {
		register_setting(
			'shainika_sms_group',
			Shainika_SMS_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'Shainika_SMS_Settings', 'sanitize' ),
			)
		);
	}

	/** Reminds admins on other screens that visitors cannot receive codes yet. */
	public static function test_mode_notice() {
		if ( ! current_user_can( 'manage_options' ) || Shainika_SMS_Settings::is_live() ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && 'settings_page_' . self::PAGE === $screen->id ) {
			return;
		}
		echo '<div class="notice notice-warning"><p><strong>ورود پیامکی در حالت آزمایشی است</strong> و برای بازدیدکننده‌ها پیامکی ارسال نمی‌شود. <a href="' . esc_url( self::url() ) . '">تکمیل تنظیمات</a></p></div>';
	}

	/** Sends one real SMS with the selected provider, even in test mode, so credentials can be checked before going live. */
	public static function test_send() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		check_admin_referer( 'shainika_sms_test' );

		$phone    = Shainika_SMS_OTP::normalize_phone( isset( $_POST['test_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['test_phone'] ) ) : '' );
		$provider = Shainika_SMS_Sender::current();
		$creds    = $provider ? Shainika_SMS_Sender::credentials( $provider ) : array();

		if ( ! $phone ) {
			$msg = array( 'error', 'شماره موبایل معتبر نیست.' );
		} elseif ( ! $provider || ! $provider->is_configured( $creds ) ) {
			$msg = array( 'error', 'اطلاعات سرویس «' . ( $provider ? $provider->label() : '' ) . '» کامل نیست. فیلدهای ستاره‌دار را پر و ذخیره کنید.' );
		} else {
			$res = $provider->send( $phone, Shainika_SMS_OTP::random_code( (int) Shainika_SMS_Settings::get( 'code_length' ) ), $creds );
			if ( ! empty( $res['ok'] ) ) {
				$msg = array( 'success', 'پیامک آزمایشی با ' . $provider->label() . ' ارسال شد (شناسه: ' . $res['ref'] . '). اگر رسید، حالت را روی «فعال» بگذارید.' );
			} else {
				$msg = array( 'error', 'ارسال ناموفق: ' . $provider->error_label( isset( $res['error'] ) ? $res['error'] : '', isset( $res['message'] ) ? $res['message'] : '' ) );
			}
		}
		set_transient( 'shainika_sms_admin_notice_' . get_current_user_id(), $msg, 60 );
		wp_safe_redirect( self::url() . '#ssa-test' );
		exit;
	}

	private static function mask( $phone ) {
		return substr( $phone, 0, 4 ) . '***' . substr( $phone, -4 );
	}

	private static function name( $key ) {
		return Shainika_SMS_Settings::OPTION . '[' . $key . ']';
	}

	private static function row( $label, $html, $desc = '', $for = '' ) {
		echo '<tr><th scope="row">' . ( $for ? '<label for="' . esc_attr( $for ) . '">' . esc_html( $label ) . '</label>' : esc_html( $label ) ) . '</th><td>';
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $desc ) {
			echo '<p class="description">' . wp_kses_post( $desc ) . '</p>';
		}
		echo '</td></tr>';
	}

	private static function input( $key, $label, $value, $type = 'text', $desc = '', $extra = '' ) {
		$id = 'ssa_' . $key;
		self::row(
			$label,
			'<input id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( $value ) . '" class="' . ( 'number' === $type ? 'small-text' : 'regular-text' ) . '" dir="ltr" ' . $extra . ' />',
			$desc,
			$id
		);
	}

	private static function checkbox( $key, $label, $checked, $text, $desc = '' ) {
		self::row(
			$label,
			'<input type="hidden" name="' . esc_attr( self::name( '_checkboxes' ) ) . '[]" value="' . esc_attr( $key ) . '" />'
			. '<label><input type="checkbox" name="' . esc_attr( self::name( $key ) ) . '" value="1"' . checked( (bool) $checked, true, false ) . ' /> ' . esc_html( $text ) . '</label>',
			$desc
		);
	}

	private static function select( $key, $label, $value, $options, $desc = '' ) {
		$html = '<select id="ssa_' . esc_attr( $key ) . '" name="' . esc_attr( self::name( $key ) ) . '">';
		foreach ( $options as $k => $text ) {
			$html .= '<option value="' . esc_attr( $k ) . '"' . selected( (string) $value, (string) $k, false ) . '>' . esc_html( $text ) . '</option>';
		}
		self::row( $label, $html . '</select>', $desc, 'ssa_' . $key );
	}

	private static function provider_rows( Shainika_SMS_Provider $provider, $selected ) {
		$pid = $provider->id();
		foreach ( $provider->fields() as $key => $field ) {
			$id       = 'ssa_' . $pid . '_' . $key;
			$name     = self::name( 'creds' ) . '[' . $pid . '][' . $key . ']';
			$const    = Shainika_SMS_Settings::cred_constant( $pid, $key );
			$secret   = ! empty( $field['secret'] );
			$default  = isset( $field['default'] ) ? $field['default'] : '';
			$value    = Shainika_SMS_Settings::cred( $pid, $key, $default );
			$label    = $field['label'] . ( ! empty( $field['required'] ) ? ' *' : '' );
			$desc     = isset( $field['desc'] ) ? $field['desc'] : '';
			$attrs    = 'dir="ltr" class="regular-text"';
			if ( ! empty( $field['placeholder'] ) ) {
				$attrs .= ' placeholder="' . esc_attr( $field['placeholder'] ) . '"';
			}

			if ( defined( $const ) ) {
				$input = '<input id="' . esc_attr( $id ) . '" type="text" value="' . esc_attr( $secret ? '••••••••' : $value ) . '" ' . $attrs . ' disabled />';
				$desc  = 'از ثابت <code>' . esc_html( $const ) . '</code> در wp-config.php خوانده می‌شود.';
			} elseif ( $secret ) {
				$input = '<input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" type="password" value="" autocomplete="new-password" ' . $attrs . ( '' !== $value ? ' placeholder="••••••••"' : '' ) . ' />';
				$desc .= ( $desc ? ' ' : '' ) . ( '' !== $value ? 'ثبت شده؛ برای حفظ مقدار فعلی خالی بگذارید.' : '' );
				$desc .= ' یا در wp-config.php: <code>define( \'' . esc_html( $const ) . '\', \'...\' );</code>';
			} else {
				$input = '<input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" type="text" value="' . esc_attr( $value ) . '" ' . $attrs . ' />';
			}

			echo '<tr class="ssa-provider-row" data-ssa-provider="' . esc_attr( $pid ) . '"' . ( $pid !== $selected ? ' hidden' : '' ) . '><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label></th><td>';
			echo $input; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( $desc ) {
				echo '<p class="description">' . wp_kses_post( $desc ) . '</p>';
			}
			echo '</td></tr>';
		}
		$help = $provider->help();
		if ( $help ) {
			echo '<tr class="ssa-provider-row" data-ssa-provider="' . esc_attr( $pid ) . '"' . ( $pid !== $selected ? ' hidden' : '' ) . '><th scope="row">راهنمای الگو</th><td><p class="description">' . wp_kses_post( $help ) . '</p></td></tr>';
		}
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		$s         = Shainika_SMS_Settings::all();
		$providers = Shainika_SMS_Sender::providers();
		$current   = Shainika_SMS_Sender::current();
		$has_wc    = shainika_sms_has_wc();

		echo '<div class="wrap ssa-admin" dir="rtl"><h1>ورود و ثبت‌نام با پیامک</h1>';
		echo '<style>.ssa-admin .ssa-nav{display:flex;flex-wrap:wrap;gap:6px 16px;margin:12px 0 4px}.ssa-admin h2:not(.ssa-title){margin-top:32px;padding-top:12px;border-top:1px solid #dcdcde}.ssa-admin .ssa-fields td,.ssa-admin .ssa-fields th{padding:6px 10px}.ssa-admin code{direction:ltr;unicode-bidi:embed}.ssa-admin .ssa-credit{margin-top:40px;color:#646970}.ssa-admin .ssa-look{display:flex;gap:32px;align-items:flex-start;flex-wrap:wrap}.ssa-admin .ssa-look-fields{flex:1 1 520px;min-width:0}.ssa-admin .ssa-look-preview{flex:0 1 400px;position:sticky;top:48px;padding:20px;background:#f0f0f1;border-radius:8px}.ssa-admin .ssa-look-label{margin:0 0 12px;font-weight:600}.ssa-admin .ssa-preview{margin:0;max-width:none}.ssa-admin .ssa-preview .ssa-title{font-size:20px}</style>';

		$notice = get_transient( 'shainika_sms_admin_notice_' . get_current_user_id() );
		if ( $notice ) {
			delete_transient( 'shainika_sms_admin_notice_' . get_current_user_id() );
			echo '<div class="notice notice-' . esc_attr( $notice[0] ) . '"><p>' . esc_html( $notice[1] ) . '</p></div>';
		}

		if ( Shainika_SMS_Settings::is_live() ) {
			echo '<div class="notice notice-success inline"><p><strong>وضعیت: فعال.</strong> کدها با ' . esc_html( $current->label() ) . ' پیامک می‌شوند.</p></div>';
		} elseif ( 'live' === $s['mode'] ) {
			echo '<div class="notice notice-error inline"><p><strong>وضعیت: آزمایشی.</strong> حالت روی «فعال» است اما اطلاعات سرویس «' . esc_html( $current ? $current->label() : '' ) . '» کامل نیست، پس هنوز پیامکی ارسال نمی‌شود.</p></div>';
		} else {
			echo '<div class="notice notice-warning inline"><p><strong>وضعیت: آزمایشی.</strong> پیامکی ارسال نمی‌شود و کدها در بخش «کدهای آزمایشی» همین صفحه نمایش داده می‌شوند.</p></div>';
		}

		echo '<p class="ssa-nav"><a href="#ssa-sms">سرویس پیامک</a><a href="#ssa-limits">کد و محدودیت‌ها</a><a href="#ssa-accounts">حساب‌ها و فیلدها</a><a href="#ssa-map">نقشه</a><a href="#ssa-place">محل نمایش</a><a href="#ssa-look">ظاهر</a><a href="#ssa-test">ارسال آزمایشی</a><a href="#ssa-help">راهنما</a></p>';

		echo '<form method="post" action="options.php">';
		settings_fields( 'shainika_sms_group' );

		/* SMS */
		echo '<h2 id="ssa-sms">سرویس پیامک</h2><table class="form-table" role="presentation">';
		self::select( 'mode', 'حالت', $s['mode'], array( 'test' => 'آزمایشی (پیامکی ارسال نمی‌شود)', 'live' => 'فعال (ارسال واقعی)' ) );
		$options = array();
		foreach ( $providers as $pid => $provider ) {
			$options[ $pid ] = $provider->label();
		}
		self::select( 'provider', 'سرویس‌دهنده', $current ? $current->id() : '', $options, 'برای ورود فقط از «الگو / پترن / وریفای» استفاده می‌شود؛ این پیامک‌ها از لیست سیاه مخابرات عبور می‌کنند و سریع می‌رسند.' );
		foreach ( $providers as $provider ) {
			self::provider_rows( $provider, $current ? $current->id() : '' );
		}
		echo '</table>';

		/* Limits */
		echo '<h2 id="ssa-limits">کد و محدودیت‌ها</h2><table class="form-table" role="presentation">';
		self::input( 'code_length', 'طول کد', $s['code_length'], 'number', 'بین ۴ تا ۸ رقم.', 'min="4" max="8"' );
		self::input( 'code_ttl', 'اعتبار کد (ثانیه)', $s['code_ttl'], 'number', '', 'min="60" max="900"' );
		self::input( 'resend_cooldown', 'فاصله‌ی دو ارسال (ثانیه)', $s['resend_cooldown'], 'number', '', 'min="30" max="600"' );
		self::input( 'max_sends_phone', 'حداکثر ارسال برای هر شماره', $s['max_sends_phone'], 'number', 'در بازه‌ی زمانی ردیف بعد.', 'min="1" max="20"' );
		self::input( 'send_window', 'بازه‌ی محدودیت (ثانیه)', $s['send_window'], 'number', 'پیش‌فرض ۶۰۰، یعنی ۳ ارسال در ۱۰ دقیقه.', 'min="60" max="3600"' );
		self::input( 'max_sends_day', 'سقف روزانه‌ی هر شماره', $s['max_sends_day'], 'number', '', 'min="1" max="100"' );
		self::input( 'max_sends_ip_hour', 'سقف ساعتی هر IP', $s['max_sends_ip_hour'], 'number', 'جلوی ارسال انبوه به شماره‌های مختلف از یک شبکه را می‌گیرد.', 'min="1" max="500"' );
		self::input( 'max_sends_total_hour', 'سقف ساعتی کل سایت', $s['max_sends_total_hour'], 'number', 'حداکثر تعداد پیامک ورود در یک ساعت برای همه‌ی بازدیدکننده‌ها؛ جلوی خالی شدن اعتبار پنل در حمله از IPهای زیاد را می‌گیرد.', 'min="10" max="100000"' );
		self::input( 'max_attempts', 'حداکثر تلاش برای هر کد', $s['max_attempts'], 'number', '', 'min="3" max="10"' );
		self::select( 'ip_source', 'تشخیص IP بازدیدکننده', $s['ip_source'], Shainika_SMS_Settings::ip_sources(), 'فقط اگر سایت واقعاً پشت همین CDN یا پروکسی است گزینه‌ای غیر از REMOTE_ADDR را انتخاب کنید؛ وگرنه هر کسی می‌تواند با جعل هدر، محدودیت IP را دور بزند.' );
		echo '</table>';

		/* Accounts */
		echo '<h2 id="ssa-accounts">حساب‌ها و فیلدهای ثبت‌نام</h2><table class="form-table" role="presentation">';
		self::checkbox( 'registration', 'ثبت‌نام با پیامک', $s['registration'], 'شماره‌های جدید حساب کاربری بسازند', 'اگر خاموش باشد فقط کاربرانی که شماره‌شان ثبت شده وارد می‌شوند و به شماره‌های ناشناس پیامکی ارسال نمی‌شود.' );

		$safe = array();
		foreach ( wp_roles()->roles as $slug => $role ) {
			if ( Shainika_SMS_Settings::role_is_safe( $slug ) ) {
				$safe[ $slug ] = translate_user_role( $role['name'] );
			}
		}
		$auto      = ( $has_wc && get_role( 'customer' ) ) ? 'customer' : (string) get_option( 'default_role', 'subscriber' );
		$auto_name = isset( wp_roles()->roles[ $auto ] ) ? translate_user_role( wp_roles()->roles[ $auto ]['name'] ) : $auto;
		self::select( 'new_user_role', 'نقش کاربر جدید', $s['new_user_role'], array( '' => 'خودکار (' . $auto_name . ')' ) + $safe, 'نقش کاربر جدید همیشه به «نقش‌های مجاز» اضافه می‌شود تا دفعه‌ی بعد هم بتواند وارد شود.' );

		$roles_html = '';
		foreach ( wp_roles()->roles as $slug => $role ) {
			$is_safe     = isset( $safe[ $slug ] );
			$roles_html .= '<label style="display:inline-block;margin-left:16px;' . ( $is_safe ? '' : 'opacity:.55' ) . '"><input type="checkbox" name="' . esc_attr( self::name( 'allowed_roles' ) ) . '[]" value="' . esc_attr( $slug ) . '"' . checked( $is_safe && in_array( $slug, (array) $s['allowed_roles'], true ), true, false ) . disabled( ! $is_safe, true, false ) . ' /> ' . esc_html( translate_user_role( $role['name'] ) ) . '</label>';
		}
		self::row( 'نقش‌های مجاز برای ورود پیامکی', $roles_html, 'نقش‌هایی که به مدیریت سایت دسترسی دارند (مدیر، ویرایشگر، مدیر فروشگاه و…) برای امنیت هیچ‌وقت با پیامک وارد نمی‌شوند و فقط از wp-login.php با رمز عبور وارد می‌شوند.' );

		$states = array( 'off' => 'نمایش داده نشود', 'optional' => 'اختیاری', 'required' => 'الزامی' );
		$fhtml  = '<table class="ssa-fields widefat striped" style="max-width:520px"><tbody>';
		foreach ( Shainika_SMS_Fields::labels() as $key => $label ) {
			$fhtml .= '<tr><th>' . esc_html( $label ) . '</th><td><select name="' . esc_attr( self::name( 'fields' ) ) . '[' . esc_attr( $key ) . ']">';
			foreach ( $states as $k => $text ) {
				$fhtml .= '<option value="' . esc_attr( $k ) . '"' . selected( $s['fields'][ $key ], $k, false ) . '>' . esc_html( $text ) . '</option>';
			}
			$fhtml .= '</select></td></tr>';
		}
		$fhtml .= '</tbody></table>';
		self::row( 'فیلدهای مرحله‌ی ثبت‌نام', $fhtml, 'بعد از تایید شماره‌ی جدید پرسیده می‌شوند. اگر همه «نمایش داده نشود» باشند، حساب بلافاصله بعد از تایید کد ساخته می‌شود. نقشه فقط وقتی نمایش داده می‌شود که کلید نقشه‌ی نشان وارد شده باشد.' . ( $has_wc ? ' نام، آدرس و کد پستی در اطلاعات صورت‌حساب و ارسال ووکامرس هم ذخیره می‌شوند.' : '' ) );

		self::input( 'legacy_meta_keys', 'شناسایی کاربران قدیمی', $s['legacy_meta_keys'], 'text', 'متاکی‌هایی که شماره‌ی موبایل کاربران فعلی سایت در آن‌ها ذخیره شده، با کاما. مثلاً <code>billing_phone</code> (ووکامرس) یا <code>digits_phone_no</code>. کاربری که شماره‌اش آن‌جا پیدا شود، بعد از تایید کد وارد همان حساب می‌شود. <strong>هشدار:</strong> این فیلدها معمولاً تاییدنشده‌اند؛ فقط وقتی فعال کنید که به درستی‌شان اطمینان دارید.' );
		echo '</table>';

		/* Map */
		echo '<h2 id="ssa-map">نقشه‌ی نشان</h2><table class="form-table" role="presentation">';
		self::input( 'neshan_map_key', 'کلید نقشه (Web)', $s['neshan_map_key'], 'text', 'از <a href="https://platform.neshan.org" target="_blank" rel="noopener">platform.neshan.org</a> یک کلید نوع «Web» بسازید و دامنه‌ی سایت را برایش مجاز کنید. برای نمایش نقشه، فیلد «موقعیت روی نقشه» را هم در بخش قبل روشن کنید.' );
		$svc = Shainika_SMS_Settings::get( 'neshan_service_key' );
		if ( defined( 'SHAINIKA_SMS_NESHAN_SERVICE_KEY' ) ) {
			self::row( 'کلید سرویس (اختیاری)', '<input type="text" value="••••••••" class="regular-text" dir="ltr" disabled />', 'از ثابت <code>SHAINIKA_SMS_NESHAN_SERVICE_KEY</code> در wp-config.php خوانده می‌شود.' );
		} else {
			self::row(
				'کلید سرویس (اختیاری)',
				'<input id="ssa_neshan_service_key" name="' . esc_attr( self::name( 'neshan_service_key' ) ) . '" type="password" value="" class="regular-text" dir="ltr" autocomplete="new-password"' . ( $svc ? ' placeholder="••••••••"' : '' ) . ' />'
				. ( $svc ? ' <label><input type="checkbox" name="' . esc_attr( self::name( 'neshan_service_key_clear' ) ) . '" value="1" /> حذف کلید</label>' : '' ),
				'برای پر شدن خودکار آدرس متنی بعد از انتخاب نقطه (Reverse Geocoding).' . ( $svc ? ' ثبت شده؛ برای حفظ آن خالی بگذارید.' : '' ),
				'ssa_neshan_service_key'
			);
		}
		self::input( 'map_lat', 'عرض جغرافیایی مرکز نقشه', $s['map_lat'] );
		self::input( 'map_lng', 'طول جغرافیایی مرکز نقشه', $s['map_lng'], 'text', 'پیش‌فرض: تهران.' );
		self::input( 'map_zoom', 'زوم اولیه', $s['map_zoom'], 'number', '', 'min="4" max="19"' );
		echo '</table>';

		/* Placement */
		echo '<h2 id="ssa-place">محل نمایش</h2><table class="form-table" role="presentation">';
		if ( $has_wc ) {
			self::select(
				'wc_myaccount',
				'صفحه‌ی «حساب کاربری من» ووکامرس',
				$s['wc_myaccount'],
				array(
					'replace' => 'جایگزین فرم ورود/ثبت‌نام ووکامرس',
					'above'   => 'بالای فرم ورود ووکامرس (هر دو نمایش داده شوند)',
					'off'     => 'نمایش داده نشود',
				)
			);
			self::checkbox( 'wc_checkout', 'صفحه‌ی تسویه‌حساب', $s['wc_checkout'], 'کادر ورود پیامکی برای مهمان‌ها نمایش داده شود', 'هم در تسویه‌حساب کلاسیک و هم بلوکی. پیام «مشتری قبلی هستید؟» ووکامرس حذف می‌شود.' );
		} else {
			self::row( 'ووکامرس', '<p class="description" style="margin:0">ووکامرس فعال نیست. با فعال شدنش، گزینه‌های «حساب کاربری من» و «تسویه‌حساب» این‌جا اضافه می‌شوند.</p>' );
		}
		self::checkbox( 'wp_login', 'صفحه‌ی ورود وردپرس', $s['wp_login'], 'کادر ورود پیامکی بالای فرم wp-login.php نمایش داده شود' );
		self::checkbox( 'password_link', 'لینک ورود با رمز', $s['password_link'], 'زیر فرم پیامکی لینک «ورود با نام کاربری و رمز عبور» نمایش داده شود' );
		self::input( 'modal_selector', 'باز کردن پاپ‌آپ با کلیک روی', $s['modal_selector'], 'text', 'انتخاب‌گر CSS، با کاما. پیش‌فرض: هر آیتم منو با کلاس <code>ssa-open</code> و هر لینک به <code>#sms-login</code>. برای آیکون حساب قالب‌ها هم می‌توانید انتخاب‌گرش را اضافه کنید (مثلاً در Woodmart: <code>.login-side-opener &gt; a</code>).' );
		self::checkbox( 'intercept_account_links', 'لینک‌های ورود قالب', $s['intercept_account_links'], 'کلیک مهمان روی لینک‌های ' . ( $has_wc ? '«حساب کاربری من» و ' : '' ) . 'wp-login.php به‌جای رفتن به آن صفحه، پاپ‌آپ را باز کند', 'برای بیشتر قالب‌ها بدون نیاز به انتخاب‌گر CSS کار می‌کند.' );
		self::input( 'redirect_after', 'آدرس انتقال بعد از ورود', $s['redirect_after'], 'url', 'خالی = همان صفحه‌ای که کاربر در آن بود (یا مقصد شورت‌کد).' );
		echo '</table>';

		/* Appearance */
		echo '<h2 id="ssa-look">ظاهر فرم ورود</h2>';
		echo '<p class="description">رنگ‌ها روی همه‌ی فرم‌ها اعمال می‌شوند: پاپ‌آپ، شورت‌کد، حساب کاربری، تسویه‌حساب و صفحه‌ی ورود وردپرس. پیش‌نمایش با هر تغییر به‌روز می‌شود؛ برای اعمال روی سایت «ذخیره‌ی تنظیمات» را بزنید.</p>';
		echo '<div class="ssa-look"><div class="ssa-look-fields"><table class="form-table" role="presentation">';
		self::input( 'title', 'عنوان فرم', $s['title'], 'text', 'در پاپ‌آپ، حساب کاربری و شورت‌کد نمایش داده می‌شود.', 'dir="rtl"' );
		$d = Shainika_SMS_Settings::defaults();
		foreach ( Shainika_SMS_Settings::colors() as $key => $color ) {
			$id = 'ssa_' . $key;
			self::row(
				$color[0],
				'<input id="' . esc_attr( $id ) . '" name="' . esc_attr( self::name( $key ) ) . '" type="text" value="' . esc_attr( $s[ $key ] ) . '" class="ssa-color" data-default-color="' . esc_attr( $d[ $key ] ) . '" data-ssa-var="' . esc_attr( $color[1] ) . '" dir="ltr" />',
				$color[2],
				$id
			);
		}
		self::input( 'radius', 'گردی گوشه‌ها (px)', $s['radius'], 'number', '۰ برای گوشه‌های تیز.', 'min="0" max="24"' );
		self::row( 'بازنشانی', '<button type="button" class="button" id="ssa-reset-colors">بازگشت به رنگ‌های پیش‌فرض</button>', 'فقط فرم را تغییر می‌دهد؛ بعد از آن ذخیره کنید.' );
		echo '</table></div>';

		echo '<div class="ssa-look-preview"><p class="ssa-look-label">پیش‌نمایش</p>'
			. '<div class="ssa-card ssa-preview" id="ssa-preview" style="' . esc_attr( Shainika_SMS_Settings::css_vars( $s ) ) . '">'
			. '<h2 class="ssa-title"' . ( '' === $s['title'] ? ' hidden' : '' ) . '>' . esc_html( $s['title'] ) . '</h2>'
			. '<div class="ssa-auth"><div class="ssa-form">'
			. '<p class="ssa-lead">شماره موبایل خود را وارد کنید تا کد تایید برایتان پیامک شود.</p>'
			. '<div class="ssa-field"><label for="ssa-preview-phone">شماره موبایل</label><input id="ssa-preview-phone" type="tel" dir="ltr" placeholder="09123456789" value="0912" autocomplete="off" /></div>'
			. '<div class="ssa-error">نمونه‌ی پیام خطا: کد واردشده درست نیست.</div>'
			. '<button type="button" class="ssa-btn">ارسال کد تایید</button>'
			. '<div class="ssa-row"><button type="button" class="ssa-link">ارسال مجدد کد</button><button type="button" class="ssa-link">ویرایش شماره</button></div>'
			. '</div></div></div></div></div>';

		submit_button( 'ذخیره‌ی تنظیمات' );
		echo '</form>';

		/* Test send */
		echo '<h2 id="ssa-test">ارسال آزمایشی</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="shainika_sms_test" />';
		wp_nonce_field( 'shainika_sms_test' );
		echo '<input type="tel" name="test_phone" dir="ltr" placeholder="09123456789" class="regular-text" /> ';
		submit_button( 'ارسال یک پیامک واقعی', 'secondary', 'submit', false );
		echo '<p class="description">ابتدا تنظیمات را ذخیره کنید. این دکمه حتی در حالت آزمایشی با سرویس انتخاب‌شده یک پیامک واقعی می‌فرستد تا قبل از فعال کردن، درستی اطلاعات را بسنجید.</p></form>';

		if ( ! Shainika_SMS_Settings::is_live() ) {
			$codes = get_transient( 'shainika_sms_test_codes' );
			echo '<h2>کدهای آزمایشی</h2><p class="description">در حالت آزمایشی، کدهای درخواست‌شده در سایت به‌جای پیامک این‌جا نمایش داده می‌شوند (۱۵ دقیقه).</p>';
			if ( is_array( $codes ) && $codes ) {
				echo '<table class="widefat striped" style="max-width:520px"><thead><tr><th>زمان</th><th>شماره</th><th>کد</th></tr></thead><tbody>';
				foreach ( $codes as $c ) {
					echo '<tr><td>' . esc_html( wp_date( 'H:i:s', (int) $c['time'] ) ) . '</td><td dir="ltr" style="text-align:right">' . esc_html( $c['phone'] ) . '</td><td dir="ltr" style="text-align:right"><code>' . esc_html( $c['code'] ) . '</code></td></tr>';
				}
				echo '</tbody></table>';
			} else {
				echo '<p>هنوز کدی درخواست نشده است.</p>';
			}
		}

		$rows = $wpdb->get_results( 'SELECT phone, status, provider_ref, created_at FROM ' . Shainika_SMS_DB::table() . ' ORDER BY id DESC LIMIT 30' ); // phpcs:ignore WordPress.DB.PreparedSQL, WordPress.DB.DirectDatabaseQuery
		echo '<h2>۳۰ درخواست آخر</h2>';
		if ( ! $rows ) {
			echo '<p>هنوز درخواستی ثبت نشده است.</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:720px"><thead><tr><th>زمان</th><th>شماره</th><th>وضعیت</th><th>شناسه‌ی ارسال</th></tr></thead><tbody>';
			$labels = array(
				'pending'     => 'در انتظار تایید',
				'used'        => 'تایید شد',
				'superseded'  => 'جایگزین شد',
				'locked'      => 'قفل شد (تلاش زیاد)',
				'send_failed' => 'ارسال ناموفق',
			);
			foreach ( $rows as $r ) {
				echo '<tr><td>' . esc_html( wp_date( 'Y/m/d H:i:s', strtotime( $r->created_at . ' UTC' ) ) ) . '</td><td dir="ltr" style="text-align:right">' . esc_html( self::mask( $r->phone ) ) . '</td><td>' . esc_html( isset( $labels[ $r->status ] ) ? $labels[ $r->status ] : $r->status ) . '</td><td dir="ltr" style="text-align:right">' . esc_html( $r->provider_ref ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}

		/* Help */
		echo '<h2 id="ssa-help">راهنمای استفاده</h2><ul style="list-style:disc;padding-right:20px">';
		echo '<li>شورت‌کد در هر صفحه، ابزارک یا صفحه‌ساز (المنتور، WPBakery و…): <code>[shainika_sms_auth]</code> — با گزینه‌های <code>title=""</code> و <code>redirect="https://…"</code>.</li>';
		echo '<li>پاپ‌آپ: در «نمایش ← فهرست‌ها» به آیتم منو کلاس CSS <code>ssa-open</code> بدهید، یا یک لینک سفارشی با آدرس <code>#sms-login</code> بسازید.</li>';
		echo '<li>قالب صفحه‌ی حساب ووکامرس را می‌توانید با کپی <code>templates/form-login.php</code> به <code>yourtheme/shainika-sms-auth/form-login.php</code> شخصی کنید.</li>';
		echo '<li>برای اتصال سرویس پیامک دیگر یا تغییر رفتار، فیلترهای افزونه در README توضیح داده شده‌اند.</li>';
		echo '</ul>';

		echo '<p class="ssa-credit">ساخته شده توسط ماهان رضائی - <a href="https://co.shainika.com" target="_blank" rel="noopener">co.shainika.com</a></p>';
		echo '</div>';
	}
}
