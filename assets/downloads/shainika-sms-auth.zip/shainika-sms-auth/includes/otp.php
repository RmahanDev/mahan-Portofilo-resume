<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shainika_SMS_OTP {

	/** Converts Persian/Arabic digits to Latin. */
	public static function latin_digits( $str ) {
		$str = (string) $str;
		$fa  = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		$ar  = array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
		$str = str_replace( $fa, range( 0, 9 ), $str );
		return str_replace( $ar, range( 0, 9 ), $str );
	}

	/** Returns 09xxxxxxxxx or false. Accepts +98, 0098, 98 and 9xxxxxxxxx forms. */
	public static function normalize_phone( $raw ) {
		$p = preg_replace( '/[\s\-\(\)\.]/u', '', self::latin_digits( $raw ) );
		$p = preg_replace( '/^(\+98|0098|98)(?=9\d{9}$)/', '0', $p );
		if ( preg_match( '/^9\d{9}$/', $p ) ) {
			$p = '0' . $p;
		}
		$p = preg_match( '/^09\d{9}$/', $p ) ? $p : false;
		return apply_filters( 'shainika_sms_normalize_phone', $p, $raw );
	}

	public static function client_ip() {
		$source = (string) Shainika_SMS_Settings::get( 'ip_source' );
		$ip     = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$header = array(
			'cloudflare'      => 'HTTP_CF_CONNECTING_IP',
			'x_forwarded_for' => 'HTTP_X_FORWARDED_FOR',
			'x_real_ip'       => 'HTTP_X_REAL_IP',
		);
		if ( isset( $header[ $source ] ) && ! empty( $_SERVER[ $header[ $source ] ] ) ) {
			$parts     = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $header[ $source ] ] ) ) );
			$candidate = trim( $parts[0] );
			if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
				$ip = $candidate;
			}
		}
		$ip = apply_filters( 'shainika_sms_client_ip', $ip );
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	private static function hash( $phone, $code ) {
		return hash_hmac( 'sha256', $phone . '|' . $code, wp_salt( 'auth' ) );
	}

	public static function random_code( $length ) {
		return (string) random_int( (int) pow( 10, $length - 1 ), (int) pow( 10, $length ) - 1 );
	}

	private static function count_rows( $where_sql, $args ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Shainika_SMS_DB::table() . ' WHERE ' . $where_sql, $args ) );
	}

	/**
	 * Applies the rate limits, creates a code and sends it.
	 *
	 * @return array|WP_Error array( ttl, cooldown, length ) on success.
	 */
	public static function request( $phone, $ip ) {
		global $wpdb;
		$s     = Shainika_SMS_Settings::all();
		$table = Shainika_SMS_DB::table();
		$now   = time();

		// 1) Cooldown between two sends to the same number.
		$last = $wpdb->get_var( $wpdb->prepare( "SELECT created_at FROM {$table} WHERE phone = %s AND status <> 'send_failed' ORDER BY id DESC LIMIT 1", $phone ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( $last ) {
			$wait = (int) $s['resend_cooldown'] - ( $now - strtotime( $last . ' UTC' ) );
			if ( $wait > 0 ) {
				return new WP_Error( 'cooldown', sprintf( 'لطفاً %d ثانیه دیگر برای دریافت کد جدید صبر کنید.', $wait ), array( 'retry_after' => $wait ) );
			}
		}

		// 2) Per-number window (default: 3 sends / 10 minutes).
		$since = gmdate( 'Y-m-d H:i:s', $now - (int) $s['send_window'] );
		if ( self::count_rows( "phone = %s AND status <> 'send_failed' AND created_at >= %s", array( $phone, $since ) ) >= (int) $s['max_sends_phone'] ) {
			return new WP_Error( 'phone_limit', 'تعداد درخواست‌های این شماره زیاد بوده است. چند دقیقه بعد دوباره تلاش کنید.', array( 'retry_after' => (int) $s['send_window'] ) );
		}

		// 3) Per-number daily cap.
		$day = gmdate( 'Y-m-d H:i:s', $now - DAY_IN_SECONDS );
		if ( self::count_rows( "phone = %s AND status <> 'send_failed' AND created_at >= %s", array( $phone, $day ) ) >= (int) $s['max_sends_day'] ) {
			return new WP_Error( 'day_limit', 'سقف درخواست روزانه‌ی این شماره پر شده است. فردا دوباره تلاش کنید.' );
		}

		// 4) Per-IP hourly cap, which stops one visitor from spraying many numbers.
		$hour = gmdate( 'Y-m-d H:i:s', $now - HOUR_IN_SECONDS );
		if ( self::count_rows( "ip = %s AND status <> 'send_failed' AND created_at >= %s", array( $ip, $hour ) ) >= (int) $s['max_sends_ip_hour'] ) {
			return new WP_Error( 'ip_limit', 'درخواست‌های زیادی از شبکه‌ی شما ثبت شده است. کمی بعد دوباره تلاش کنید.' );
		}

		// 5) Site-wide hourly cap: limits the damage (SMS credit) of an attack spread over many IPs.
		if ( self::count_rows( "status <> 'send_failed' AND created_at >= %s", array( $hour ) ) >= (int) $s['max_sends_total_hour'] ) {
			error_log( '[shainika-sms] site-wide hourly SMS limit reached' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
			return new WP_Error( 'total_limit', 'ارسال کد موقتاً در دسترس نیست. چند دقیقه‌ی دیگر دوباره تلاش کنید.' );
		}

		$length = (int) $s['code_length'];
		$code   = self::random_code( $length );

		// Older pending codes of this number stop working as soon as a new one is issued.
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'superseded' WHERE phone = %s AND status = 'pending'", $phone ) ); // phpcs:ignore WordPress.DB.PreparedSQL

		$wpdb->insert(
			$table,
			array(
				'phone'      => $phone,
				'code_hash'  => self::hash( $phone, $code ),
				'ip'         => $ip,
				'attempts'   => 0,
				'status'     => 'pending',
				'created_at' => gmdate( 'Y-m-d H:i:s', $now ),
				'expires_at' => gmdate( 'Y-m-d H:i:s', $now + (int) $s['code_ttl'] ),
			)
		);
		$row_id = (int) $wpdb->insert_id;

		$result = Shainika_SMS_Sender::send_otp( $phone, $code );
		if ( ! $result['ok'] ) {
			$wpdb->update( $table, array( 'status' => 'send_failed' ), array( 'id' => $row_id ) );
			return new WP_Error( 'send_failed', 'ارسال پیامک با مشکل روبه‌رو شد. چند لحظه بعد دوباره تلاش کنید.' );
		}
		$wpdb->update( $table, array( 'provider_ref' => $result['ref'] ), array( 'id' => $row_id ) );

		return array(
			'ttl'      => (int) $s['code_ttl'],
			'cooldown' => (int) $s['resend_cooldown'],
			'length'   => $length,
		);
	}

	/** @return true|WP_Error */
	public static function verify( $phone, $code ) {
		global $wpdb;
		$table = Shainika_SMS_DB::table();
		$max   = (int) Shainika_SMS_Settings::get( 'max_attempts' );

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE phone = %s AND status = 'pending' AND expires_at > %s ORDER BY id DESC LIMIT 1", $phone, gmdate( 'Y-m-d H:i:s' ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( ! $row ) {
			return new WP_Error( 'expired', 'کد منقضی شده یا درخواست نشده است. کد جدید دریافت کنید.', array( 'expired' => true ) );
		}

		// Count the attempt first, so parallel guesses cannot exceed the limit.
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET attempts = attempts + 1 WHERE id = %d", $row->id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$attempts = (int) $wpdb->get_var( $wpdb->prepare( "SELECT attempts FROM {$table} WHERE id = %d", $row->id ) ); // phpcs:ignore WordPress.DB.PreparedSQL

		if ( $attempts > $max ) {
			$wpdb->update( $table, array( 'status' => 'locked' ), array( 'id' => $row->id ) );
			return new WP_Error( 'locked', 'تعداد تلاش‌های ناموفق زیاد بود. کد جدید دریافت کنید.', array( 'expired' => true ) );
		}

		if ( ! hash_equals( $row->code_hash, self::hash( $phone, $code ) ) ) {
			$left = $max - $attempts;
			if ( $left <= 0 ) {
				$wpdb->update( $table, array( 'status' => 'locked' ), array( 'id' => $row->id ) );
				return new WP_Error( 'locked', 'تعداد تلاش‌های ناموفق زیاد بود. کد جدید دریافت کنید.', array( 'expired' => true ) );
			}
			return new WP_Error( 'wrong_code', sprintf( 'کد واردشده درست نیست. %d تلاش دیگر باقی مانده است.', $left ) );
		}

		// Single use: only one request can flip pending -> used.
		$changed = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'used' WHERE id = %d AND status = 'pending'", $row->id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		if ( 1 !== (int) $changed ) {
			return new WP_Error( 'expired', 'این کد قبلاً استفاده شده است.', array( 'expired' => true ) );
		}
		return true;
	}
}
