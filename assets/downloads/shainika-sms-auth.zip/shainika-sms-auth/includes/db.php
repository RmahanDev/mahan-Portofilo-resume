<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shainika_SMS_DB {

	const DB_VERSION = '1';

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'shainika_sms_otp';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				phone varchar(20) NOT NULL,
				code_hash char(64) NOT NULL,
				ip varchar(45) NOT NULL DEFAULT '',
				attempts smallint(5) unsigned NOT NULL DEFAULT 0,
				status varchar(20) NOT NULL DEFAULT 'pending',
				provider_ref varchar(64) NOT NULL DEFAULT '',
				created_at datetime NOT NULL,
				expires_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY phone_created (phone,created_at),
				KEY ip_created (ip,created_at)
			) {$charset};"
		);

		update_option( 'shainika_sms_db_version', self::DB_VERSION );
		if ( ! wp_next_scheduled( 'shainika_sms_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'shainika_sms_cleanup' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'shainika_sms_cleanup' );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'shainika_sms_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
		add_action( 'shainika_sms_cleanup', array( __CLASS__, 'cleanup' ) );
		if ( ! wp_next_scheduled( 'shainika_sms_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'shainika_sms_cleanup' );
		}
	}

	/** Rows are only needed for rate limiting (24h), so older ones are removed. */
	public static function cleanup() {
		global $wpdb;
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS - HOUR_IN_SECONDS );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE created_at < %s', $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}
}
