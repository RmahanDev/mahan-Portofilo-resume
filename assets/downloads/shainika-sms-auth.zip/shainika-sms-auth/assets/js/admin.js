/* Shainika SMS Auth - settings page: provider fields + color pickers with live preview. */
(function ($) {
	'use strict';

	/* Only the selected provider's fields are shown. */
	var provider = document.getElementById('ssa_provider');
	function toggleProvider() {
		document.querySelectorAll('.ssa-provider-row').forEach(function (row) {
			row.hidden = row.getAttribute('data-ssa-provider') !== provider.value;
		});
	}
	if (provider) {
		provider.addEventListener('change', toggleProvider);
		toggleProvider();
	}

	/* Live preview. */
	var preview = document.getElementById('ssa-preview');

	function readableOn(hex) {
		var h = String(hex || '').replace('#', '');
		if (h.length === 3) { h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2]; }
		if (!/^[0-9a-f]{6}$/i.test(h)) { return '#ffffff'; }
		var lum = [0, 2, 4].reduce(function (sum, i, n) {
			var c = parseInt(h.substr(i, 2), 16) / 255;
			c = c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
			return sum + [0.2126, 0.7152, 0.0722][n] * c;
		}, 0);
		return (1.05 / (lum + 0.05)) >= ((lum + 0.05) / 0.0555) ? '#ffffff' : '#111111';
	}

	function apply() {
		if (!preview) { return; }
		$('.ssa-color').each(function () {
			var name = $(this).data('ssa-var');
			var val = $.trim($(this).val());
			if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(val)) {
				preview.style.setProperty(name, val);
			} else {
				preview.style.removeProperty(name);
			}
		});
		if (!/^#/.test($.trim($('#ssa_button_text').val()))) {
			preview.style.setProperty('--ssa-on-accent', readableOn($('#ssa_accent').val() || '#2271b1'));
		}
		var r = parseInt($('#ssa_radius').val(), 10);
		preview.style.setProperty('--ssa-radius', (isNaN(r) ? 8 : Math.max(0, Math.min(24, r))) + 'px');
		var title = $.trim($('#ssa_title').val());
		$(preview).find('.ssa-title').text(title).prop('hidden', !title);
	}

	if ($.fn.wpColorPicker) {
		$('.ssa-color').wpColorPicker({
			change: function (e, ui) {
				$(e.target).val(ui.color.toString());
				apply();
			},
			clear: function () { setTimeout(apply, 0); }
		});
	}
	$('#ssa_radius, #ssa_title').on('input change', apply);
	$('.ssa-color').on('input change', apply);

	$('#ssa-reset-colors').on('click', function () {
		$('.ssa-color').each(function () {
			var def = $(this).data('default-color') || '';
			if (def) {
				$(this).wpColorPicker('color', def);
			} else {
				$(this).closest('.wp-picker-container').find('.wp-picker-clear').trigger('click');
				$(this).val('');
			}
		});
		$('#ssa_radius').val(8);
		apply();
	});

	apply();
})(jQuery);
