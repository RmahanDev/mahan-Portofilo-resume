/* Shainika SMS Auth - front end. Vanilla JS, no dependencies. */
(function () {
	'use strict';

	var C = window.ShainikaSMS;
	if (!C) { return; }

	var FA = '۰۱۲۳۴۵۶۷۸۹';
	var AR = '٠١٢٣٤٥٦٧٨٩';
	var NESHAN_CSS = 'https://static.neshan.org/sdk/mapboxgl/v1.13.2/neshan-sdk/v1.1.5/index.css';
	var NESHAN_JS = 'https://static.neshan.org/sdk/mapboxgl/v1.13.2/neshan-sdk/v1.1.5/index.js';
	var FIELDS = C.fields || {};

	function latin(s) {
		return String(s)
			.replace(/[۰-۹]/g, function (d) { return FA.indexOf(d); })
			.replace(/[٠-٩]/g, function (d) { return AR.indexOf(d); });
	}
	function fa(n) {
		return String(n).replace(/\d/g, function (d) { return FA.charAt(d); });
	}
	function wait(ms) {
		return new Promise(function (res) { setTimeout(res, ms); });
	}
	function el(tag, attrs, kids) {
		var n = document.createElement(tag);
		Object.keys(attrs || {}).forEach(function (k) {
			var v = attrs[k];
			if (v === false || v === null || v === undefined) { return; }
			if (k === 'class') { n.className = v; }
			else if (k === 'text') { n.textContent = v; }
			else if (v === true) { n.setAttribute(k, ''); }
			else { n.setAttribute(k, v); }
		});
		(kids || []).forEach(function (c) { if (c) { n.appendChild(c); } });
		return n;
	}
	function errMsg(e) {
		return (e && e.data && e.data.message) || 'اتصال به سرور برقرار نشد. اینترنت خود را بررسی کنید.';
	}

	/* ---------- ajax + session (nonce/form token fetched on demand, so page caching cannot make them stale) ---------- */
	var session = null;
	var pending = null;

	function loadSession(force) {
		if (session && !force) { return Promise.resolve(session); }
		if (pending && !force) { return pending; }
		var fd = new FormData();
		fd.append('action', 'shainika_sms_init');
		pending = fetch(C.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store' })
			.then(function (r) { return r.json(); })
			.then(function (j) {
				pending = null;
				if (j && j.success && j.data && j.data.logged_in) { window.location.reload(); }
				if (j && j.success && j.data && j.data.nonce) { session = j.data; return session; }
				throw new Error('session');
			})
			.catch(function (e) { pending = null; throw e; });
		return pending;
	}

	function call(action, data, tries) {
		tries = (tries === undefined) ? 1 : tries;
		return loadSession().then(function (s) {
			var fd = new FormData();
			fd.append('action', 'shainika_sms_' + action);
			fd.append('nonce', s.nonce);
			fd.append('ft', s.ft);
			Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
			return fetch(C.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' });
		}).then(function (r) {
			return r.json().catch(function () {
				return { success: false, data: { code: 'bad_response', message: 'پاسخ نامعتبر از سرور دریافت شد.' } };
			});
		}).then(function (j) {
			if (j && j.success) { return j.data; }
			var d = (j && j.data) || { code: 'unknown', message: 'خطای ناشناخته.' };
			// Expired nonce or a form token that is too fresh: renew and retry once, silently.
			if (tries > 0 && (d.code === 'bad_nonce' || d.code === 'bad_token') && !d.restart) {
				return loadSession(true).then(function () { return wait(2300); }).then(function () {
					return call(action, data, tries - 1);
				});
			}
			var err = new Error(d.message || 'خطا');
			err.data = d;
			throw err;
		});
	}

	/* ---------- Neshan map ---------- */
	var neshanPromise = null;
	function loadNeshan() {
		if (window.nmp_mapboxgl) { return Promise.resolve(); }
		if (neshanPromise) { return neshanPromise; }
		neshanPromise = new Promise(function (resolve, reject) {
			document.head.appendChild(el('link', { rel: 'stylesheet', href: NESHAN_CSS }));
			var s = el('script', { src: NESHAN_JS, async: true });
			s.onload = resolve;
			s.onerror = function () { neshanPromise = null; reject(new Error('neshan')); };
			document.head.appendChild(s);
		});
		return neshanPromise;
	}

	function passwordHref(redirect) {
		if (!C.passwordUrl) { return ''; }
		try {
			var u = new URL(C.passwordUrl, window.location.href);
			u.searchParams.set('redirect_to', redirect || window.location.href.split('#')[0]);
			return u.toString();
		} catch (e) {
			return C.passwordUrl;
		}
	}

	/* ---------- widget ---------- */
	function Widget(root) {
		this.root = root;
		this.redirect = root.getAttribute('data-redirect') || '';
		this.context = root.getAttribute('data-context') || '';
		this.phone = '';
		this.token = '';
		this.timer = null;
		this.showPhone();
	}

	Widget.prototype.clear = function () {
		if (this.timer) { clearInterval(this.timer); this.timer = null; }
		while (this.root.firstChild) { this.root.removeChild(this.root.firstChild); }
	};

	Widget.prototype.busy = function (btn, on, label) {
		btn.disabled = !!on;
		btn.classList.toggle('is-loading', !!on);
		if (label) { btn.textContent = label; }
	};

	Widget.prototype.setError = function (box, msg) {
		box.textContent = msg || '';
		box.hidden = !msg;
	};

	Widget.prototype.field = function (name, label, input, optional) {
		input.id = 'ssa-' + name + '-' + Math.random().toString(36).slice(2, 7);
		return el('div', { class: 'ssa-field', 'data-field': name }, [
			el('label', { for: input.id, text: label + (optional ? ' (اختیاری)' : '') }),
			input,
			el('span', { class: 'ssa-field-error', 'data-error': name, hidden: true })
		]);
	};

	Widget.prototype.target = function () {
		return this.redirect || window.location.href.split('#')[0];
	};

	Widget.prototype.done = function (data) {
		var to = data && data.redirect;
		var here = window.location.href.split('#')[0];
		if (to && to !== here) { window.location.href = to; } else { window.location.reload(); }
	};

	/* Step 1: mobile number */
	Widget.prototype.showPhone = function (prefill) {
		var self = this;
		this.clear();

		var input = el('input', {
			type: 'tel', name: 'phone', inputmode: 'numeric', autocomplete: 'tel', dir: 'ltr',
			maxlength: 16, placeholder: '09123456789', required: true
		});
		if (prefill) { input.value = prefill; }
		var hp = el('input', { type: 'text', name: 'website', class: 'ssa-hp', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' });
		var err = el('div', { class: 'ssa-error', role: 'alert', hidden: true });
		var btn = el('button', { type: 'submit', class: 'ssa-btn', text: 'ارسال کد تایید' });
		var lead = 'شماره موبایل خود را وارد کنید تا کد تایید برایتان پیامک شود.' + (C.register ? ' اگر حساب ندارید، همین‌جا ساخته می‌شود.' : '');

		var pwd = null;
		if (C.passwordUrl && this.context !== 'wp-login') {
			pwd = el('p', { class: 'ssa-alt' }, [
				el('a', { href: passwordHref(this.redirect), class: 'ssa-link', 'data-ssa-skip': true, text: 'ورود با نام کاربری و رمز عبور' })
			]);
		}

		var form = el('form', { class: 'ssa-form', novalidate: true }, [
			el('p', { class: 'ssa-lead', text: lead }),
			this.field('phone', 'شماره موبایل', input),
			hp, err, btn, pwd
		]);
		this.root.appendChild(form);

		input.addEventListener('focus', function () { loadSession().catch(function () {}); });

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			self.setError(err, '');
			var phone = latin(input.value).replace(/[\s\-]/g, '');
			if (!/^(\+98|0098|98|0)?9\d{9}$/.test(phone)) {
				self.setError(err, 'شماره موبایل معتبر نیست. نمونه: 09123456789');
				return;
			}
			self.busy(btn, true);
			call('send', { phone: phone, website: hp.value }).then(function (data) {
				self.phone = phone;
				self.showCode(data);
			}).catch(function (e2) {
				self.setError(err, errMsg(e2));
				self.busy(btn, false);
			});
		});

		// Inline forms do not steal focus on page load; the modal does.
		if (this.root.closest('.ssa-modal') && !this.root.closest('.ssa-modal').hidden) {
			setTimeout(function () { input.focus(); }, 30);
		}
	};

	/* Step 2: verification code */
	Widget.prototype.showCode = function (info) {
		var self = this;
		this.clear();
		var len = info.length || C.codeLength;

		var input = el('input', {
			type: 'text', name: 'code', inputmode: 'numeric', autocomplete: 'one-time-code', dir: 'ltr',
			maxlength: len, class: 'ssa-code', placeholder: new Array(len + 1).join('•'), required: true
		});
		var err = el('div', { class: 'ssa-error', role: 'alert', hidden: true });
		var btn = el('button', { type: 'submit', class: 'ssa-btn', text: 'تایید و ادامه' });
		var resend = el('button', { type: 'button', class: 'ssa-link', disabled: true });
		var edit = el('button', { type: 'button', class: 'ssa-link', text: 'ویرایش شماره' });

		var form = el('form', { class: 'ssa-form', novalidate: true }, [
			el('p', { class: 'ssa-lead', text: 'کد ' + fa(len) + ' رقمی به شماره‌ی ' + fa(this.phone) + ' پیامک شد.' }),
			this.field('code', 'کد تایید', input),
			err, btn,
			el('div', { class: 'ssa-row' }, [resend, edit])
		]);
		this.root.appendChild(form);
		input.focus();

		function tick(left) {
			function paint() {
				if (left > 0) {
					var m = Math.floor(left / 60), s = left % 60;
					resend.textContent = 'ارسال مجدد کد (' + fa(('0' + m).slice(-2) + ':' + ('0' + s).slice(-2)) + ')';
					resend.disabled = true;
				} else {
					resend.textContent = 'ارسال مجدد کد';
					resend.disabled = false;
				}
			}
			if (self.timer) { clearInterval(self.timer); }
			paint();
			self.timer = setInterval(function () {
				left -= 1;
				paint();
				if (left <= 0) { clearInterval(self.timer); self.timer = null; }
			}, 1000);
		}
		tick(info.cooldown || 60);

		var sending = false;
		function submit() {
			if (sending) { return; }
			self.setError(err, '');
			var code = latin(input.value).replace(/\D/g, '');
			if (code.length !== len) {
				self.setError(err, 'کد ' + fa(len) + ' رقمی را کامل وارد کنید.');
				return;
			}
			sending = true;
			self.busy(btn, true);
			call('verify', { phone: self.phone, code: code, redirect: self.target() }).then(function (data) {
				if (data.status === 'logged_in') {
					btn.textContent = 'در حال ورود...';
					self.done(data);
				} else if (data.status === 'register') {
					self.token = data.token;
					self.showProfile();
				}
			}).catch(function (e) {
				sending = false;
				self.setError(err, errMsg(e));
				self.busy(btn, false);
				input.value = '';
				input.focus();
				if (e.data && e.data.expired) { tick(0); }
			});
		}

		form.addEventListener('submit', function (e) { e.preventDefault(); submit(); });
		input.addEventListener('input', function () {
			input.value = latin(input.value).replace(/\D/g, '');
			if (input.value.length === len) { submit(); }
		});
		edit.addEventListener('click', function () { self.showPhone(self.phone); });
		resend.addEventListener('click', function () {
			self.setError(err, '');
			resend.disabled = true;
			call('send', { phone: self.phone, website: '' }).then(function (data) {
				tick(data.cooldown || 60);
				input.value = '';
				input.focus();
			}).catch(function (e) {
				self.setError(err, errMsg(e));
				var wait_s = e.data && e.data.retry_after;
				if (wait_s && wait_s < 600) { tick(wait_s); } else { resend.disabled = false; }
			});
		});
	};

	/* Step 3: profile for new users (only the fields enabled in the settings) */
	Widget.prototype.showProfile = function () {
		var self = this;
		this.clear();
		var useMap = !!(FIELDS.map && C.mapKey);
		var addressTouched = false;
		var inputs = {};

		function opt(name) { return FIELDS[name] === 'optional'; }
		function has(name) { return !!FIELDS[name]; }

		if (has('first_name')) { inputs.first_name = el('input', { type: 'text', name: 'first_name', autocomplete: 'given-name', maxlength: 40, required: !opt('first_name') }); }
		if (has('last_name')) { inputs.last_name = el('input', { type: 'text', name: 'last_name', autocomplete: 'family-name', maxlength: 60, required: !opt('last_name') }); }
		if (has('email')) { inputs.email = el('input', { type: 'email', name: 'email', autocomplete: 'email', dir: 'ltr', maxlength: 100, required: !opt('email') }); }
		if (has('phone2')) { inputs.phone2 = el('input', { type: 'tel', name: 'phone2', inputmode: 'numeric', dir: 'ltr', maxlength: 11, placeholder: '02112345678', required: !opt('phone2') }); }
		if (has('address')) { inputs.address = el('textarea', { name: 'address', rows: 3, maxlength: 300, autocomplete: 'street-address', required: !opt('address') }); }
		if (has('postcode')) { inputs.postcode = el('input', { type: 'text', name: 'postcode', inputmode: 'numeric', autocomplete: 'postal-code', dir: 'ltr', maxlength: 10, required: !opt('postcode') }); }

		var lat = el('input', { type: 'hidden', name: 'lat' });
		var lng = el('input', { type: 'hidden', name: 'lng' });
		var err = el('div', { class: 'ssa-error', role: 'alert', hidden: true });
		var btn = el('button', { type: 'submit', class: 'ssa-btn', text: 'تکمیل ثبت‌نام' });

		var mapBox = null, mapEl = null, locate = null, mapErr = null, mapFailed = false;
		if (useMap) {
			mapEl = el('div', { class: 'ssa-map', 'aria-label': 'نقشه' });
			locate = el('button', { type: 'button', class: 'ssa-link', text: 'استفاده از موقعیت فعلی من' });
			mapErr = el('span', { class: 'ssa-field-error', 'data-error': 'map', hidden: true });
			mapBox = el('div', { class: 'ssa-field ssa-field-map', 'data-field': 'map' }, [
				el('span', { class: 'ssa-label', text: 'موقعیت روی نقشه' + (opt('map') ? ' (اختیاری)' : '') }),
				el('p', { class: 'ssa-hint', text: 'نقشه را جابه‌جا کنید و روی محل موردنظر بزنید، یا نشانگر را بکشید.' }),
				mapEl, locate, mapErr
			]);
		}

		var names = (inputs.first_name || inputs.last_name) ? el('div', { class: (inputs.first_name && inputs.last_name) ? 'ssa-grid' : '' }, [
			inputs.first_name ? this.field('first_name', 'نام', inputs.first_name, opt('first_name')) : null,
			inputs.last_name ? this.field('last_name', 'نام خانوادگی', inputs.last_name, opt('last_name')) : null
		]) : null;

		var form = el('form', { class: 'ssa-form', novalidate: true }, [
			el('p', { class: 'ssa-lead', text: 'شماره‌ی شما تایید شد. برای ساخت حساب، اطلاعات زیر را تکمیل کنید.' }),
			names,
			inputs.email ? this.field('email', 'ایمیل', inputs.email, opt('email')) : null,
			inputs.phone2 ? this.field('phone2', 'شماره تماس دوم (ثابت یا موبایل)', inputs.phone2, opt('phone2')) : null,
			mapBox,
			inputs.address ? this.field('address', 'آدرس کامل', inputs.address, opt('address')) : null,
			inputs.postcode ? this.field('postcode', 'کد پستی', inputs.postcode, opt('postcode')) : null,
			lat, lng, err, btn
		]);
		this.root.appendChild(form);
		var first = form.querySelector('input:not([type=hidden]), textarea');
		if (first) { first.focus(); }

		if (inputs.address) { inputs.address.addEventListener('input', function () { addressTouched = true; }); }

		function setPoint(lngLat) {
			lat.value = lngLat.lat.toFixed(6);
			lng.value = lngLat.lng.toFixed(6);
			mapErr.hidden = true;
			if (C.hasReverse && inputs.address && !addressTouched) {
				call('reverse', { token: self.token, lat: lat.value, lng: lng.value }).then(function (d) {
					if (!addressTouched && d.address) { inputs.address.value = d.address; }
				}).catch(function () {});
			}
		}

		if (useMap) {
			loadNeshan().then(function () {
				var map = new window.nmp_mapboxgl.Map({
					mapType: window.nmp_mapboxgl.Map.mapTypes.neshanVector,
					container: mapEl,
					zoom: C.zoom,
					pitch: 0,
					center: C.center,
					minZoom: 4,
					maxZoom: 20,
					trackResize: true,
					mapKey: C.mapKey,
					poi: false,
					traffic: false
				});
				var accent = (getComputedStyle(self.root).getPropertyValue('--ssa-accent') || '').trim() || '#2271b1';
				var marker = null;
				function place(lngLat, fly) {
					if (!marker) {
						marker = new window.nmp_mapboxgl.Marker({ draggable: true, color: accent }).setLngLat(lngLat).addTo(map);
						marker.on('dragend', function () { setPoint(marker.getLngLat()); });
					} else {
						marker.setLngLat(lngLat);
					}
					if (fly) { map.flyTo({ center: [lngLat.lng, lngLat.lat], zoom: 16 }); }
					setPoint(lngLat);
				}
				map.on('click', function (e) { place(e.lngLat, false); });
				locate.addEventListener('click', function () {
					if (!navigator.geolocation) { return; }
					navigator.geolocation.getCurrentPosition(function (pos) {
						place({ lat: pos.coords.latitude, lng: pos.coords.longitude }, true);
					});
				});
			}).catch(function () {
				mapEl.textContent = 'بارگذاری نقشه ممکن نشد.' + (inputs.address ? ' آدرس را به‌صورت متنی وارد کنید.' : '');
				mapEl.classList.add('is-failed');
				mapFailed = true;
				locate.hidden = true;
			});
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			self.setError(err, '');
			Array.prototype.forEach.call(form.querySelectorAll('[data-error]'), function (n) { n.hidden = true; });
			self.busy(btn, true);
			var payload = { token: self.token, lat: lat.value, lng: lng.value, map_unavailable: mapFailed ? '1' : '', redirect: self.target() };
			Object.keys(inputs).forEach(function (k) { payload[k] = inputs[k].value; });
			call('register', payload).then(function (data) {
				btn.textContent = 'حساب ساخته شد...';
				self.done(data);
			}).catch(function (e2) {
				var d = e2.data || {};
				if (d.restart) { self.showPhone(self.phone); return; }
				self.setError(err, errMsg(e2));
				if (d.fields) {
					Object.keys(d.fields).forEach(function (k) {
						var box = form.querySelector('[data-error="' + k + '"]');
						if (box) { box.textContent = d.fields[k]; box.hidden = false; }
					});
				}
				self.busy(btn, false);
			});
		});
	};

	/* ---------- modal ---------- */
	var lastTrigger = null;
	function modal() { return document.querySelector('.ssa-modal'); }

	function openModal(trigger) {
		var m = modal();
		if (!m) { return false; }
		lastTrigger = trigger || null;
		m.hidden = false;
		document.documentElement.classList.add('ssa-lock');
		loadSession().catch(function () {});
		var input = m.querySelector('.ssa-auth input:not([type=hidden]):not(.ssa-hp)');
		if (input) { setTimeout(function () { input.focus(); }, 30); }
		return true;
	}
	function closeModal() {
		var m = modal();
		if (!m || m.hidden) { return; }
		m.hidden = true;
		document.documentElement.classList.remove('ssa-lock');
		if (lastTrigger && lastTrigger.focus) { lastTrigger.focus(); }
	}

	/* Links to "My account" / wp-login.php (exact page, no action=…) open the modal instead. */
	function normPath(href) {
		try {
			var u = new URL(href, window.location.href);
			if (u.origin !== window.location.origin) { return null; }
			return { path: u.pathname.replace(/\/+$/, '') || '/', search: u.searchParams };
		} catch (e) { return null; }
	}
	var accountPaths = (C.accountUrls || []).map(normPath).filter(Boolean).map(function (p) { return p.path; });
	function isAccountLink(a) {
		if (!accountPaths.length || !a || !a.getAttribute('href')) { return false; }
		var p = normPath(a.href);
		if (!p || p.search.get('action')) { return false; }
		return accountPaths.indexOf(p.path) !== -1;
	}

	function init() {
		Array.prototype.forEach.call(document.querySelectorAll('.ssa-auth'), function (root) { new Widget(root); });

		document.addEventListener('click', function (e) {
			var t = e.target;
			if (!t.closest) { return; }
			if (t.closest('[data-ssa-close]')) { closeModal(); return; }
			if (e.ctrlKey || e.metaKey || e.shiftKey || e.button > 0 || !modal()) { return; }
			if (t.closest('.ssa-auth, [data-ssa-skip]')) { return; }
			var hit = null;
			if (C.triggers) {
				try { hit = t.closest(C.triggers); } catch (err) { hit = null; }
			}
			if (!hit) {
				var a = t.closest('a[href]');
				if (a && isAccountLink(a)) { hit = a; }
			}
			if (hit) {
				// Capture phase + stopPropagation keeps the theme's own login drawer from opening.
				e.preventDefault();
				e.stopPropagation();
				openModal(hit);
			}
		}, true);

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') { closeModal(); }
		});

		if (window.location.hash === '#sms-login') { openModal(null); }
	}

	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
