<?php
/**
 * Moaref – سیستم کد معرف و کیف پول (کلاس اصلی افزونه)
 *
 * کد معرف اختصاصی برای هر کاربر، هدیه برای کاربر جدید، کمیسیون درصدی خرید برای معرف
 * (با سطح‌بندی سه‌مرحله‌ای)، کش‌بک خرید (تومانی پله‌ای یا درصدی ثابت)، مهلت روزی جداگانه
 * برای معرفی‌کننده و معرفی‌شده، و کیف پول تومانی با مدیریت از پیشخوان.
 *
 * WooCommerce برای کمیسیون، کش‌بک و پرداخت با کیف پول لازم است. TeraWallet (woo-wallet) اختیاری.
 *
 * @package Moaref
 * @author  ماهان رضائی - https://co.shainika.com
 * @license GPL-2.0-or-later
 *
 * همه مبالغ این افزونه (تنظیمات، کیف پول، گزارش‌ها) به «تومان» هستند.
 * واحد پول ووکامرس (IRR، IRT، IRHR، IRHT) خودکار تشخیص داده و تبدیل می‌شود.
 *
 * مبنای کمیسیون و کش‌بک «مبلغ پرداخت‌شده» است: جمع محصولات بعد از تخفیف، بدون ارسال و مالیات،
 * منهای مبلغی که با کیف پول پرداخت شده (سفارش ۱٬۰۰۰٬۰۰۰ با ۴۰۰٬۰۰۰ کیف پول ← مبنا ۶۰۰٬۰۰۰).
 *
 * کیف پول: اگر افزونه TeraWallet فعال باشد مبالغ مستقیماً به آن واریز/برداشت می‌شود،
 * در غیر این صورت موجودی در user_meta (کلید _moaref_wallet_balance) نگه داشته می‌شود.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Moaref_Referral' ) ) :

final class Moaref_Referral {

	const OPT             = 'moaref_settings';
	const META_CODE       = '_moaref_code';
	const META_REFERRER   = '_moaref_referrer_id';
	const META_GIFT_PAID  = '_moaref_gift_paid';
	const META_REF_COUNT  = '_moaref_referral_count';
	const META_EARNED     = '_moaref_total_earned';
	const META_COMM_GIVEN = '_moaref_commission_given';
	const META_BALANCE    = '_moaref_wallet_balance'; // فقط وقتی TeraWallet نصب نیست
	const META_LOG        = '_moaref_wallet_log';
	const ORDER_META_PAID = '_moaref_commission_paid';
	const ORDER_META_REV  = '_moaref_commission_reversed';
	const ORDER_WALLET    = '_moaref_wallet_paid';   // مبلغ کسرشده از کیف پول در تسویه (تومان)
	const ORDER_WALLET_BACK  = '_moaref_wallet_returned'; // مبلغ کیف پول با لغو/استرداد به مشتری برگشته و هنوز دوباره کسر نشده
	const ORDER_WALLET_CYCLE = '_moaref_wallet_cycle';    // شمارنده «لغو ← فعال‌سازی دوباره» (برای مُهرهای یک‌بارمصرف)
	const META_REWARD     = '_moaref_referrer_reward_paid';
	const SESSION_WALLET  = 'moaref_use_wallet';
	const FEE_NAME        = 'کسر از کیف پول';
	const OPT_CASHBACK    = 'moaref_cashback';
	const OPT_WALLET      = 'moaref_wallet_settings';
	const CASHBACK_SLUG   = 'moaref-cashback';
	const ORDER_CB_PAID   = '_moaref_cashback_paid';
	const ORDER_CB_REV    = '_moaref_cashback_reversed';
	const META_WIN_REFERRED = '_moaref_win_referred'; // شروع مهلت «معرفی‌شده»: اولین خرید تکمیل‌شده بعد از ثبت معرف
	const META_WIN_REFERRER = '_moaref_win_referrer'; // شروع مهلت «معرفی‌کننده»: اولین خرید تکمیل‌شده بعد از اولین معرفی
	const ORDER_SKIP      = '_moaref_skip_';          // پیشوند کلید «چرا پرداخت نشد» روی سفارش
	const MAX_WINDOW_DAYS = 36500;                    // سقف مهلت روزی (۱۰۰ سال)
	const MAX_AMOUNT      = 1000000000000;            // سقف هر مبلغ قابل‌ثبت در تنظیمات (تومان)
	const MAX_LEVELS      = 3;
	const MAX_COOKIE_DAYS = 100000; // عملاً بدون سقف
	const BROWSER_MAX_AGE = 400;    // سقف عمر کوکی در کروم (روز)
	const FIELD           = 'moaref_ref_code';
	const COOKIE          = 'moaref_ref';
	const CODE_LENGTH     = 8;
	const ADMIN_SLUG      = 'moaref-wallet';
	const MAX_CHAIN_DEPTH = 50;

	/** جلوگیری از ثبت دوباره هوک‌ها اگر mr_init بیش از یک بار صدا زده شود */
	private static $booted = false;

	public static function mr_init() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		// ثبت ?ref=CODE در کوکی
		if ( did_action( 'init' ) ) { // اگر اسنیپت دیرتر از init اجرا شود
			self::mr_capture_ref_param();
		} else {
			add_action( 'init', array( __CLASS__, 'mr_capture_ref_param' ) );
		}

		// فیلد کد معرف در فرم ثبت‌نام وردپرس و ووکامرس
		add_action( 'register_form', array( __CLASS__, 'mr_render_register_field' ) );
		add_action( 'woocommerce_register_form', array( __CLASS__, 'mr_render_register_field' ) );

		// اعتبارسنجی
		add_filter( 'registration_errors', array( __CLASS__, 'mr_validate_wp_registration' ), 10, 3 );
		add_filter( 'woocommerce_registration_errors', array( __CLASS__, 'mr_validate_wc_registration' ), 10, 3 );

		// بعد از ساخت کاربر: تولید کد + ثبت معرف + هدیه
		add_action( 'user_register', array( __CLASS__, 'mr_on_user_register' ), 20 );

		// ثبت کد معرف از پنل کاربری (یک بار)
		add_action( 'template_redirect', array( __CLASS__, 'mr_handle_panel_referrer_submit' ) );

		// شروع مهلت روزی (اولین خرید تکمیل‌شده) — قبل از کمیسیون و کش‌بک تا همان خرید هم داخل مهلت حساب شود
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'mr_mark_window_start' ), 5 );

		// کمیسیون خرید
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'mr_maybe_pay_commission' ), 20 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'mr_reverse_commission' ), 20 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'mr_reverse_commission' ), 20 );

		// کش‌بک خرید (تومانی پله‌ای یا درصدی)
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'mr_maybe_pay_cashback' ), 25 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'mr_reverse_cashback' ), 25 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'mr_reverse_cashback' ), 25 );

		// پرداخت با کیف پول در صفحه تسویه حساب
		add_action( 'woocommerce_review_order_before_payment', array( __CLASS__, 'mr_render_checkout_wallet' ) );
		add_action( 'woocommerce_checkout_update_order_review', array( __CLASS__, 'mr_checkout_review_update' ) );
		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'mr_add_wallet_fee' ), 999 );
		add_filter( 'woocommerce_cart_totals_get_fees_from_cart_taxes', array( __CLASS__, 'mr_wallet_fee_no_tax' ), 10, 2 ); // [A]
		add_action( 'woocommerce_review_order_after_order_total', array( __CLASS__, 'mr_render_seen_fee' ) );                  // [D]
		add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'mr_check_wallet_unchanged' ), 10, 2 );         // [D]
		add_action( 'moaref_release_wallet_order', array( __CLASS__, 'mr_release_wallet_order' ) );                           // [C]
		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'mr_validate_wallet_fee' ), 10, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'mr_charge_wallet_for_order' ), 10, 3 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'mr_refund_wallet_payment' ), 10 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'mr_refund_wallet_payment' ), 10 );
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'mr_redebit_wallet_on_reopen' ), 10, 3 );

		// حذف کاربر: معرفی‌شده‌های او آزاد می‌شوند تا بتوانند معرف جدید ثبت کنند
		add_action( 'delete_user', array( __CLASS__, 'mr_on_delete_user' ) );

		// پنل کاربری
		add_shortcode( 'moaref_panel', array( __CLASS__, 'mr_shortcode_panel' ) );
		add_action( 'woocommerce_account_dashboard', array( __CLASS__, 'mr_print_panel' ) );

		// مدیریت: تنظیمات و صفحه کیف پول
		add_action( 'admin_menu', array( __CLASS__, 'mr_admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'mr_register_settings' ) );
		add_filter( 'option_page_capability_moaref_group', array( __CLASS__, 'mr_admin_cap' ) );
		add_filter( 'option_page_capability_moaref_cashback_group', array( __CLASS__, 'mr_admin_cap' ) );
		add_filter( 'option_page_capability_moaref_wallet_group', array( __CLASS__, 'mr_admin_cap' ) );
		add_action( 'admin_post_moaref_wallet_adjust', array( __CLASS__, 'mr_handle_admin_wallet_form' ) );
		add_action( 'wp_ajax_moaref_wallet_quick', array( __CLASS__, 'mr_ajax_wallet_quick' ) );

		// مدیریت: لیست کاربران + ویرایش سریع + پروفایل
		add_filter( 'manage_users_columns', array( __CLASS__, 'mr_users_columns' ) );
		add_filter( 'manage_users_custom_column', array( __CLASS__, 'mr_users_column_value' ), 10, 3 );
		add_filter( 'user_row_actions', array( __CLASS__, 'mr_user_row_actions' ), 10, 2 );
		add_action( 'admin_footer-users.php', array( __CLASS__, 'mr_users_list_script' ) );
		add_action( 'show_user_profile', array( __CLASS__, 'mr_profile_wallet_box' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'mr_profile_wallet_box' ) );
	}

	/* -------------------------------------------------------------------------
	 * Settings
	 * ---------------------------------------------------------------------- */

	public static function mr_defaults() {
		return array(
			'gift_amount'        => 50000, // مبلغ هدیه کاربر جدید (تومان)
			'referrer_reward'    => 0,     // مبلغ ثابت برای معرف به ازای هر معرفی (تومان)
			'gift_trigger'       => 'first_order', // register = بلافاصله | first_order = بعد از اولین خرید تکمیل‌شده (پیش‌فرض امن: ضد اکانت فیک)
			'checkout_wallet'    => 1,     // ۱ = چک‌باکس «پرداخت با کیف پول» در تسویه حساب
			'commission_percent' => 10,    // درصد کمیسیون معرف
			'commission_mode'    => 'all', // all = هر خرید | first = فقط اولین خرید
			'level_count'        => 3,     // تعداد مراحل فعال سطح‌بندی معرف (۰ تا ۳)
			'levels'             => array( // با رسیدن به «users» معرفی، «extra» درصد به درصد پیش‌فرض اضافه می‌شود
				array( 'users' => 10, 'extra' => 2 ),
				array( 'users' => 25, 'extra' => 4 ),
				array( 'users' => 50, 'extra' => 6 ),
			),
			'min_order'          => 0,     // حداقل مبلغ سفارش برای کمیسیون (تومان)
			'comm_expiry'        => 0,     // ۱ = مهلت روزی برای کمیسیون فعال است
			'comm_days_referred' => 90,    // کمیسیون تا چند روز بعد از اولین خرید «معرفی‌شده» (۰ = بدون محدودیت)
			'comm_days_referrer' => 0,     // کمیسیون تا چند روز بعد از اولین خرید «معرفی‌کننده» (اختیاری؛ ۰ = بدون محدودیت)
			'cookie_days'        => 30,
			'cookie_unlimited'   => 0,     // ۱ = لینک دعوت بدون انقضا
		);
	}

	public static function mr_opt( $key ) {
		$opts = wp_parse_args( (array) get_option( self::OPT, array() ), self::mr_defaults() );
		return isset( $opts[ $key ] ) ? $opts[ $key ] : null;
	}

	public static function mr_sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();
		$d     = self::mr_defaults();

		return array(
			'gift_amount'        => isset( $input['gift_amount'] ) ? self::mr_sanitize_amount( $input['gift_amount'] ) : $d['gift_amount'],
			'commission_percent' => self::mr_sanitize_percent( isset( $input['commission_percent'] ) ? $input['commission_percent'] : null, $d['commission_percent'] ),
			'referrer_reward'    => isset( $input['referrer_reward'] ) ? self::mr_sanitize_amount( $input['referrer_reward'] ) : $d['referrer_reward'],
			'gift_trigger'       => ( isset( $input['gift_trigger'] ) && 'first_order' === $input['gift_trigger'] ) ? 'first_order' : 'register',
			'checkout_wallet'    => (int) self::mr_opt( 'checkout_wallet' ), // فقط برای سازگاری؛ تنظیم اصلی در صفحه کیف پول است
			'commission_mode'    => ( isset( $input['commission_mode'] ) && 'first' === $input['commission_mode'] ) ? 'first' : 'all',
			'min_order'          => isset( $input['min_order'] ) ? self::mr_sanitize_amount( $input['min_order'] ) : $d['min_order'],
			'comm_expiry'        => empty( $input['comm_expiry'] ) ? 0 : 1,
			'comm_days_referred' => self::mr_sanitize_days( isset( $input['comm_days_referred'] ) ? $input['comm_days_referred'] : null, $d['comm_days_referred'] ),
			'comm_days_referrer' => self::mr_sanitize_days( isset( $input['comm_days_referrer'] ) ? $input['comm_days_referrer'] : null, $d['comm_days_referrer'] ),
			'cookie_days'        => isset( $input['cookie_days'] ) ? min( self::MAX_COOKIE_DAYS, max( 1, absint( self::mr_fa_digits( $input['cookie_days'] ) ) ) ) : $d['cookie_days'],
			'level_count'        => isset( $input['level_count'] ) ? min( self::MAX_LEVELS, absint( self::mr_fa_digits( $input['level_count'] ) ) ) : $d['level_count'],
			'levels'             => self::mr_sanitize_levels( isset( $input['levels'] ) ? $input['levels'] : null, $d['levels'] ),
			'cookie_unlimited'   => empty( $input['cookie_unlimited'] ) ? 0 : 1,
		);
	}

	/** پله‌ها را پاک‌سازی می‌کند. $k1/$k2: نام دو ستون (حد، مقدار)؛ $max2 = null یعنی ستون دوم مبلغ تومانی است، وگرنه درصد با سقف $max2 */
	private static function mr_sanitize_rows( $rows, $fallback, $k1, $k2, $max2 = null ) {
		if ( ! is_array( $rows ) ) {
			return $fallback;
		}
		$out = array();
		for ( $i = 0; $i < self::MAX_LEVELS; $i++ ) {
			$row   = isset( $rows[ $i ] ) && is_array( $rows[ $i ] ) ? $rows[ $i ] : array();
			$v1    = isset( $row[ $k1 ] ) ? self::mr_sanitize_amount( $row[ $k1 ] ) : 0;
			if ( null === $max2 ) { // ستون مبلغ (تومان): جداکننده‌های هزارگان را هم می‌پذیرد
				$v2 = isset( $row[ $k2 ] ) ? self::mr_sanitize_amount( $row[ $k2 ] ) : 0;
			} else {                // ستون درصد
				$v2 = isset( $row[ $k2 ] ) ? min( $max2, self::mr_sanitize_percent( $row[ $k2 ], 0 ) ) : 0;
			}
			$out[] = array( $k1 => $v1, $k2 => $v2 );
		}
		return $out;
	}

	private static function mr_sanitize_levels( $rows, $fallback ) {
		return self::mr_sanitize_rows( $rows, $fallback, 'users', 'extra', 100 );
	}

	/** تعداد روز مهلت: عدد صحیح ۰ تا MAX_WINDOW_DAYS (۰ = بدون محدودیت)؛ ارقام فارسی را هم می‌پذیرد، ورودی نامعتبر = مقدار قبلی/پیش‌فرض */
	private static function mr_sanitize_days( $raw, $fallback ) {
		$raw = null === $raw ? '' : self::mr_fa_digits( $raw );
		if ( '' === $raw || ! is_numeric( $raw ) || (float) $raw < 0 ) {
			return $fallback;
		}
		return min( self::MAX_WINDOW_DAYS, (int) floor( (float) $raw ) );
	}

	/** پله‌های فعال (مرتب از کوچک به بزرگ، پله‌های خالی حذف) */
	private static function mr_active_rows( $rows, $count, $k1 ) {
		$rows = array_slice( (array) $rows, 0, max( 0, min( self::MAX_LEVELS, (int) $count ) ) );
		$rows = array_values( array_filter( $rows, function ( $r ) use ( $k1 ) {
			return ! empty( $r[ $k1 ] );
		} ) );
		usort( $rows, function ( $a, $b ) use ( $k1 ) {
			return $a[ $k1 ] <=> $b[ $k1 ];
		} );
		return $rows;
	}

	/** درصد کمیسیون این معرف = درصد پیش‌فرض + درصد اضافه بالاترین مرحله‌ای که به آن رسیده */
	public static function mr_commission_percent( $referrer ) {
		$base  = (float) self::mr_opt( 'commission_percent' );
		$count = (int) get_user_meta( $referrer, self::META_REF_COUNT, true );
		$extra = 0;
		foreach ( self::mr_active_rows( self::mr_opt( 'levels' ), self::mr_opt( 'level_count' ), 'users' ) as $lv ) {
			if ( $count >= $lv['users'] ) {
				$extra = max( $extra, (float) $lv['extra'] );
			}
		}
		return min( 100, $base + $extra );
	}

	/** مرحله بعدی معرف برای نمایش در پنل: array( users, extra ) یا null */
	private static function mr_next_level( $referrer ) {
		$count = (int) get_user_meta( $referrer, self::META_REF_COUNT, true );
		foreach ( self::mr_active_rows( self::mr_opt( 'levels' ), self::mr_opt( 'level_count' ), 'users' ) as $lv ) {
			if ( $count < $lv['users'] ) {
				return $lv;
			}
		}
		return null;
	}

	/* ---- Cashback settings ---- */

	public static function mr_cashback_defaults() {
		return array(
			'enabled'       => 0,
			'mode'          => 'fixed', // fixed = تومانی پله‌ای | percent = درصد ثابت (بدون پله)
			'percent'       => 5,       // درصد کش‌بک در حالت «درصدی» (از مبلغ پرداخت‌شده)
			'tier_count'    => 3,
			'tiers'         => array( // خرید حداقل «min» تومان → «amount» تومان کش‌بک
				array( 'min' => 1000000, 'amount' => 100000 ),
				array( 'min' => 1500000, 'amount' => 150000 ),
				array( 'min' => 2000000, 'amount' => 200000 ),
			),
			'expiry'        => 0,       // ۱ = مهلت روزی برای کش‌بک فعال است
			'days_referred' => 90,      // کش‌بک «معرفی‌شده‌ها» تا چند روز بعد از اولین خرید خودشان (۰ = بدون محدودیت)
			'days_referrer' => 90,      // کش‌بک «معرفی‌کننده‌ها» تا چند روز بعد از اولین خرید خودشان (۰ = بدون محدودیت)
		);
	}

	public static function mr_cb_opt( $key ) {
		$opts = wp_parse_args( (array) get_option( self::OPT_CASHBACK, array() ), self::mr_cashback_defaults() );
		return isset( $opts[ $key ] ) ? $opts[ $key ] : null;
	}

	public static function mr_sanitize_cashback( $input ) {
		$input = is_array( $input ) ? $input : array();
		$d     = self::mr_cashback_defaults();
		return array(
			'enabled'       => empty( $input['enabled'] ) ? 0 : 1,
			'mode'          => ( isset( $input['mode'] ) && 'percent' === $input['mode'] ) ? 'percent' : 'fixed',
			'percent'       => self::mr_sanitize_percent( isset( $input['percent'] ) ? $input['percent'] : null, $d['percent'] ),
			'tier_count'    => isset( $input['tier_count'] ) ? min( self::MAX_LEVELS, max( 1, absint( $input['tier_count'] ) ) ) : $d['tier_count'],
			'tiers'         => self::mr_sanitize_rows( isset( $input['tiers'] ) ? $input['tiers'] : null, $d['tiers'], 'min', 'amount' ),
			'expiry'        => empty( $input['expiry'] ) ? 0 : 1,
			'days_referred' => self::mr_sanitize_days( isset( $input['days_referred'] ) ? $input['days_referred'] : null, $d['days_referred'] ),
			'days_referrer' => self::mr_sanitize_days( isset( $input['days_referrer'] ) ? $input['days_referrer'] : null, $d['days_referrer'] ),
		);
	}

	/** درصد ۰ تا ۱۰۰ با حداکثر دو رقم اعشار؛ ارقام فارسی و «٫» را می‌پذیرد، ورودی نامعتبر = مقدار پیش‌فرض */
	private static function mr_sanitize_percent( $raw, $fallback ) {
		$raw = null === $raw ? '' : str_replace( array( '٫', ',', '،' ), '.', self::mr_fa_digits( $raw ) );
		if ( '' === $raw || ! is_numeric( $raw ) ) {
			return $fallback;
		}
		return round( min( 100, max( 0, (float) $raw ) ), 2 );
	}

	/**
	 * مبلغ کش‌بک برای مبنای $base تومانی.
	 * حالت درصدی: یک درصد ثابت از مبنا (بدون پله). حالت تومانی: بالاترین پله‌ای که خرید به آن رسیده.
	 */
	public static function mr_cashback_for( $base ) {
		if ( 'percent' === self::mr_cb_opt( 'mode' ) ) {
			return max( 0, round( (float) $base * (float) self::mr_cb_opt( 'percent' ) / 100 ) );
		}
		$amount = 0;
		foreach ( self::mr_active_rows( self::mr_cb_opt( 'tiers' ), self::mr_cb_opt( 'tier_count' ), 'min' ) as $tier ) {
			if ( $base >= $tier['min'] ) {
				$amount = (float) $tier['amount'];
			}
		}
		return $amount;
	}

	/* ---- Wallet settings ---- */

	public static function mr_wallet_defaults() {
		return array(
			// اگر قبلاً در تنظیمات کد معرف خاموش شده بود، همان حفظ می‌شود
			'checkout_wallet' => (int) self::mr_opt( 'checkout_wallet' ),
		);
	}

	public static function mr_wallet_opt( $key ) {
		$opts = wp_parse_args( (array) get_option( self::OPT_WALLET, array() ), self::mr_wallet_defaults() );
		return isset( $opts[ $key ] ) ? $opts[ $key ] : null;
	}

	public static function mr_sanitize_wallet_settings( $input ) {
		$input = is_array( $input ) ? $input : array();
		return array(
			'checkout_wallet' => empty( $input['checkout_wallet'] ) ? 0 : 1,
		);
	}

	/* -------------------------------------------------------------------------
	 * Currency (Toman <-> store currency)
	 * ---------------------------------------------------------------------- */

	/** ضریب تبدیل تومان به واحد پول فروشگاه (ووکامرس فارسی: IRR، IRT، IRHR، IRHT) */
	private static function mr_store_rate() {
		$rates = array(
			'IRR'  => 10,    // ریال
			'IRT'  => 1,     // تومان
			'IRHR' => 0.01,  // هزار ریال
			'IRHT' => 0.001, // هزار تومان
		);
		$cur  = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IRT';
		$rate = isset( $rates[ $cur ] ) ? $rates[ $cur ] : 1;
		$rate = (float) apply_filters( 'moaref_store_rate', $rate, $cur );
		return ( $rate > 0 && is_finite( $rate ) ) ? $rate : 1.0;
	}

	/** دسترسی لازم برای صفحه‌های مدیریت (با فیلتر moaref_admin_capability قابل تغییر است) */
	public static function mr_admin_cap() {
		$cap = apply_filters( 'moaref_admin_capability', 'manage_options' );
		return ( is_string( $cap ) && '' !== $cap ) ? $cap : 'manage_options';
	}

	/* -------------------------------------------------------------------------
	 * Atomic helpers (برای جلوگیری از پرداخت تکراری در درخواست‌های همزمان)
	 * ---------------------------------------------------------------------- */

	/**
	 * یک «مُهر» یکتا در جدول options ثبت می‌کند. چون option_name ایندکس یکتا دارد،
	 * از بین چند درخواست همزمان فقط یکی true می‌گیرد.
	 */
	private static function mr_claim( $key ) {
		global $wpdb;
		return (bool) $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				'_moaref_claim_' . $key,
				time()
			)
		);
	}

	private static function mr_unclaim( $key ) {
		global $wpdb;
		$wpdb->delete( $wpdb->options, array( 'option_name' => '_moaref_claim_' . $key ) );
	}

	/** افزایش اتمی یک عدد در user_meta */
	private static function mr_meta_increment( $user_id, $key, $delta ) {
		global $wpdb;
		add_user_meta( $user_id, $key, 0, true );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->usermeta} SET meta_value = CAST(meta_value AS DECIMAL(20,0)) + %f WHERE user_id = %d AND meta_key = %s",
				(float) $delta,
				(int) $user_id,
				$key
			)
		);
		wp_cache_delete( $user_id, 'user_meta' );
	}

	public static function mr_toman_to_store( $toman ) {
		return (float) $toman * self::mr_store_rate();
	}

	public static function mr_store_to_toman( $amount ) {
		return round( (float) $amount / self::mr_store_rate(), 6 );
	}

	public static function mr_format_toman( $toman ) {
		/* translators: %s: amount in Toman */
		return sprintf( __( '%s تومان', 'moaref' ), number_format_i18n( round( (float) $toman ) ) );
	}

	/** تبدیل ارقام فارسی/عربی به انگلیسی */
	private static function mr_fa_digits( $raw ) {
		return strtr(
			is_scalar( $raw ) ? sanitize_text_field( wp_unslash( (string) $raw ) ) : '',
			array(
				'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
				'۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
				'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
				'٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
			)
		);
	}

	/** ورودی عددی کاربر: اعداد فارسی/عربی و جداکننده‌ها را می‌پذیرد */
	public static function mr_sanitize_amount( $raw ) {
		$raw = is_scalar( $raw ) ? sanitize_text_field( wp_unslash( (string) $raw ) ) : '';
		if ( preg_match( '/^\s*[-−–]/u', $raw ) ) { // مبلغ منفی پذیرفته نمی‌شود (علامت منفی حذف و مثبت نمی‌شود)
			return 0;
		}
		$raw = strtr(
			$raw,
			array(
				'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
				'۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
				'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
				'٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
			)
		);
		$raw = str_replace( '٫', '.', $raw );          // ممیز فارسی
		$raw = preg_replace( '/[^0-9.]/', '', $raw );  // حذف , ٬ فاصله و ...
		if ( substr_count( $raw, '.' ) > 1 || preg_match( '/^\d{1,3}\.\d{3}$/', $raw ) ) { // 1.000.000 و 150.000 = جداکننده هزارگان
			$raw = str_replace( '.', '', $raw );
		}
		return min( self::MAX_AMOUNT, max( 0, round( (float) $raw ) ) );
	}

	/* -------------------------------------------------------------------------
	 * Referral code helpers
	 * ---------------------------------------------------------------------- */

	/** فقط حروف و اعداد انگلیسی، بزرگ، حداکثر ۱۶ کاراکتر */
	public static function mr_sanitize_code( $raw ) {
		$raw = is_scalar( $raw ) ? self::mr_fa_digits( $raw ) : ''; // ارقام فارسی/عربی → انگلیسی؛ آرایه (?ref[]=x) نادیده گرفته می‌شود
		$raw = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', $raw ) );
		return substr( $raw, 0, 16 );
	}

	public static function mr_find_user_by_code( $code ) {
		$code = self::mr_sanitize_code( $code );
		if ( '' === $code ) {
			return 0;
		}
		$ids = get_users(
			array(
				'meta_key'    => self::META_CODE,
				'meta_value'  => $code,
				'number'      => 1,
				'fields'      => 'ID',
				'count_total' => false,
			)
		);
		return $ids ? (int) $ids[0] : 0;
	}

	/** کد کاربر را برمی‌گرداند و اگر نداشت (کاربران قدیمی) می‌سازد */
	public static function mr_get_code( $user_id ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return '';
		}
		$code = get_user_meta( $user_id, self::META_CODE, true );
		if ( $code ) {
			return $code;
		}
		do {
			$code = strtoupper( wp_generate_password( self::CODE_LENGTH, false, false ) );
		} while ( self::mr_find_user_by_code( $code ) );

		update_user_meta( $user_id, self::META_CODE, $code );
		return $code;
	}

	public static function mr_share_link( $user_id ) {
		return add_query_arg( 'ref', rawurlencode( self::mr_get_code( $user_id ) ), home_url( '/' ) );
	}

	/** آیا $user_id در زنجیره معرف‌های $referrer وجود دارد؟ (جلوگیری از معرفی دوری A→B→A) */
	private static function mr_creates_loop( $user_id, $referrer ) {
		$current = (int) $referrer;
		for ( $i = 0; $i < self::MAX_CHAIN_DEPTH && $current; $i++ ) {
			if ( $current === (int) $user_id ) {
				return true;
			}
			$current = (int) get_user_meta( $current, self::META_REFERRER, true );
		}
		return false;
	}

	/**
	 * ثبت معرف برای کاربر (فقط یک بار) + پرداخت هدیه.
	 *
	 * @return true|WP_Error
	 */
	public static function mr_assign_referrer( $user_id, $referrer ) {
		$user_id  = absint( $user_id );
		$referrer = absint( $referrer );

		if ( ! $user_id || ! $referrer || ! get_userdata( $referrer ) ) {
			return new WP_Error( 'invalid', __( 'کد معرف وارد شده معتبر نیست.', 'moaref' ) );
		}
		if ( $referrer === $user_id ) {
			return new WP_Error( 'self', __( 'نمی‌توانید کد معرف خودتان را وارد کنید.', 'moaref' ) );
		}
		if ( self::mr_creates_loop( $user_id, $referrer ) ) {
			return new WP_Error( 'loop', __( 'این کاربر خودش توسط شما معرفی شده است و نمی‌تواند معرف شما باشد.', 'moaref' ) );
		}
		// مُهر اتمی: حتی با ارسال همزمان چند درخواست، معرف فقط یک بار ثبت می‌شود
		wp_cache_delete( $user_id, 'user_meta' );
		if ( get_user_meta( $user_id, self::META_REFERRER, true ) || ! self::mr_claim( 'referrer_' . $user_id ) ) {
			return new WP_Error( 'already', __( 'قبلاً برای حساب شما معرف ثبت شده است.', 'moaref' ) );
		}

		update_user_meta( $user_id, self::META_REFERRER, $referrer );
		self::mr_meta_increment( $referrer, self::META_REF_COUNT, 1 );

		if ( 'register' === self::mr_opt( 'gift_trigger' ) ) {
			self::mr_maybe_pay_gift( $user_id );
			self::mr_maybe_pay_referrer_reward( $user_id );
		}

		do_action( 'moaref_user_referred', $user_id, $referrer );
		return true;
	}

	/** معرفی‌کننده حذف شد: ارتباط معرفی‌شده‌های او پاک می‌شود (وگرنه برای همیشه به «کاربر حذف‌شده» وصل می‌مانند و معرف جدید نمی‌توانند ثبت کنند) */
	public static function mr_on_delete_user( $user_id ) {
		global $wpdb;
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value = %s",
				self::META_REFERRER,
				(string) absint( $user_id )
			)
		);
		foreach ( $ids as $id ) {
			delete_user_meta( (int) $id, self::META_REFERRER );
			self::mr_unclaim( 'referrer_' . (int) $id );
		}
	}

	/** پرداخت هدیه کاربر معرفی‌شده (فقط یک بار) */
	private static function mr_maybe_pay_gift( $user_id ) {
		$gift = (float) self::mr_opt( 'gift_amount' );
		if ( $gift <= 0 || get_user_meta( $user_id, self::META_GIFT_PAID, true ) || ! self::mr_claim( 'gift_' . $user_id ) ) {
			return false;
		}
		if ( self::mr_credit( $user_id, $gift, __( 'هدیه ثبت کد معرف', 'moaref' ) ) ) {
			update_user_meta( $user_id, self::META_GIFT_PAID, time() );
			return true;
		}
		self::mr_unclaim( 'gift_' . $user_id ); // واریز ناموفق بود؛ اجازه تلاش دوباره
		return false;
	}

	/** پاداش ثابت معرف به ازای معرفی $referee (برای هر کاربر معرفی‌شده فقط یک بار) */
	private static function mr_maybe_pay_referrer_reward( $referee ) {
		$reward   = (float) self::mr_opt( 'referrer_reward' );
		$referrer = (int) get_user_meta( $referee, self::META_REFERRER, true );
		if ( $reward <= 0 || ! $referrer || ! get_userdata( $referrer ) || get_user_meta( $referee, self::META_REWARD, true ) || ! self::mr_claim( 'reward_' . $referee ) ) {
			return false;
		}
		$referee_user = get_userdata( $referee );
		/* translators: %s: referred user's display name */
		$note = sprintf( __( 'پاداش معرفی کاربر %s', 'moaref' ), $referee_user ? $referee_user->display_name : '#' . $referee );
		if ( self::mr_credit( $referrer, $reward, $note ) ) {
			update_user_meta( $referee, self::META_REWARD, $reward );
			self::mr_meta_increment( $referrer, self::META_EARNED, $reward );
			do_action( 'moaref_referrer_reward_paid', $referrer, $reward, $referee );
			return true;
		}
		self::mr_unclaim( 'reward_' . $referee );
		return false;
	}

	/* -------------------------------------------------------------------------
	 * Cookie (?ref=CODE)
	 * ---------------------------------------------------------------------- */

	/**
	 * کوکی لینک دعوت به شکل «CODE-EXPIRY» ذخیره می‌شود (EXPIRY = زمان انقضا، ۰ = بدون انقضا).
	 * انقضا سمت سرور چک می‌شود، چون مرورگرها بیشتر از ۴۰۰ روز به کوکی عمر نمی‌دهند؛
	 * برای مدت‌های طولانی‌تر، کوکی با هر بازدید تا سقف ۴۰۰ روز تمدید می‌شود.
	 */
	public static function mr_capture_ref_param() {
		if ( is_user_logged_in() || headers_sent() ) {
			return;
		}
		$unlimited = (bool) self::mr_opt( 'cookie_unlimited' );
		$days      = (int) self::mr_opt( 'cookie_days' );
		if ( ! empty( $_GET['ref'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$code = self::mr_sanitize_code( $_GET['ref'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( ! $code || ! self::mr_find_user_by_code( $code ) ) {
				return;
			}
			$expiry = $unlimited ? 0 : time() + $days * DAY_IN_SECONDS;
		} elseif ( self::mr_cookie_code() && ( $unlimited || $days > self::BROWSER_MAX_AGE ) ) {
			$code   = self::mr_cookie_code();
			$expiry = $unlimited ? 0 : self::mr_cookie_expiry();
		} else {
			return;
		}
		$browser_max = time() + self::BROWSER_MAX_AGE * DAY_IN_SECONDS;
		$value       = $code . '-' . $expiry;
		self::mr_set_cookie( $value, $expiry ? min( $expiry, $browser_max ) : $browser_max );
		$_COOKIE[ self::COOKIE ] = $value;
	}

	/** ثبت کوکی لینک دعوت با SameSite=Lax؛ روی PHP قدیمی‌تر از ۷.۳ هم کار می‌کند */
	private static function mr_set_cookie( $value, $expires ) {
		$path   = COOKIEPATH ? COOKIEPATH : '/';
		$domain = COOKIE_DOMAIN ? COOKIE_DOMAIN : '';
		if ( PHP_VERSION_ID >= 70300 ) {
			setcookie(
				self::COOKIE,
				$value,
				array(
					'expires'  => $expires,
					'path'     => $path,
					'domain'   => $domain,
					'secure'   => is_ssl(),
					'httponly' => true,
					'samesite' => 'Lax',
				)
			);
			return;
		}
		// PHP < 7.3 آرایه تنظیمات را نمی‌شناسد؛ SameSite از طریق path اضافه می‌شود
		setcookie( self::COOKIE, $value, $expires, $path . '; samesite=Lax', $domain, is_ssl(), true );
	}

	/** wp_date از وردپرس ۵.۳ به بعد؛ برای نسخه‌های قدیمی‌تر date_i18n با منطقه زمانی سایت */
	private static function mr_date( $format, $timestamp ) {
		if ( function_exists( 'wp_date' ) ) {
			return wp_date( $format, $timestamp );
		}
		return date_i18n( $format, (int) $timestamp + (int) round( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) );
	}

	/** آیا صفحه تسویه حساب فروشگاه با بلوک ووکامرس ساخته شده است؟ (چک‌باکس کیف پول فقط در تسویه کلاسیک نمایش داده می‌شود) */
	private static function mr_checkout_uses_block() {
		if ( ! function_exists( 'wc_get_page_id' ) || ! function_exists( 'has_block' ) ) {
			return false;
		}
		$page_id = (int) wc_get_page_id( 'checkout' );
		$page    = $page_id > 0 ? get_post( $page_id ) : null;
		return $page ? has_block( 'woocommerce/checkout', $page ) : false;
	}

	private static function mr_cookie_parts() {
		if ( empty( $_COOKIE[ self::COOKIE ] ) || ! is_scalar( $_COOKIE[ self::COOKIE ] ) ) {
			return array( '', 0 );
		}
		$parts = explode( '-', sanitize_text_field( wp_unslash( (string) $_COOKIE[ self::COOKIE ] ) ), 2 );
		return array( self::mr_sanitize_code( $parts[0] ), isset( $parts[1] ) ? absint( $parts[1] ) : 0 );
	}

	private static function mr_cookie_expiry() {
		$parts = self::mr_cookie_parts();
		return $parts[1];
	}

	private static function mr_cookie_code() {
		list( $code, $expiry ) = self::mr_cookie_parts();
		return ( $expiry && $expiry < time() ) ? '' : $code;
	}

	private static function mr_clear_cookie() {
		if ( isset( $_COOKIE[ self::COOKIE ] ) && ! headers_sent() ) {
			setcookie( self::COOKIE, '', time() - HOUR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN );
		}
	}

	/* -------------------------------------------------------------------------
	 * Registration
	 * ---------------------------------------------------------------------- */

	public static function mr_render_register_field() {
		// فیلد از کوکی پر نمی‌شود تا صفحه‌های کش‌شده کد یک نفر را به همه نشان ندهند؛
		// اگر خالی بماند، کد لینک دعوت (کوکی) هنگام ثبت‌نام خودکار اعمال می‌شود.
		$value = isset( $_POST[ self::FIELD ] ) ? self::mr_sanitize_code( $_POST[ self::FIELD ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		?>
		<p class="form-row form-row-wide moaref-ref-field">
			<label for="<?php echo esc_attr( self::FIELD ); ?>"><?php esc_html_e( 'کد معرف (اختیاری)', 'moaref' ); ?></label>
			<input type="text" class="input input-text" name="<?php echo esc_attr( self::FIELD ); ?>"
				id="<?php echo esc_attr( self::FIELD ); ?>" value="<?php echo esc_attr( $value ); ?>"
				maxlength="16" autocomplete="off" dir="ltr" pattern="[A-Za-z0-9۰-۹٠-٩]*" />
		</p>
		<?php
	}

	/**
	 * کد ارسال‌شده در فرم ثبت‌نام. خروجی: WP_Error یا شناسه معرف (۰ = بدون کد)
	 * nonce اینجا لازم نیست: فرم ثبت‌نام برای کاربر مهمان است (nonce مهمان امنیتی اضافه نمی‌کند)
	 * و با کش صفحه باعث خطای «نشست منقضی» می‌شد. ووکامرس nonce خودش را دارد.
	 */
	private static function mr_check_posted_code() {
		if ( empty( $_POST[ self::FIELD ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return 0;
		}
		$referrer = self::mr_find_user_by_code( $_POST[ self::FIELD ] );
		if ( ! $referrer ) {
			return new WP_Error( 'moaref_invalid', __( 'کد معرف وارد شده معتبر نیست.', 'moaref' ) );
		}
		return $referrer;
	}

	public static function mr_validate_wp_registration( $errors, $login, $email ) {
		$r = self::mr_check_posted_code();
		if ( is_wp_error( $r ) ) {
			$errors->add( $r->get_error_code(), $r->get_error_message() );
		}
		return $errors;
	}

	public static function mr_validate_wc_registration( $errors, $username, $email ) {
		return self::mr_validate_wp_registration( $errors, $username, $email );
	}

	public static function mr_on_user_register( $user_id ) {
		$user_id = absint( $user_id );
		self::mr_get_code( $user_id );

		$referrer = self::mr_check_posted_code();
		if ( is_wp_error( $referrer ) ) {
			return;
		}
		// کاربرانی که مدیر از پیشخوان می‌سازد از کوکی معرف نمی‌گیرند
		if ( ! $referrer && self::mr_cookie_code() && ! ( is_admin() && current_user_can( 'create_users' ) ) ) {
			$referrer = self::mr_find_user_by_code( self::mr_cookie_code() );
		}
		if ( $referrer && true === self::mr_assign_referrer( $user_id, $referrer ) ) {
			self::mr_clear_cookie();
		}
	}

	/* -------------------------------------------------------------------------
	 * Set referrer later from the user panel (once)
	 * ---------------------------------------------------------------------- */

	private static function mr_panel_messages() {
		return array(
			'ok'      => array( 'success', __( 'کد معرف با موفقیت ثبت شد.', 'moaref' ) ),
			'nonce'   => array( 'error', __( 'نشست فرم منقضی شده است. دوباره تلاش کنید.', 'moaref' ) ),
			'empty'   => array( 'error', __( 'لطفاً کد معرف را وارد کنید.', 'moaref' ) ),
			'invalid' => array( 'error', __( 'کد معرف وارد شده معتبر نیست.', 'moaref' ) ),
			'self'    => array( 'error', __( 'نمی‌توانید کد معرف خودتان را وارد کنید.', 'moaref' ) ),
			'loop'    => array( 'error', __( 'این کاربر خودش توسط شما معرفی شده است و نمی‌تواند معرف شما باشد.', 'moaref' ) ),
			'already' => array( 'error', __( 'قبلاً برای حساب شما معرف ثبت شده است.', 'moaref' ) ),
		);
	}

	public static function mr_handle_panel_referrer_submit() {
		if ( empty( $_POST['moaref_action'] ) || 'set_referrer' !== $_POST['moaref_action'] || ! is_user_logged_in() ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}
		$uid  = get_current_user_id();
		// wp_get_referer() وقتی فرم به همان صفحه ارسال شود false برمی‌گرداند، پس از raw referer استفاده می‌کنیم
		$back = wp_get_raw_referer();
		$home = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'dashboard' ) : home_url( '/' );
		$back = $back ? wp_validate_redirect( $back, $home ) : $home;
		$back = remove_query_arg( 'moaref_msg', $back );

		if ( empty( $_POST['_moaref_panel_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['_moaref_panel_nonce'] ) ), 'moaref_set_referrer_' . $uid ) ) {
			$status = 'nonce';
		} else {
			$code = isset( $_POST[ self::FIELD ] ) ? self::mr_sanitize_code( $_POST[ self::FIELD ] ) : '';
			if ( '' === $code ) {
				$status = 'empty';
			} elseif ( get_user_meta( $uid, self::META_REFERRER, true ) ) {
				$status = 'already';
			} else {
				$result = self::mr_assign_referrer( $uid, self::mr_find_user_by_code( $code ) );
				$status = is_wp_error( $result ) ? $result->get_error_code() : 'ok';
			}
		}

		wp_safe_redirect( add_query_arg( 'moaref_msg', $status, $back ) );
		exit;
	}

	/* -------------------------------------------------------------------------
	 * Commission on purchase
	 * ---------------------------------------------------------------------- */

	/**
	 * مبلغی از سفارش که با کیف پول پرداخت شده (به واحد پول فروشگاه): جمع fee‌های منفی «کیف پول» (خود اسنیپت یا TeraWallet)؛
	 * اگر مدیر fee را از سفارش حذف کرده باشد، مبلغ کسرشده‌ای که اسنیپت روی سفارش ثبت کرده ملاک است.
	 */
	private static function mr_wallet_part( $order ) {
		$sum = 0;
		foreach ( $order->get_fees() as $fee ) {
			$name = strtolower( (string) $fee->get_name() );
			if ( (float) $fee->get_total() < 0 && ( false !== strpos( $name, 'wallet' ) || false !== strpos( $name, 'کیف پول' ) ) ) {
				$sum += abs( (float) $fee->get_total() );
			}
		}
		return max( $sum, self::mr_toman_to_store( (float) $order->get_meta( self::ORDER_WALLET ) ) );
	}

	/**
	 * مبنای کمیسیون و کش‌بک = «مبلغ پرداخت‌شده» (تومان): جمع اقلام بعد از تخفیف، بدون حمل‌ونقل و مالیات،
	 * منهای مبالغ مسترد شده و منهای مبلغی که از کیف پول پرداخت شده است.
	 * مثال: سفارش ۱٬۰۰۰٬۰۰۰ با ۴۰۰٬۰۰۰ کیف پول ← مبنا ۶۰۰٬۰۰۰. سفارشی که کامل با درگاه «کیف پول» پرداخت شده مبنا ندارد.
	 */
	private static function mr_commission_base( $order ) {
		if ( 'wallet' === $order->get_payment_method() ) {
			return 0;
		}
		$base = (float) $order->get_subtotal() - (float) $order->get_total_discount() - (float) $order->get_total_refunded() - self::mr_wallet_part( $order );
		return max( 0, (float) apply_filters( 'moaref_commission_base', self::mr_store_to_toman( $base ), $order ) );
	}

	/* -------------------------------------------------------------------------
	 * Expiry windows (مهلت روزی جداگانه برای معرفی‌شده و معرفی‌کننده)
	 * ---------------------------------------------------------------------- */

	/** کلید متای شروع مهلت برای نقش 'referred' (معرفی‌شده) یا 'referrer' (معرفی‌کننده) */
	private static function mr_window_key( $role ) {
		return 'referrer' === $role ? self::META_WIN_REFERRER : self::META_WIN_REFERRED;
	}

	/**
	 * هر نفر مهلتش را از «اولین خرید تکمیل‌شده بعد از ورود به سیستم معرفی» می‌شمارد:
	 * معرفی‌شده بعد از ثبت کد معرف، معرفی‌کننده بعد از اولین معرفی. خریدهای قبل از آن شروع مهلت حساب نمی‌شوند،
	 * تا مشتری قدیمی که بعداً کد معرف می‌زند یا معرف می‌شود، از همان لحظه مهلتش تمام‌شده نباشد.
	 */
	public static function mr_mark_window_start( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		$buyer = $order ? (int) $order->get_customer_id() : 0;
		if ( ! $buyer ) {
			return;
		}
		$roles = array();
		if ( get_user_meta( $buyer, self::META_REFERRER, true ) ) {
			$roles[] = 'referred';
		}
		if ( (int) get_user_meta( $buyer, self::META_REF_COUNT, true ) > 0 ) {
			$roles[] = 'referrer';
		}
		foreach ( $roles as $role ) {
			add_user_meta( $buyer, self::mr_window_key( $role ), time(), true ); // unique: فقط بار اول ثبت می‌شود
		}
	}

	/**
	 * آیا مهلت $days روزی این نفر در نقش $role هنوز باز است؟
	 * ۰ روز = بدون محدودیت. اگر مهلت هنوز شروع نشده (بعد از ورود به سیستم معرفی هنوز خریدی تکمیل نشده) باز است.
	 */
	private static function mr_window_open( $user_id, $role, $days ) {
		$days = (int) $days;
		if ( $days <= 0 ) {
			return true;
		}
		$start = (int) get_user_meta( $user_id, self::mr_window_key( $role ), true );
		return ! $start || time() <= $start + $days * DAY_IN_SECONDS;
	}

	/**
	 * مهلت کمیسیون: هر دو نفر باید داخل مهلت خودشان باشند (خریدار در نقش معرفی‌شده، معرف در نقش معرفی‌کننده).
	 *
	 * @return string '' = باز است | 'referred' یا 'referrer' = مهلت کدام طرف تمام شده
	 */
	private static function mr_commission_window_closed_for( $buyer, $referrer ) {
		if ( ! self::mr_opt( 'comm_expiry' ) ) {
			return '';
		}
		if ( ! self::mr_window_open( $buyer, 'referred', self::mr_opt( 'comm_days_referred' ) ) ) {
			return 'referred';
		}
		if ( ! self::mr_window_open( $referrer, 'referrer', self::mr_opt( 'comm_days_referrer' ) ) ) {
			return 'referrer';
		}
		return '';
	}

	/**
	 * مهلت کش‌بک: فقط کسانی مهلت دارند که معرفی‌شده‌اند (کد معرف زده‌اند) یا معرفی‌کننده‌اند (حداقل یک نفر را معرفی کرده‌اند)؛
	 * مشتری معمولی همیشه کش‌بک می‌گیرد. اگر کسی هر دو نقش را دارد، تا وقتی مهلت یکی از دو نقش باز باشد کش‌بک می‌گیرد.
	 */
	private static function mr_cashback_window_open( $buyer ) {
		if ( ! self::mr_cb_opt( 'expiry' ) ) {
			return true;
		}
		$checks = array();
		if ( get_user_meta( $buyer, self::META_REFERRER, true ) ) {
			$checks['referred'] = self::mr_cb_opt( 'days_referred' );
		}
		if ( (int) get_user_meta( $buyer, self::META_REF_COUNT, true ) > 0 ) {
			$checks['referrer'] = self::mr_cb_opt( 'days_referrer' );
		}
		if ( ! $checks ) {
			return true;
		}
		foreach ( $checks as $role => $days ) {
			if ( self::mr_window_open( $buyer, $role, $days ) ) {
				return true;
			}
		}
		return false;
	}

	/** دلیل پرداخت‌نشدن را فقط یک بار برای هر سفارش و هر نوع ('commission' یا 'cashback') در یادداشت سفارش ثبت می‌کند */
	private static function mr_skip_note( $order, $type, $text ) {
		$key = self::ORDER_SKIP . $type;
		if ( $order->get_meta( $key ) ) {
			return;
		}
		$order->update_meta_data( $key, time() );
		$order->save();
		$order->add_order_note( $text );
	}

	public static function mr_maybe_pay_commission( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$buyer    = (int) $order->get_customer_id();
		$referrer = $buyer ? (int) get_user_meta( $buyer, self::META_REFERRER, true ) : 0;
		if ( ! $referrer || $referrer === $buyer ) {
			return;
		}

		// هدیه کاربر جدید در حالت «بعد از اولین خرید»
		if ( 'first_order' === self::mr_opt( 'gift_trigger' ) ) {
			self::mr_maybe_pay_gift( $buyer );
			self::mr_maybe_pay_referrer_reward( $buyer );
		}

		if ( $order->get_meta( self::ORDER_META_PAID ) || ! get_userdata( $referrer ) ) {
			return;
		}

		$base = self::mr_commission_base( $order );
		if ( $base <= 0 || $base < (float) self::mr_opt( 'min_order' ) ) {
			return;
		}

		$percent = self::mr_commission_percent( $referrer );
		$amount  = round( $base * $percent / 100 );
		$amount = (float) apply_filters( 'moaref_commission_amount', $amount, $order, $referrer );
		if ( $amount <= 0 ) {
			return;
		}

		// مهلت روزی کمیسیون: بعد از پایان مهلت معرفی‌شده یا معرفی‌کننده، کمیسیونی پرداخت نمی‌شود
		$closed = self::mr_commission_window_closed_for( $buyer, $referrer );
		if ( $closed ) {
			self::mr_skip_note(
				$order,
				'commission',
				'referred' === $closed ? __( 'کمیسیون پرداخت نشد: مهلت روزی «معرفی‌شده» تمام شده است.', 'moaref' ) : __( 'کمیسیون پرداخت نشد: مهلت روزی «معرفی‌کننده» تمام شده است.', 'moaref' )
			);
			return;
		}

		// مُهرهای اتمی: هر سفارش فقط یک بار، و در حالت «اولین خرید» هر خریدار فقط یک بار
		$first = 'first' === self::mr_opt( 'commission_mode' );
		if ( $first && get_user_meta( $buyer, self::META_COMM_GIVEN, true ) ) {
			return;
		}
		if ( ! self::mr_claim( 'order_' . $order->get_id() ) ) {
			return;
		}
		if ( $first && ! self::mr_claim( 'first_' . $buyer ) ) {
			self::mr_unclaim( 'order_' . $order->get_id() );
			return;
		}

		/* translators: %s: order number */
		$note = sprintf( __( 'کمیسیون معرفی – سفارش #%s', 'moaref' ), $order->get_order_number() );
		if ( self::mr_credit( $referrer, $amount, $note ) ) {
			$order->update_meta_data( self::ORDER_META_PAID, $amount );
			$order->update_meta_data( '_moaref_commission_referrer', $referrer );
			if ( $first ) {
				$order->update_meta_data( '_moaref_commission_first', 1 ); // این سفارش «فرصت اولین خرید» را مصرف کرده
			}
			$order->save();
			update_user_meta( $buyer, self::META_COMM_GIVEN, 1 );
			self::mr_meta_increment( $referrer, self::META_EARNED, $amount );
			$order->add_order_note( $note . ' : ' . self::mr_format_toman( $amount ) . ' (' . sprintf( /* translators: 1: percent, 2: paid amount */ __( '%1$s٪ از مبلغ پرداخت‌شده %2$s', 'moaref' ), $percent, self::mr_format_toman( $base ) ) . ')' );
			do_action( 'moaref_commission_paid', $referrer, $amount, $order );
		} else {
			self::mr_unclaim( 'order_' . $order->get_id() );
			if ( $first ) {
				self::mr_unclaim( 'first_' . $buyer );
			}
		}
	}

	/** برگشت کمیسیون وقتی سفارش مسترد یا لغو شود */
	public static function mr_reverse_commission( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order  = wc_get_order( $order_id );
		$amount = $order ? (float) $order->get_meta( self::ORDER_META_PAID ) : 0;
		if ( $amount <= 0 || $order->get_meta( self::ORDER_META_REV ) || ! self::mr_claim( 'reverse_' . $order->get_id() ) ) {
			return;
		}
		$referrer = (int) $order->get_meta( '_moaref_commission_referrer' );
		if ( ! $referrer ) {
			$referrer = (int) get_user_meta( (int) $order->get_customer_id(), self::META_REFERRER, true );
		}
		if ( ! $referrer || ! get_userdata( $referrer ) ) {
			return;
		}

		// اگر معرف قبلاً خرجش کرده باشد، فقط تا سقف موجودی برداشت می‌شود
		/* translators: %s: order number */
		$note = sprintf( __( 'برگشت کمیسیون معرفی – سفارش #%s', 'moaref' ), $order->get_order_number() );
		$take = self::mr_debit_capped( $referrer, $amount, $note );
		if ( false === $take ) {
			self::mr_unclaim( 'reverse_' . $order->get_id() ); // برداشت انجام نشد؛ با تغییر وضعیت بعدی دوباره تلاش می‌شود
			return;
		}
		if ( $take > 0 ) {
			self::mr_meta_increment( $referrer, self::META_EARNED, -$take );
			if ( $take >= $amount && $order->get_meta( '_moaref_commission_first' ) ) { // کمیسیون «اولین خرید» کامل برگشت خورد: خرید بعدی همین خریدار دوباره مشمول است
				$buyer = (int) $order->get_customer_id();
				delete_user_meta( $buyer, self::META_COMM_GIVEN );
				self::mr_unclaim( 'first_' . $buyer );
			}
		}
		$order->update_meta_data( self::ORDER_META_REV, $take );
		$order->save();
		$order->add_order_note( $note . ' : ' . self::mr_format_toman( $take ) . ( $take < $amount ? ' (' . __( 'موجودی معرف کافی نبود', 'moaref' ) . ')' : '' ) );
		do_action( 'moaref_commission_reversed', $referrer, $take, $order );
	}

	/* -------------------------------------------------------------------------
	 * Cashback (Toman tiers or percent; paid into the wallet when the order is completed)
	 * ---------------------------------------------------------------------- */

	public static function mr_maybe_pay_cashback( $order_id ) {
		if ( ! self::mr_cb_opt( 'enabled' ) || ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		$buyer = $order ? (int) $order->get_customer_id() : 0;
		if ( ! $buyer || $order->get_meta( self::ORDER_CB_PAID ) ) {
			return;
		}
		$base   = self::mr_commission_base( $order );
		$amount = (float) apply_filters( 'moaref_cashback_amount', self::mr_cashback_for( $base ), $order );
		if ( $amount <= 0 ) {
			return;
		}
		// مهلت روزی کش‌بک (فقط معرفی‌شده‌ها و معرفی‌کننده‌ها)؛ قبل از مُهر چک می‌شود تا با افزایش مهلت، سفارش دوباره قابل پرداخت باشد
		if ( ! self::mr_cashback_window_open( $buyer ) ) {
			self::mr_skip_note( $order, 'cashback', __( 'کش‌بک پرداخت نشد: مهلت روزی کش‌بک این مشتری تمام شده است.', 'moaref' ) );
			return;
		}
		if ( ! self::mr_claim( 'cashback_' . $order->get_id() ) ) {
			return;
		}
		/* translators: %s: order number */
		$note   = sprintf( __( 'کش‌بک خرید – سفارش #%s', 'moaref' ), $order->get_order_number() );
		$detail = 'percent' === self::mr_cb_opt( 'mode' )
			? ' (' . sprintf( /* translators: 1: percent, 2: paid amount */ __( '%1$s٪ از مبلغ پرداخت‌شده %2$s', 'moaref' ), self::mr_cb_opt( 'percent' ), self::mr_format_toman( $base ) ) . ')'
			: ' (' . sprintf( /* translators: %s: paid amount */ __( 'مبلغ پرداخت‌شده %s', 'moaref' ), self::mr_format_toman( $base ) ) . ')';
		if ( self::mr_credit( $buyer, $amount, $note ) ) {
			$order->update_meta_data( self::ORDER_CB_PAID, $amount );
			$order->update_meta_data( '_moaref_cashback_user', $buyer );
			$order->save();
			$order->add_order_note( $note . ' : ' . self::mr_format_toman( $amount ) . $detail );
			do_action( 'moaref_cashback_paid', $buyer, $amount, $order );
		} else {
			self::mr_unclaim( 'cashback_' . $order->get_id() );
		}
	}

	/** برگشت کش‌بک با لغو یا استرداد سفارش (تا سقف موجودی مشتری) */
	public static function mr_reverse_cashback( $order_id ) {
		$order  = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		$amount = $order ? (float) $order->get_meta( self::ORDER_CB_PAID ) : 0;
		if ( $amount <= 0 || $order->get_meta( self::ORDER_CB_REV ) || ! self::mr_claim( 'cashback_rev_' . $order->get_id() ) ) {
			return;
		}
		$buyer = (int) $order->get_meta( '_moaref_cashback_user' );
		$buyer = $buyer ? $buyer : (int) $order->get_customer_id();
		/* translators: %s: order number */
		$note = sprintf( __( 'برگشت کش‌بک – سفارش #%s', 'moaref' ), $order->get_order_number() );
		$take = self::mr_debit_capped( $buyer, $amount, $note );
		if ( false === $take ) {
			self::mr_unclaim( 'cashback_rev_' . $order->get_id() );
			return;
		}
		$order->update_meta_data( self::ORDER_CB_REV, $take );
		$order->save();
		$order->add_order_note( $note . ' : ' . self::mr_format_toman( $take ) . ( $take < $amount ? ' (' . __( 'موجودی مشتری کافی نبود', 'moaref' ) . ')' : '' ) );
	}

	/* -------------------------------------------------------------------------
	 * Checkout: pay with wallet (classic checkout)
	 * ---------------------------------------------------------------------- */

	private static function mr_checkout_wallet_enabled() {
		return self::mr_wallet_opt( 'checkout_wallet' ) && is_user_logged_in() && function_exists( 'WC' );
	}

	/** آیا مشتری تیک «استفاده از کیف پول» را زده است؟ */
	private static function mr_wants_wallet() {
		// ارسال نهایی فرم تسویه: خود فرم ملاک است
		if ( isset( $_POST['woocommerce-process-checkout-nonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies it.
			return ! empty( $_POST[ self::SESSION_WALLET ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		return WC()->session && WC()->session->get( self::SESSION_WALLET );
	}

	/** به‌روزرسانی سبد با ajax تسویه حساب (update_order_review) */
	public static function mr_checkout_review_update( $post_data ) {
		if ( ! WC()->session ) {
			return;
		}
		parse_str( (string) $post_data, $data );
		WC()->session->set( self::SESSION_WALLET, ! empty( $data[ self::SESSION_WALLET ] ) ? 1 : 0 );
	}

	/** کسر موجودی کیف پول به صورت fee منفی (حداکثر تا مبلغ کل سفارش) */
	public static function mr_add_wallet_fee( $cart ) {
		if ( ( is_admin() && ! wp_doing_ajax() ) || ! self::mr_checkout_wallet_enabled() || ! self::mr_wants_wallet() ) {
			return;
		}
		$balance = self::mr_toman_to_store_safe( self::mr_get_balance( get_current_user_id() ) );
		$total   = (float) $cart->get_cart_contents_total() + (float) $cart->get_cart_contents_tax()
			+ (float) $cart->get_shipping_total() + (float) $cart->get_shipping_tax();
		foreach ( $cart->get_fees() as $fee ) {
			$total += (float) $fee->amount;
		}
		$use = min( $balance, max( 0, $total ) );
		if ( $use > 0 ) {
			$cart->add_fee( self::FEE_NAME, -$use, false );
		}
	}

	/** [A] ووکامرس fee منفی را مثل تخفیف روی مالیات هم اعمال می‌کند؛ پرداخت از کیف پول تخفیف نیست، پس مالیات نباید کم شود */
	public static function mr_wallet_fee_no_tax( $taxes, $fee ) {
		return ( isset( $fee->object->name ) && self::FEE_NAME === $fee->object->name ) ? array() : $taxes;
	}

	/** [B] رُند به پایین تا دقتِ قیمتِ فروشگاه (نه ثابت ۲ رقم)، تا جمع «نقد + کیف پول» با ارزش سفارش یکی باشد */
	private static function mr_toman_to_store_safe( $toman ) {
		$p = pow( 10, function_exists( 'wc_get_price_decimals' ) ? max( 0, (int) wc_get_price_decimals() ) : 2 );
		return floor( self::mr_toman_to_store( $toman ) * $p + 1e-6 ) / $p;
	}

	/** [D] مبلغ کسر کیف پول که در همین لحظه در سبد حساب شده (واحد پول فروشگاه) */
	private static function mr_cart_wallet_fee() {
		$sum = 0;
		if ( function_exists( 'WC' ) && WC()->cart ) {
			foreach ( WC()->cart->get_fees() as $fee ) {
				if ( self::FEE_NAME === $fee->name ) {
					$sum += abs( (float) $fee->total );
				}
			}
		}
		return $sum;
	}

	/** [D] مبلغی که به مشتری نشان داده شد، داخل فرم می‌ماند تا هنگام ثبت نهایی با مبلغ جدید مقایسه شود */
	public static function mr_render_seen_fee() {
		if ( ! self::mr_checkout_wallet_enabled() ) {
			return;
		}
		echo '<tr class="moaref-seen" style="display:none"><td colspan="2"><input type="hidden" name="moaref_wallet_seen" value="' . esc_attr( wc_format_decimal( self::mr_cart_wallet_fee(), 4 ) ) . '" /></td></tr>';
	}

	/** [D] اگر موجودی بین نمایش خلاصه سفارش و ثبت نهایی عوض شده باشد، سفارش ساخته نمی‌شود و مشتری مبلغ جدید را می‌بیند */
	public static function mr_check_wallet_unchanged( $data, $errors ) {
		if ( ! self::mr_checkout_wallet_enabled() || ! isset( $_POST['moaref_wallet_seen'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies it.
			return;
		}
		$seen = (float) wc_format_decimal( wp_unslash( $_POST['moaref_wallet_seen'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( abs( $seen - self::mr_cart_wallet_fee() ) > 0.01 ) {
			if ( WC()->session ) {
				WC()->session->set( 'refresh_totals', true );
			}
			$errors->add( 'moaref_wallet_changed', __( 'موجودی کیف پول شما تغییر کرده است و مبلغ سفارش به‌روز شد. لطفاً مبلغ جدید را بررسی و دوباره ثبت کنید.', 'moaref' ) );
		}
	}

	public static function mr_render_checkout_wallet() {
		if ( ! self::mr_checkout_wallet_enabled() ) {
			return;
		}
		$balance = self::mr_get_balance( get_current_user_id() );
		if ( $balance <= 0 ) {
			return;
		}
		?>
		<div class="moaref-checkout-wallet" style="padding:12px;margin:0 0 16px;border:1px dashed #c3c4c7;border-radius:8px;">
			<label style="display:flex;gap:8px;align-items:center;cursor:pointer;">
				<input type="checkbox" name="<?php echo esc_attr( self::SESSION_WALLET ); ?>" value="1" <?php checked( (bool) self::mr_wants_wallet() ); ?> />
				<span>
					<?php esc_html_e( 'استفاده از موجودی کیف پول', 'moaref' ); ?>
					(<?php echo esc_html( self::mr_format_toman( $balance ) ); ?>)
				</span>
			</label>
		</div>
		<script>
		/* بدون وابستگی به زمان بارگذاری jQuery: با قالب‌ها و افزونه‌های بهینه‌سازی که اسکریپت‌ها را defer/delay می‌کنند هم کار می‌کند */
		(function () {
			if (window.moarefWalletBound) { return; }
			window.moarefWalletBound = true;
			document.addEventListener('change', function (e) {
				var t = e.target;
				if (!t || t.name !== '<?php echo esc_js( self::SESSION_WALLET ); ?>') { return; }
				if (window.jQuery) {
					window.jQuery(document.body).trigger('update_checkout');
				}
			});
		})();
		</script>
		<?php
	}

	/** قبل از ساخت سفارش: موجودی هنوز کافی است؟ */
	public static function mr_validate_wallet_fee( $order, $data ) {
		$use = self::mr_order_wallet_fee( $order );
		if ( $use > 0 && self::mr_get_balance( (int) $order->get_customer_id() ) + 0.5 < $use ) {
			throw new Exception( esc_html__( 'موجودی کیف پول شما تغییر کرده است. صفحه را دوباره بارگذاری کنید.', 'moaref' ) );
		}
	}

	/** مبلغ کسر از کیف پول در سفارش (تومان) */
	private static function mr_order_wallet_fee( $order ) {
		$sum = 0;
		foreach ( $order->get_fees() as $fee ) {
			if ( self::FEE_NAME === $fee->get_name() ) {
				$sum += abs( (float) $fee->get_total() );
			}
		}
		return round( self::mr_store_to_toman( $sum ) );
	}

	/** بعد از ثبت سفارش: برداشت از کیف پول */
	public static function mr_charge_wallet_for_order( $order_id, $posted = array(), $order = null ) {
		$order = $order ? $order : wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$use = self::mr_order_wallet_fee( $order );
		if ( $use <= 0 || $order->get_meta( self::ORDER_WALLET ) || ! self::mr_claim( 'walletpay_' . $order->get_id() ) ) {
			return;
		}
		/* translators: %s: order number */
		$note = sprintf( __( 'پرداخت سفارش #%s', 'moaref' ), $order->get_order_number() );
		if ( ! self::mr_debit( (int) $order->get_customer_id(), $use, $note ) ) {
			self::mr_unclaim( 'walletpay_' . $order->get_id() );
			// کسر کیف پول انجام نشد: fee منفی را حذف کن تا سفارش ناموفق با تخفیفِ پرداخت‌نشده قابل پرداخت نباشد
			foreach ( $order->get_fees() as $item_id => $fee ) {
				if ( self::FEE_NAME === $fee->get_name() ) {
					$order->remove_item( $item_id );
				}
			}
			$order->calculate_totals( false );
			$order->update_status( 'failed', __( 'برداشت از کیف پول انجام نشد (موجودی کافی نبود).', 'moaref' ) );
			throw new Exception( esc_html__( 'موجودی کیف پول برای این سفارش کافی نیست.', 'moaref' ) );
		}
		$order->update_meta_data( self::ORDER_WALLET, $use );
		$order->update_meta_data( '_moaref_wallet_user', (int) $order->get_customer_id() );
		$order->save();
		$order->add_order_note( sprintf( /* translators: %s: amount */ __( 'کسر از کیف پول: %s', 'moaref' ), self::mr_format_toman( $use ) ) );
		// [C] اگر پرداخت آنلاین تکمیل نشد (انصراف، خطای درگاه، سفارش ناموفق)، بعد از مدتی سفارش لغو و مبلغ کیف پول برگردانده می‌شود
		wp_schedule_single_event( time() + (int) apply_filters( 'moaref_wallet_hold_seconds', 2 * HOUR_IN_SECONDS, $order ), 'moaref_release_wallet_order', array( (int) $order->get_id() ) );
		if ( WC()->session ) {
			WC()->session->set( self::SESSION_WALLET, 0 );
		}
	}

	/** [C] سفارش پرداخت‌نشده‌ای که مبلغی از کیف پول برداشت شده، بعد از مهلت لغو می‌شود (برگشت مبلغ با هوک لغو انجام می‌شود) */
	public static function mr_release_wallet_order( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		if ( $order && $order->has_status( array( 'pending', 'failed' ) ) && (float) $order->get_meta( self::ORDER_WALLET ) > 0 ) {
			$order->update_status( 'cancelled', __( 'پرداخت سفارش تکمیل نشد؛ مبلغ کیف پول به حساب مشتری برگشت.', 'moaref' ) );
		}
	}

	/** کاربری که کیف پولش در تسویه کسر شده (اگر بعداً مشتریِ سفارش عوض شود، برگشت پول هم به همان کاربر می‌رود) */
	private static function mr_wallet_payer( $order ) {
		$payer = (int) $order->get_meta( '_moaref_wallet_user' );
		return $payer ? $payer : (int) $order->get_customer_id();
	}

	/** لغو یا استرداد سفارش: برگشت مبلغ کیف پول */
	public static function mr_refund_wallet_payment( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
		$paid  = $order ? (float) $order->get_meta( self::ORDER_WALLET ) : 0;
		$n     = $order ? (int) $order->get_meta( self::ORDER_WALLET_CYCLE ) : 0;
		$key   = $order ? 'walletrefund_' . $order->get_id() . ( $n ? '_' . $n : '' ) : '';
		if ( $paid <= 0 || ! self::mr_claim( $key ) ) {
			return;
		}
		/* translators: %s: order number */
		$note = sprintf( __( 'برگشت مبلغ کیف پول – سفارش #%s', 'moaref' ), $order->get_order_number() );
		if ( self::mr_credit( self::mr_wallet_payer( $order ), $paid, $note ) ) {
			$order->update_meta_data( self::ORDER_WALLET_BACK, time() );
			$order->save();
			$order->add_order_note( $note . ' : ' . self::mr_format_toman( $paid ) );
		} else {
			self::mr_unclaim( $key );
		}
	}

	/**
	 * سفارشی که با لغو/استرداد مبلغ کیف پولش برگشته بود دوباره فعال شد (مثلاً بازگشت دیرهنگام از درگاه یا اصلاح لغو اشتباهی):
	 * همان مبلغ دوباره از کیف پول کسر می‌شود؛ اگر موجودی کافی نباشد سفارش «در انتظار» می‌ماند.
	 */
	public static function mr_redebit_wallet_on_reopen( $order_id, $from, $to ) {
		$dead = array( 'cancelled', 'refunded' );
		if ( ! in_array( $from, $dead, true ) || in_array( $to, $dead, true ) || ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		$paid  = $order ? (float) $order->get_meta( self::ORDER_WALLET ) : 0;
		if ( $paid <= 0 || ! $order->get_meta( self::ORDER_WALLET_BACK ) ) {
			return;
		}
		$next = (int) $order->get_meta( self::ORDER_WALLET_CYCLE ) + 1;
		$key  = 'walletredo_' . $order->get_id() . '_' . $next;
		if ( ! self::mr_claim( $key ) ) {
			return;
		}
		/* translators: %s: order number */
		$note = sprintf( __( 'کسر مجدد کیف پول (فعال‌سازی دوباره سفارش) – سفارش #%s', 'moaref' ), $order->get_order_number() );
		if ( self::mr_debit( self::mr_wallet_payer( $order ), $paid, $note ) ) {
			$order->delete_meta_data( self::ORDER_WALLET_BACK );
			$order->update_meta_data( self::ORDER_WALLET_CYCLE, $next );
			$order->save();
			$order->add_order_note( $note . ' : ' . self::mr_format_toman( $paid ) );
		} else {
			self::mr_unclaim( $key );
			$order->update_status( 'on-hold', sprintf( /* translators: %s: amount */ __( 'موجودی کیف پول مشتری برای کسر مجدد %s کافی نیست؛ سفارش تا بررسی مدیر در انتظار می‌ماند.', 'moaref' ), self::mr_format_toman( $paid ) ) );
		}
	}

	/* -------------------------------------------------------------------------
	 * Wallet (all amounts in Toman)
	 * ---------------------------------------------------------------------- */

	private static function mr_has_terawallet() {
		return function_exists( 'woo_wallet' ) && isset( woo_wallet()->wallet );
	}

	public static function mr_get_balance( $user_id ) {
		if ( self::mr_has_terawallet() ) {
			return floor( self::mr_store_to_toman( (float) woo_wallet()->wallet->get_wallet_balance( $user_id, 'edit' ) ) );
		}
		return (float) get_user_meta( $user_id, self::META_BALANCE, true );
	}

	/** $by: شناسه مدیری که دستی تغییر می‌دهد (۰ = عملیات خودکار سیستم) */
	public static function mr_credit( $user_id, $toman, $note = '', $by = 0 ) {
		return self::mr_adjust( $user_id, abs( (float) $toman ), $note, $by );
	}

	public static function mr_debit( $user_id, $toman, $note = '', $by = 0 ) {
		return self::mr_adjust( $user_id, -abs( (float) $toman ), $note, $by );
	}

	/**
	 * برداشت «تا سقف موجودی»: min($max, موجودی). اگر موجودی همزمان تغییر کند دوباره تلاش می‌کند.
	 *
	 * @return float|false مبلغ برداشت‌شده (۰ = موجودی صفر بود) یا false اگر برداشت انجام نشد
	 */
	private static function mr_debit_capped( $user_id, $max, $note ) {
		for ( $i = 0; $i < 5; $i++ ) {
			$take = min( round( (float) $max ), floor( self::mr_get_balance( $user_id ) ) );
			if ( $take <= 0 ) {
				return 0;
			}
			if ( self::mr_debit( $user_id, $take, $note ) ) {
				return $take;
			}
		}
		return false;
	}

	/**
	 * تغییر موجودی. $delta مثبت = واریز، منفی = برداشت (تومان).
	 * برداشت بیش از موجودی انجام نمی‌شود.
	 *
	 * @return bool
	 */
	private static function mr_adjust( $user_id, $delta, $note, $by = 0 ) {
		global $wpdb;

		$user_id = absint( $user_id );
		$delta   = round( (float) $delta );
		$note    = sanitize_text_field( $note );
		if ( ! $user_id || 0.0 === $delta || ! is_finite( $delta ) || ! get_userdata( $user_id ) ) {
			return false;
		}
		$lock = 'moaref_' . substr( md5( DB_NAME . $wpdb->prefix ), 0, 12 ) . '_' . $user_id;
		$wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 10)', $lock ) );
		$ok = self::mr_adjust_locked( $user_id, $delta, $note, $by );
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		return $ok;
	}

	private static function mr_adjust_locked( $user_id, $delta, $note, $by = 0 ) {
		global $wpdb;
		if ( self::mr_has_terawallet() ) {
			$store = round( self::mr_toman_to_store( abs( $delta ) ), 6 ); // 123457 * 0.001 = 123.45700000000001 > 123.457
			if ( $delta > 0 ) {
				$ok = (bool) woo_wallet()->wallet->credit( $user_id, $store, $note );
			} else {
				if ( self::mr_get_balance( $user_id ) < abs( $delta ) ) {
					return false;
				}
				$ok = (bool) woo_wallet()->wallet->debit( $user_id, $store, $note );
			}
		} else {
			// به‌روزرسانی اتمی در دیتابیس تا دو درخواست همزمان موجودی را خراب نکنند
			add_user_meta( $user_id, self::META_BALANCE, 0, true );
			$sql = "UPDATE {$wpdb->usermeta}
				SET meta_value = CAST(meta_value AS DECIMAL(20,0)) + %f
				WHERE user_id = %d AND meta_key = %s";
			$args = array( $delta, $user_id, self::META_BALANCE );
			if ( $delta < 0 ) {
				$sql   .= ' AND CAST(meta_value AS DECIMAL(20,0)) >= %f';
				$args[] = abs( $delta );
			}
			$ok = (bool) $wpdb->query( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			wp_cache_delete( $user_id, 'user_meta' );
		}

		if ( $ok ) {
			self::mr_log( $user_id, $delta, $note, $by );
			do_action( 'moaref_wallet_adjusted', $user_id, $delta, $note );
		}
		return $ok;
	}

	private static function mr_log( $user_id, $delta, $note, $by = 0 ) {
		wp_cache_delete( $user_id, 'user_meta' );
		$log   = get_user_meta( $user_id, self::META_LOG, true );
		$log   = is_array( $log ) ? $log : array();
		$log[] = array(
			'amount' => $delta,
			'note'   => $note,
			'time'   => time(),
			'by'     => absint( $by ),
		);
		update_user_meta( $user_id, self::META_LOG, array_slice( $log, -100 ) );
	}

	/* -------------------------------------------------------------------------
	 * User panel
	 * ---------------------------------------------------------------------- */

	public static function mr_shortcode_panel() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'برای مشاهده کد معرف وارد حساب کاربری شوید.', 'moaref' ) . '</p>';
		}
		$uid      = get_current_user_id();
		$code     = self::mr_get_code( $uid );
		$link     = self::mr_share_link( $uid );
		$referrer = (int) get_user_meta( $uid, self::META_REFERRER, true );
		$messages = self::mr_panel_messages();
		$msg_key  = isset( $_GET['moaref_msg'] ) ? sanitize_key( wp_unslash( $_GET['moaref_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		ob_start();
		?>
		<div class="moaref-panel" style="border:1px solid #e2e2e2;border-radius:10px;padding:16px;margin:16px 0;">
			<?php if ( isset( $messages[ $msg_key ] ) ) : ?>
				<div class="moaref-notice moaref-notice-<?php echo esc_attr( $messages[ $msg_key ][0] ); ?>"
					style="padding:8px 12px;border-radius:6px;margin-bottom:12px;color:#1d2327;background:<?php echo 'success' === $messages[ $msg_key ][0] ? '#e7f6ec' : '#fdecea'; ?>;">
					<?php echo esc_html( $messages[ $msg_key ][1] ); ?>
				</div>
			<?php endif; ?>

			<h3 style="margin-top:0;"><?php esc_html_e( 'کد معرف شما', 'moaref' ); ?></h3>
			<p>
				<code dir="ltr" style="font-size:1.3em;letter-spacing:2px;"><?php echo esc_html( $code ); ?></code>
				<button type="button" class="button moaref-copy" data-copy="<?php echo esc_attr( $code ); ?>"><?php esc_html_e( 'کپی کد', 'moaref' ); ?></button>
			</p>
			<p>
				<input type="text" readonly dir="ltr" value="<?php echo esc_url( $link ); ?>" style="width:100%;max-width:420px;" onclick="this.select();" />
				<button type="button" class="button moaref-copy" data-copy="<?php echo esc_url( $link ); ?>"><?php esc_html_e( 'کپی لینک', 'moaref' ); ?></button>
			</p>
			<ul style="list-style:none;padding:0;margin:0 0 12px;">
				<li><?php esc_html_e( 'تعداد معرفی‌ها:', 'moaref' ); ?> <strong><?php echo esc_html( number_format_i18n( (int) get_user_meta( $uid, self::META_REF_COUNT, true ) ) ); ?></strong></li>
				<li><?php esc_html_e( 'درصد کمیسیون شما از خرید معرفی‌شده‌ها:', 'moaref' ); ?> <strong><?php echo esc_html( number_format_i18n( self::mr_commission_percent( $uid ), 1 ) ); ?>٪</strong>
					<?php $next = self::mr_next_level( $uid ); ?>
					<?php if ( $next ) : ?>
						<small>(<?php echo esc_html( sprintf( /* translators: 1: referral count, 2: percent */ __( 'با رسیدن به %1$s معرفی: %2$s٪', 'moaref' ), number_format_i18n( $next['users'] ), number_format_i18n( min( 100, (float) self::mr_opt( 'commission_percent' ) + (float) $next['extra'] ), 1 ) ) ); ?>)</small>
					<?php endif; ?>
				</li>
				<li><?php esc_html_e( 'مجموع کمیسیون دریافتی:', 'moaref' ); ?> <strong><?php echo esc_html( self::mr_format_toman( (float) get_user_meta( $uid, self::META_EARNED, true ) ) ); ?></strong></li>
				<li><?php esc_html_e( 'موجودی کیف پول:', 'moaref' ); ?> <strong><?php echo esc_html( self::mr_format_toman( self::mr_get_balance( $uid ) ) ); ?></strong></li>
			</ul>

			<hr />
			<?php if ( $referrer ) : ?>
				<?php $ref_user = get_userdata( $referrer ); ?>
				<p><?php esc_html_e( 'معرف شما:', 'moaref' ); ?> <strong><?php echo esc_html( $ref_user ? $ref_user->display_name : __( 'کاربر حذف‌شده', 'moaref' ) ); ?></strong></p>
			<?php else : ?>
				<form method="post" class="moaref-set-referrer">
					<label for="moaref_panel_code"><strong><?php esc_html_e( 'کد معرف دارید؟', 'moaref' ); ?></strong></label>
					<p style="margin:4px 0 8px;font-size:.9em;"><?php esc_html_e( 'فقط یک بار می‌توانید کد معرف ثبت کنید و بعد از ثبت قابل تغییر نیست.', 'moaref' ); ?></p>
					<input type="hidden" name="moaref_action" value="set_referrer" />
					<?php wp_nonce_field( 'moaref_set_referrer_' . $uid, '_moaref_panel_nonce' ); ?>
					<input type="text" id="moaref_panel_code" name="<?php echo esc_attr( self::FIELD ); ?>" maxlength="16"
						dir="ltr" autocomplete="off" pattern="[A-Za-z0-9۰-۹٠-٩]*" required style="max-width:200px;" />
					<button type="submit" class="button"><?php esc_html_e( 'ثبت کد معرف', 'moaref' ); ?></button>
				</form>
			<?php endif; ?>
		</div>
		<script>
		(function () {
			document.querySelectorAll('.moaref-copy').forEach(function (btn) {
				if (btn.dataset.bound) { return; }
				btn.dataset.bound = '1';
				btn.addEventListener('click', function () {
					var text = btn.getAttribute('data-copy'), old = btn.textContent;
					var done = function () { btn.textContent = '<?php echo esc_js( __( 'کپی شد ✓', 'moaref' ) ); ?>'; setTimeout(function () { btn.textContent = old; }, 1500); };
					if (navigator.clipboard) { navigator.clipboard.writeText(text).then(done); }
					else { var t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); done(); }
				});
			});
		})();
		</script>
		<?php
		return ob_get_clean();
	}

	public static function mr_print_panel() {
		echo self::mr_shortcode_panel(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}

	/* -------------------------------------------------------------------------
	 * Admin: menu, settings
	 * ---------------------------------------------------------------------- */

	/** اعتبار سازنده در پایین صفحه‌های مدیریت افزونه (فقط پیشخوان؛ در سایت برای مشتری‌ها نمایش داده نمی‌شود) */
	private static function mr_credit_footer() {
		?>
		<p class="moaref-credit" style="margin-top:24px;color:#646970;font-size:12px;">
			<?php
			printf(
				/* translators: %s: author name and website link */
				esc_html__( 'ساخته شده توسط %s', 'moaref' ),
				'ماهان رضائی - <a href="https://co.shainika.com" target="_blank" rel="noopener">co.shainika.com</a>'
			);
			?>
		</p>
		<?php
	}

	public static function mr_admin_menu() {
		add_users_page( __( 'سیستم کد معرف', 'moaref' ), __( 'کد معرف', 'moaref' ), self::mr_admin_cap(), 'moaref-referral', array( __CLASS__, 'mr_settings_page' ) );
		add_users_page( __( 'کیف پول کاربران', 'moaref' ), __( 'کیف پول', 'moaref' ), self::mr_admin_cap(), self::ADMIN_SLUG, array( __CLASS__, 'mr_wallet_page' ) );
		add_users_page( __( 'کش‌بک خرید', 'moaref' ), __( 'کش‌بک', 'moaref' ), self::mr_admin_cap(), self::CASHBACK_SLUG, array( __CLASS__, 'mr_cashback_page' ) );
	}

	public static function mr_register_settings() {
		register_setting(
			'moaref_group',
			self::OPT,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'mr_sanitize_settings' ),
				'default'           => self::mr_defaults(),
			)
		);
		register_setting(
			'moaref_cashback_group',
			self::OPT_CASHBACK,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'mr_sanitize_cashback' ),
				'default'           => self::mr_cashback_defaults(),
			)
		);
		register_setting(
			'moaref_wallet_group',
			self::OPT_WALLET,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'mr_sanitize_wallet_settings' ),
			)
		);
	}

	public static function mr_settings_page() {
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			return;
		}
		$o = wp_parse_args( (array) get_option( self::OPT, array() ), self::mr_defaults() );
		$n = esc_attr( self::OPT );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'سیستم کد معرف', 'moaref' ); ?></h1>
			<?php settings_errors(); ?>
			<style>@media (max-width:782px){.form-table table td,.form-table table th{display:table-cell}}</style>
			<form method="post" action="options.php">
				<?php settings_fields( 'moaref_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th><label for="moaref_gift"><?php esc_html_e( 'مبلغ هدیه کاربر جدید (تومان)', 'moaref' ); ?></label></th>
						<td><input id="moaref_gift" type="text" inputmode="decimal" dir="ltr" min="0" step="1" name="<?php echo $n; ?>[gift_amount]" value="<?php echo esc_attr( $o['gift_amount'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="moaref_reward"><?php esc_html_e( 'مبلغ پاداش معرف (تومان)', 'moaref' ); ?></label></th>
						<td>
							<input id="moaref_reward" type="text" inputmode="decimal" dir="ltr" min="0" step="1" name="<?php echo $n; ?>[referrer_reward]" value="<?php echo esc_attr( $o['referrer_reward'] ); ?>" />
							<p class="description"><?php esc_html_e( 'مبلغ ثابتی که به ازای هر معرفی به کیف پول معرف واریز می‌شود (جدا از درصد کمیسیون خرید). ۰ = غیرفعال.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="moaref_gift_trigger"><?php esc_html_e( 'زمان واریز هدیه و پاداش معرف', 'moaref' ); ?></label></th>
						<td>
							<select id="moaref_gift_trigger" name="<?php echo $n; ?>[gift_trigger]">
								<option value="register" <?php selected( $o['gift_trigger'], 'register' ); ?>><?php esc_html_e( 'بلافاصله بعد از ثبت کد معرف', 'moaref' ); ?></option>
								<option value="first_order" <?php selected( $o['gift_trigger'], 'first_order' ); ?>><?php esc_html_e( 'بعد از اولین خرید تکمیل‌شده (ضد اکانت فیک)', 'moaref' ); ?></option>
							</select>
							<p class="description"><?php esc_html_e( 'در حالت «بلافاصله» هر کس می‌تواند با ساختن اکانت‌های فیک هدیه جمع کند؛ کاربران قدیمیِ بدون معرف هم با ثبت کد در پنل کاربری هدیه می‌گیرند. برای فروشگاه واقعی «بعد از اولین خرید تکمیل‌شده» پیشنهاد می‌شود.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="moaref_pct"><?php esc_html_e( 'درصد کمیسیون معرف', 'moaref' ); ?></label></th>
						<td>
							<input id="moaref_pct" type="text" inputmode="decimal" dir="ltr" min="0" max="100" step="any" name="<?php echo $n; ?>[commission_percent]" value="<?php echo esc_attr( $o['commission_percent'] ); ?>" /> %
							<p class="description"><?php esc_html_e( 'از «مبلغ پرداخت‌شده» محاسبه می‌شود: جمع محصولات بعد از تخفیف، بدون ارسال و مالیات، منهای مبلغی که با کیف پول پرداخت شده. مثال: سفارش ۱٬۰۰۰٬۰۰۰ تومانی با ۴۰۰٬۰۰۰ کیف پول ← مبنا ۶۰۰٬۰۰۰ تومان.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="moaref_mode"><?php esc_html_e( 'پرداخت کمیسیون برای', 'moaref' ); ?></label></th>
						<td>
							<select id="moaref_mode" name="<?php echo $n; ?>[commission_mode]">
								<option value="all" <?php selected( $o['commission_mode'], 'all' ); ?>><?php esc_html_e( 'همه خریدهای کاربر معرفی‌شده', 'moaref' ); ?></option>
								<option value="first" <?php selected( $o['commission_mode'], 'first' ); ?>><?php esc_html_e( 'فقط اولین خرید', 'moaref' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="moaref_min"><?php esc_html_e( 'حداقل مبلغ پرداخت‌شده (تومان)', 'moaref' ); ?></label></th>
						<td>
							<input id="moaref_min" type="text" inputmode="decimal" dir="ltr" min="0" step="1" name="<?php echo $n; ?>[min_order]" value="<?php echo esc_attr( $o['min_order'] ); ?>" />
							<p class="description"><?php esc_html_e( '«مبلغ پرداخت‌شده» سفارش (بعد از تخفیف و کسر کیف پول، بدون ارسال و مالیات) باید حداقل این عدد باشد تا کمیسیون پرداخت شود؛ با جمع کل فاکتور مقایسه نمی‌شود. ۰ = بدون حداقل.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'مهلت روزی کمیسیون', 'moaref' ); ?></th>
						<td>
							<label>
								<input id="moaref_comm_expiry" type="checkbox" value="1" name="<?php echo $n; ?>[comm_expiry]" <?php checked( $o['comm_expiry'], 1 ); ?> />
								<?php esc_html_e( 'روشن باشد: بعد از پایان مهلت، کمیسیون پرداخت نمی‌شود.', 'moaref' ); ?>
							</label>
							<table class="widefat striped moaref-days-table" style="max-width:520px;margin-top:8px;">
								<thead><tr><th><?php esc_html_e( 'طرف', 'moaref' ); ?></th><th><?php esc_html_e( 'مهلت از اولین خرید خودش', 'moaref' ); ?></th></tr></thead>
								<tbody>
									<tr>
										<td><label for="moaref_comm_days_referred"><?php esc_html_e( 'معرفی‌شده (خریدار)', 'moaref' ); ?></label></td>
										<td><input id="moaref_comm_days_referred" type="text" inputmode="decimal" dir="ltr" min="0" max="<?php echo (int) self::MAX_WINDOW_DAYS; ?>" step="1" style="width:110px;" name="<?php echo $n; ?>[comm_days_referred]" value="<?php echo esc_attr( $o['comm_days_referred'] ); ?>" /> <?php esc_html_e( 'روز', 'moaref' ); ?></td>
									</tr>
									<tr>
										<td><label for="moaref_comm_days_referrer"><?php esc_html_e( 'معرفی‌کننده (معرف) — اختیاری', 'moaref' ); ?></label></td>
										<td><input id="moaref_comm_days_referrer" type="text" inputmode="decimal" dir="ltr" min="0" max="<?php echo (int) self::MAX_WINDOW_DAYS; ?>" step="1" style="width:110px;" name="<?php echo $n; ?>[comm_days_referrer]" value="<?php echo esc_attr( $o['comm_days_referrer'] ); ?>" /> <?php esc_html_e( 'روز', 'moaref' ); ?></td>
									</tr>
								</tbody>
							</table>
							<p class="description"><?php esc_html_e( 'هر نفر مهلتش را از اولین خرید تکمیل‌شدهٔ خودش بعد از ورود به سیستم معرفی می‌شمارد (معرفی‌شده: بعد از ثبت کد معرف؛ معرفی‌کننده: بعد از اولین معرفی). کمیسیون فقط وقتی پرداخت می‌شود که مهلت هر دو نفر باز باشد. ۰ = بدون محدودیت؛ کسی که هنوز بعد از ورود به سیستم معرفی خریدی نکرده، مهلتش شروع نشده و باز است.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="moaref_level_count"><?php esc_html_e( 'سطح‌بندی معرف', 'moaref' ); ?></label></th>
						<td>
							<select id="moaref_level_count" name="<?php echo $n; ?>[level_count]">
								<?php for ( $i = 0; $i <= self::MAX_LEVELS; $i++ ) : ?>
									<option value="<?php echo (int) $i; ?>" <?php selected( (int) $o['level_count'], $i ); ?>><?php echo esc_html( 0 === $i ? __( 'غیرفعال', 'moaref' ) : sprintf( /* translators: %s: number of steps */ __( '%s مرحله', 'moaref' ), (int) $i ) ); ?></option>
								<?php endfor; ?>
							</select>
							<table class="widefat striped" style="max-width:520px;margin-top:8px;">
								<thead><tr><th><?php esc_html_e( 'مرحله', 'moaref' ); ?></th><th><?php esc_html_e( 'تعداد معرفی (حداقل)', 'moaref' ); ?></th><th><?php esc_html_e( 'درصد اضافه', 'moaref' ); ?></th></tr></thead>
								<tbody>
								<?php foreach ( array_values( (array) $o['levels'] ) as $i => $lv ) : ?>
									<?php if ( $i >= self::MAX_LEVELS ) { break; } ?>
									<tr class="moaref-level-row" data-step="<?php echo (int) $i + 1; ?>">
										<td><?php echo (int) $i + 1; ?></td>
										<td><input type="text" inputmode="decimal" dir="ltr" min="1" step="1" style="width:110px;" name="<?php echo $n; ?>[levels][<?php echo (int) $i; ?>][users]" value="<?php echo esc_attr( $lv['users'] ); ?>" /> <?php esc_html_e( 'نفر', 'moaref' ); ?></td>
										<td>+<input type="text" inputmode="decimal" dir="ltr" min="0" max="100" step="any" style="width:80px;" name="<?php echo $n; ?>[levels][<?php echo (int) $i; ?>][extra]" value="<?php echo esc_attr( $lv['extra'] ); ?>" /> %</td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
							<p class="description"><?php esc_html_e( 'وقتی تعداد معرفی‌های یک کاربر به عدد هر مرحله برسد، درصد آن مرحله به «درصد کمیسیون معرف» اضافه می‌شود (فقط بالاترین مرحله، نه جمع مراحل). مثال: ۱۰٪ + ۲٪ = ۱۲٪.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'لینک دعوت بدون انقضا', 'moaref' ); ?></th>
						<td>
							<label>
								<input id="moaref_unlimited" type="checkbox" value="1" name="<?php echo $n; ?>[cookie_unlimited]" <?php checked( $o['cookie_unlimited'], 1 ); ?> />
								<?php esc_html_e( 'روشن باشد: لینک دعوت هیچ‌وقت منقضی نمی‌شود و «اعتبار لینک دعوت» غیرفعال می‌شود.', 'moaref' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'مرورگر کروم حداکثر ۴۰۰ روز به کوکی عمر می‌دهد؛ در این حالت کوکی با هر بازدید کاربر دوباره تمدید می‌شود.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="moaref_days"><?php esc_html_e( 'اعتبار لینک دعوت (روز)', 'moaref' ); ?></label></th>
						<td>
							<input id="moaref_days" type="text" inputmode="decimal" dir="ltr" min="1" max="<?php echo (int) self::MAX_COOKIE_DAYS; ?>" name="<?php echo $n; ?>[cookie_days]" value="<?php echo esc_attr( $o['cookie_days'] ); ?>" <?php disabled( $o['cookie_unlimited'], 1 ); ?> />
							<?php if ( $o['cookie_unlimited'] ) : ?>
								<input type="hidden" id="moaref_days_keep" name="<?php echo $n; ?>[cookie_days]" value="<?php echo esc_attr( $o['cookie_days'] ); ?>" />
							<?php endif; ?>
						</td>
					</tr>
				</table>
				<p><?php esc_html_e( 'کیف پول فعال:', 'moaref' ); ?> <strong><?php echo esc_html( self::mr_has_terawallet() ? 'TeraWallet' : __( 'کیف پول داخلی (user_meta)', 'moaref' ) ); ?></strong></p>
				<p><?php esc_html_e( 'شورت‌کد پنل کاربر:', 'moaref' ); ?> <code>[moaref_panel]</code></p>
				<?php if ( self::mr_has_terawallet() ) : ?>
					<p class="description"><?php esc_html_e( 'اگر «هدیه ثبت‌نام» یا «Referrals» خود TeraWallet روشن است، خاموشش کنید تا هدیه دو بار پرداخت نشود.', 'moaref' ); ?></p>
				<?php endif; ?>
				<p class="description"><?php printf( /* translators: %s: query parameter name */ esc_html__( 'اگر افزونه کش (LiteSpeed، WP Rocket و ...) دارید، پارامتر %s را از کش مستثنا کنید تا کوکی لینک دعوت ثبت شود.', 'moaref' ), '<code>ref</code>' ); ?></p>
				<?php submit_button(); ?>
			</form>
			<?php self::mr_credit_footer(); ?>
		</div>
		<script>
		(function () {
			var sel = document.getElementById('moaref_level_count');
			if (!sel) { return; }
			var sync = function () {
				document.querySelectorAll('.moaref-level-row').forEach(function (tr) {
					tr.style.opacity = (+tr.getAttribute('data-step') <= +sel.value) ? '1' : '.35';
				});
			};
			sel.addEventListener('change', sync); sync();
		})();
		(function () {
			var cb = document.getElementById('moaref_unlimited'), days = document.getElementById('moaref_days');
			if (!cb || !days) { return; }
			cb.addEventListener('change', function () {
				days.disabled = cb.checked;
				// فیلد غیرفعال ارسال نمی‌شود؛ مقدار قبلی با hidden حفظ می‌شود
				var keep = document.getElementById('moaref_days_keep');
				if (cb.checked && !keep) {
					keep = document.createElement('input');
					keep.type = 'hidden'; keep.id = 'moaref_days_keep'; keep.name = days.name; keep.value = days.value;
					days.parentNode.appendChild(keep);
				} else if (!cb.checked && keep) {
					keep.remove();
				}
			});
		})();
		(function () {
			var cb = document.getElementById('moaref_comm_expiry'), tbl = document.querySelector('.moaref-days-table');
			if (!cb || !tbl) { return; }
			var sync = function () { tbl.style.opacity = cb.checked ? '1' : '.45'; };
			cb.addEventListener('change', sync); sync();
		})();
		</script>
		<?php
	}

	/* -------------------------------------------------------------------------
	 * Admin: cashback page (Users → کش‌بک)
	 * ---------------------------------------------------------------------- */

	public static function mr_cashback_page() {
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			return;
		}
		$o       = wp_parse_args( (array) get_option( self::OPT_CASHBACK, array() ), self::mr_cashback_defaults() );
		$n       = esc_attr( self::OPT_CASHBACK );
		$percent = 'percent' === $o['mode'];
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'کش‌بک خرید', 'moaref' ); ?></h1>
			<?php settings_errors(); ?>
			<p><?php esc_html_e( 'با تکمیل شدن هر سفارش، کش‌بک به کیف پول خریدار واریز می‌شود. با لغو یا استرداد سفارش، کش‌بک برمی‌گردد.', 'moaref' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'moaref_cashback_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th><?php esc_html_e( 'فعال بودن کش‌بک', 'moaref' ); ?></th>
						<td><label><input type="checkbox" value="1" name="<?php echo $n; ?>[enabled]" <?php checked( $o['enabled'], 1 ); ?> /> <?php esc_html_e( 'کش‌بک خرید فعال باشد', 'moaref' ); ?></label></td>
					</tr>
					<tr>
						<th><label for="moaref_cb_mode"><?php esc_html_e( 'نوع کش‌بک', 'moaref' ); ?></label></th>
						<td>
							<select id="moaref_cb_mode" name="<?php echo $n; ?>[mode]">
								<option value="fixed" <?php selected( $o['mode'], 'fixed' ); ?>><?php esc_html_e( 'تومانی (پله‌ای)', 'moaref' ); ?></option>
								<option value="percent" <?php selected( $o['mode'], 'percent' ); ?>><?php esc_html_e( 'درصدی (ثابت، بدون پله)', 'moaref' ); ?></option>
							</select>
							<p class="description"><?php esc_html_e( '«تومانی»: با رسیدن مبلغ پرداخت‌شده به هر پله، مبلغ ثابت همان پله پرداخت می‌شود (فقط بالاترین پله، نه جمع پله‌ها). «درصدی»: یک درصد ثابت از مبلغ پرداخت‌شده، بدون پله.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr class="moaref-cb-percent" <?php echo $percent ? '' : 'style="display:none"'; ?>>
						<th><label for="moaref_cb_percent"><?php esc_html_e( 'درصد کش‌بک', 'moaref' ); ?></label></th>
						<td>
							<input id="moaref_cb_percent" type="text" inputmode="decimal" dir="ltr" min="0" max="100" step="any" style="width:110px;" name="<?php echo $n; ?>[percent]" value="<?php echo esc_attr( $o['percent'] ); ?>" /> %
							<p class="description"><?php esc_html_e( 'مثال: ۵٪ از مبلغ پرداخت‌شدهٔ ۱٬۰۰۰٬۰۰۰ تومان = ۵۰٬۰۰۰ تومان. برای هر خرید همین درصد اعمال می‌شود و پله‌ای وجود ندارد.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr class="moaref-cb-fixed" <?php echo $percent ? 'style="display:none"' : ''; ?>>
						<th><label for="moaref_tier_count"><?php esc_html_e( 'تعداد پله‌ها', 'moaref' ); ?></label></th>
						<td>
							<select id="moaref_tier_count" name="<?php echo $n; ?>[tier_count]">
								<?php for ( $i = 1; $i <= self::MAX_LEVELS; $i++ ) : ?>
									<option value="<?php echo (int) $i; ?>" <?php selected( (int) $o['tier_count'], $i ); ?>><?php echo esc_html( sprintf( /* translators: %s: number of tiers */ __( '%s پله', 'moaref' ), (int) $i ) ); ?></option>
								<?php endfor; ?>
							</select>
						</td>
					</tr>
					<tr class="moaref-cb-fixed" <?php echo $percent ? 'style="display:none"' : ''; ?>>
						<th><?php esc_html_e( 'پله‌ها', 'moaref' ); ?></th>
						<td>
							<table class="widefat striped" style="max-width:560px;">
								<thead><tr><th><?php esc_html_e( 'پله', 'moaref' ); ?></th><th><?php esc_html_e( 'مبلغ پرداخت‌شده از (تومان)', 'moaref' ); ?></th><th><?php esc_html_e( 'کش‌بک (تومان)', 'moaref' ); ?></th></tr></thead>
								<tbody>
								<?php foreach ( array_values( (array) $o['tiers'] ) as $i => $tier ) : ?>
									<?php if ( $i >= self::MAX_LEVELS ) { break; } ?>
									<tr class="moaref-tier-row" data-step="<?php echo (int) $i + 1; ?>">
										<td><?php echo (int) $i + 1; ?></td>
										<td><input type="text" inputmode="numeric" dir="ltr" style="width:150px;" name="<?php echo $n; ?>[tiers][<?php echo (int) $i; ?>][min]" value="<?php echo esc_attr( $tier['min'] ); ?>" /></td>
										<td><input type="text" inputmode="numeric" dir="ltr" style="width:150px;" name="<?php echo $n; ?>[tiers][<?php echo (int) $i; ?>][amount]" value="<?php echo esc_attr( $tier['amount'] ); ?>" /></td>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
							<p class="description"><?php esc_html_e( 'پله‌های خالی (۰) نادیده گرفته می‌شوند.', 'moaref' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'مهلت روزی کش‌بک', 'moaref' ); ?></th>
						<td>
							<label>
								<input id="moaref_cb_expiry" type="checkbox" value="1" name="<?php echo $n; ?>[expiry]" <?php checked( $o['expiry'], 1 ); ?> />
								<?php esc_html_e( 'روشن باشد: بعد از پایان مهلت، کش‌بک پرداخت نمی‌شود.', 'moaref' ); ?>
							</label>
							<table class="widefat striped moaref-days-table" style="max-width:520px;margin-top:8px;">
								<thead><tr><th><?php esc_html_e( 'طرف', 'moaref' ); ?></th><th><?php esc_html_e( 'مهلت از اولین خرید خودش', 'moaref' ); ?></th></tr></thead>
								<tbody>
									<tr>
										<td><label for="moaref_cb_days_referred"><?php esc_html_e( 'معرفی‌شده (کد معرف زده)', 'moaref' ); ?></label></td>
										<td><input id="moaref_cb_days_referred" type="text" inputmode="decimal" dir="ltr" min="0" max="<?php echo (int) self::MAX_WINDOW_DAYS; ?>" step="1" style="width:110px;" name="<?php echo $n; ?>[days_referred]" value="<?php echo esc_attr( $o['days_referred'] ); ?>" /> <?php esc_html_e( 'روز', 'moaref' ); ?></td>
									</tr>
									<tr>
										<td><label for="moaref_cb_days_referrer"><?php esc_html_e( 'معرفی‌کننده (حداقل یک نفر را معرفی کرده)', 'moaref' ); ?></label></td>
										<td><input id="moaref_cb_days_referrer" type="text" inputmode="decimal" dir="ltr" min="0" max="<?php echo (int) self::MAX_WINDOW_DAYS; ?>" step="1" style="width:110px;" name="<?php echo $n; ?>[days_referrer]" value="<?php echo esc_attr( $o['days_referrer'] ); ?>" /> <?php esc_html_e( 'روز', 'moaref' ); ?></td>
									</tr>
								</tbody>
							</table>
							<p class="description"><?php esc_html_e( 'هر نفر مهلتش را از اولین خرید تکمیل‌شدهٔ خودش بعد از ورود به سیستم معرفی می‌شمارد (معرفی‌شده: بعد از ثبت کد معرف؛ معرفی‌کننده: بعد از اولین معرفی). مشتری معمولی که نه کد معرف زده و نه کسی را معرفی کرده مهلت ندارد. کسی که هر دو نقش را دارد تا باز بودن مهلت یکی از آن‌ها کش‌بک می‌گیرد. ۰ = بدون محدودیت.', 'moaref' ); ?></p>
						</td>
					</tr>
				</table>
				<p class="description"><?php esc_html_e( 'مبلغ پرداخت‌شده = جمع محصولات بعد از تخفیف، بدون ارسال و مالیات، منهای مبلغی که با کیف پول پرداخت شده. مثال: سفارش ۱٬۰۰۰٬۰۰۰ تومانی با ۴۰۰٬۰۰۰ کیف پول ← مبنا ۶۰۰٬۰۰۰ تومان.', 'moaref' ); ?></p>
				<?php submit_button(); ?>
			</form>
			<?php self::mr_credit_footer(); ?>
		</div>
		<script>
		(function () {
			var mode = document.getElementById('moaref_cb_mode');
			if (mode) {
				var syncMode = function () {
					var pct = mode.value === 'percent';
					document.querySelectorAll('.moaref-cb-percent').forEach(function (tr) { tr.style.display = pct ? '' : 'none'; });
					document.querySelectorAll('.moaref-cb-fixed').forEach(function (tr) { tr.style.display = pct ? 'none' : ''; });
				};
				mode.addEventListener('change', syncMode); syncMode();
			}
			var sel = document.getElementById('moaref_tier_count');
			if (sel) {
				var syncTiers = function () {
					document.querySelectorAll('.moaref-tier-row').forEach(function (tr) {
						tr.style.opacity = (+tr.getAttribute('data-step') <= +sel.value) ? '1' : '.35';
					});
				};
				sel.addEventListener('change', syncTiers); syncTiers();
			}
			var ex = document.getElementById('moaref_cb_expiry'), tbl = document.querySelector('.moaref-days-table');
			if (ex && tbl) {
				var syncDays = function () { tbl.style.opacity = ex.checked ? '1' : '.45'; };
				ex.addEventListener('change', syncDays); syncDays();
			}
		})();
		</script>
		<?php
	}

	/* -------------------------------------------------------------------------
	 * Admin: wallet page (Users → کیف پول)
	 * ---------------------------------------------------------------------- */

	private static function mr_find_user( $raw ) {
		$raw = self::mr_fa_digits( $raw );
		if ( '' === $raw ) {
			return false;
		}
		if ( ctype_digit( $raw ) ) { // شناسه کاربر؛ اگر پیدا نشد (یا بلندتر از شناسه معمول بود) نام کاربری عددی مثل شماره موبایل
			$by_id = strlen( $raw ) < 9 ? get_userdata( (int) $raw ) : false;
			return $by_id ? $by_id : get_user_by( 'login', $raw );
		}
		if ( is_email( $raw ) ) {
			return get_user_by( 'email', $raw );
		}
		$user = get_user_by( 'login', $raw );
		return $user ? $user : get_user_by( 'slug', sanitize_title( $raw ) );
	}

	private static function mr_wallet_page_url( $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::ADMIN_SLUG ), $args ), admin_url( 'users.php' ) );
	}

	public static function mr_handle_admin_wallet_form() {
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			wp_die( esc_html__( 'دسترسی ندارید.', 'moaref' ), 403 );
		}
		check_admin_referer( 'moaref_wallet_adjust' );
		$token = isset( $_POST['moaref_token'] ) ? sanitize_key( wp_unslash( $_POST['moaref_token'] ) ) : '';
		if ( ! $token || ! self::mr_claim( 'adm_' . $token ) ) {
			wp_safe_redirect( self::mr_wallet_page_url( array( 'user' => isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0, 'moaref_msg' => 'failed' ) ) );
			exit;
		}

		$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		$amount  = isset( $_POST['amount'] ) ? self::mr_sanitize_amount( $_POST['amount'] ) : 0;
		$type    = ( isset( $_POST['type'] ) && 'debit' === $_POST['type'] ) ? 'debit' : 'credit';
		$note    = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '';
		$note    = $note ? $note : ( 'credit' === $type ? __( 'افزایش موجودی توسط مدیر', 'moaref' ) : __( 'کاهش موجودی توسط مدیر', 'moaref' ) );

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			$msg = 'nouser';
		} elseif ( $amount <= 0 ) {
			$msg = 'noamount';
		} else {
			$ok  = 'credit' === $type ? self::mr_credit( $user_id, $amount, $note, get_current_user_id() ) : self::mr_debit( $user_id, $amount, $note, get_current_user_id() );
			$msg = $ok ? 'done' : ( 'debit' === $type ? 'lowbalance' : 'failed' );
		}

		wp_safe_redirect( self::mr_wallet_page_url( array( 'user' => $user_id, 'moaref_msg' => $msg ) ) );
		exit;
	}

	public static function mr_wallet_page() {
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only GET filters.
		$user  = isset( $_GET['user'] ) ? self::mr_find_user( $_GET['user'] ) : false;
		$msg   = isset( $_GET['moaref_msg'] ) ? sanitize_key( wp_unslash( $_GET['moaref_msg'] ) ) : '';
		$query = isset( $_GET['user'] ) ? sanitize_text_field( wp_unslash( $_GET['user'] ) ) : '';
		// phpcs:enable

		$notices = array(
			'done'       => array( 'success', __( 'موجودی کیف پول به‌روزرسانی شد.', 'moaref' ) ),
			'nouser'     => array( 'error', __( 'کاربر پیدا نشد.', 'moaref' ) ),
			'noamount'   => array( 'error', __( 'مبلغ معتبر وارد کنید.', 'moaref' ) ),
			'lowbalance' => array( 'error', __( 'موجودی کاربر برای این برداشت کافی نیست.', 'moaref' ) ),
			'failed'     => array( 'error', __( 'عملیات انجام نشد.', 'moaref' ) ),
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'کیف پول کاربران', 'moaref' ); ?></h1>
			<?php settings_errors(); ?>

			<?php $wo = wp_parse_args( (array) get_option( self::OPT_WALLET, array() ), self::mr_wallet_defaults() ); ?>
			<?php if ( self::mr_checkout_uses_block() ) : ?>
				<div class="notice notice-warning inline"><p><?php printf( /* translators: %s: shortcode */ esc_html__( 'صفحه «تسویه حساب» فروشگاه با بلوک ووکامرس ساخته شده و چک‌باکس کیف پول در آن نمایش داده نمی‌شود. برای فعال شدن، محتوای صفحه را با شورت‌کد %s جایگزین کنید.', 'moaref' ), '<code>[woocommerce_checkout]</code>' ); ?></p></div>
			<?php endif; ?>
			<form method="post" action="options.php" class="card" style="max-width:640px;">
				<h2 style="margin-top:0;"><?php esc_html_e( 'تنظیمات کیف پول', 'moaref' ); ?></h2>
				<?php settings_fields( 'moaref_wallet_group' ); ?>
				<p>
					<label>
						<input type="checkbox" value="1" name="<?php echo esc_attr( self::OPT_WALLET ); ?>[checkout_wallet]" <?php checked( $wo['checkout_wallet'], 1 ); ?> />
						<?php esc_html_e( 'چک‌باکس «استفاده از موجودی کیف پول» در صفحه تسویه حساب نمایش داده شود.', 'moaref' ); ?>
					</label>
				</p>
				<p class="description"><?php esc_html_e( 'پاداش خرید با کیف پول: کش‌بک و کمیسیون معرف روی «مبلغ پرداخت‌شده» حساب می‌شود، یعنی جمع محصولات بعد از تخفیف، بدون ارسال و مالیات، منهای مبلغی که با کیف پول پرداخت شده. مثال: سفارش ۱٬۰۰۰٬۰۰۰ تومانی با ۴۰۰٬۰۰۰ کیف پول ← مبنا ۶۰۰٬۰۰۰ تومان. اگر کل سفارش با کیف پول پرداخت شود، مبنا صفر است و پاداشی ندارد.', 'moaref' ); ?></p>
				<?php submit_button( __( 'ذخیره تنظیمات کیف پول', 'moaref' ), 'primary', 'submit', false ); ?>
			</form>

			<?php if ( isset( $notices[ $msg ] ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( $notices[ $msg ][0] ); ?> is-dismissible"><p><?php echo esc_html( $notices[ $msg ][1] ); ?></p></div>
			<?php endif; ?>

			<form method="get" style="margin:16px 0;">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::ADMIN_SLUG ); ?>" />
				<input type="search" name="user" value="<?php echo esc_attr( $query ); ?>" placeholder="<?php esc_attr_e( 'شناسه، ایمیل یا نام کاربری', 'moaref' ); ?>" style="min-width:280px;" />
				<?php submit_button( __( 'جستجوی کاربر', 'moaref' ), 'secondary', '', false ); ?>
			</form>

			<?php if ( $query && ! $user ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'کاربری با این مشخصات پیدا نشد.', 'moaref' ); ?></p></div>
			<?php endif; ?>

			<?php if ( $user ) : ?>
				<div class="card" style="max-width:640px;">
					<h2 style="margin-top:0;"><?php echo esc_html( $user->display_name ); ?> <small>(<?php echo esc_html( $user->user_login ); ?>)</small></h2>
					<p><?php esc_html_e( 'موجودی فعلی:', 'moaref' ); ?> <strong style="font-size:1.2em;"><?php echo esc_html( self::mr_format_toman( self::mr_get_balance( $user->ID ) ) ); ?></strong></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="moaref_wallet_adjust" />
						<input type="hidden" name="user_id" value="<?php echo esc_attr( $user->ID ); ?>" />
						<?php wp_nonce_field( 'moaref_wallet_adjust' ); ?>
						<input type="hidden" name="moaref_token" value="<?php echo esc_attr( str_replace( '-', '', wp_generate_uuid4() ) ); ?>" />
						<table class="form-table" role="presentation">
							<tr>
								<th><?php esc_html_e( 'نوع عملیات', 'moaref' ); ?></th>
								<td>
									<label><input type="radio" name="type" value="credit" checked /> <?php esc_html_e( 'افزایش موجودی', 'moaref' ); ?></label>
									&nbsp;&nbsp;
									<label><input type="radio" name="type" value="debit" /> <?php esc_html_e( 'کاهش موجودی', 'moaref' ); ?></label>
								</td>
							</tr>
							<tr>
								<th><label for="moaref_amount"><?php esc_html_e( 'مبلغ (تومان)', 'moaref' ); ?></label></th>
								<td><input id="moaref_amount" type="text" inputmode="numeric" name="amount" required dir="ltr" /></td>
							</tr>
							<tr>
								<th><label for="moaref_note"><?php esc_html_e( 'توضیحات', 'moaref' ); ?></label></th>
								<td><input id="moaref_note" type="text" name="note" class="regular-text" maxlength="200" /></td>
							</tr>
						</table>
						<?php submit_button( __( 'ثبت تغییر موجودی', 'moaref' ) ); ?>
					</form>
				</div>

				<?php
				$log = get_user_meta( $user->ID, self::META_LOG, true );
				$log = is_array( $log ) ? array_reverse( $log ) : array();
				?>
				<h2><?php esc_html_e( 'آخرین تراکنش‌ها', 'moaref' ); ?></h2>
				<table class="widefat striped" style="max-width:900px;">
					<thead><tr><th><?php esc_html_e( 'تاریخ', 'moaref' ); ?></th><th><?php esc_html_e( 'مبلغ', 'moaref' ); ?></th><th><?php esc_html_e( 'توضیحات', 'moaref' ); ?></th><th><?php esc_html_e( 'توسط', 'moaref' ); ?></th></tr></thead>
					<tbody>
					<?php if ( ! $log ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'تراکنشی ثبت نشده است.', 'moaref' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( array_slice( $log, 0, 50 ) as $row ) : ?>
						<?php $by = ! empty( $row['by'] ) ? get_userdata( (int) $row['by'] ) : false; ?>
						<tr>
							<td><?php echo esc_html( self::mr_date( 'Y/m/d H:i', (int) $row['time'] ) ); ?></td>
							<td style="color:<?php echo (float) $row['amount'] >= 0 ? '#1e7e34' : '#b32d2e'; ?>;" dir="ltr">
								<?php echo esc_html( ( (float) $row['amount'] >= 0 ? '+' : '−' ) . self::mr_format_toman( abs( (float) $row['amount'] ) ) ); ?>
							</td>
							<td><?php echo esc_html( isset( $row['note'] ) ? $row['note'] : '' ); ?></td>
							<td><?php echo esc_html( $by ? $by->display_name : __( 'سیستم', 'moaref' ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
			<?php self::mr_credit_footer(); ?>
		</div>
		<?php
	}

	/* -------------------------------------------------------------------------
	 * Admin: AJAX quick edit from the users list
	 * ---------------------------------------------------------------------- */

	public static function mr_ajax_wallet_quick() {
		check_ajax_referer( 'moaref_wallet_quick', 'nonce' );
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			wp_send_json_error( array( 'message' => __( 'دسترسی ندارید.', 'moaref' ) ), 403 );
		}
		$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		$amount  = isset( $_POST['amount'] ) ? self::mr_sanitize_amount( $_POST['amount'] ) : 0;
		$type    = ( isset( $_POST['type'] ) && 'debit' === $_POST['type'] ) ? 'debit' : 'credit';

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'کاربر پیدا نشد.', 'moaref' ) ) );
		}
		if ( $amount <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'مبلغ معتبر وارد کنید.', 'moaref' ) ) );
		}

		$note = 'credit' === $type ? __( 'افزایش موجودی توسط مدیر (ویرایش سریع)', 'moaref' ) : __( 'کاهش موجودی توسط مدیر (ویرایش سریع)', 'moaref' );
		$ok   = 'credit' === $type ? self::mr_credit( $user_id, $amount, $note, get_current_user_id() ) : self::mr_debit( $user_id, $amount, $note, get_current_user_id() );
		if ( ! $ok ) {
			wp_send_json_error( array( 'message' => 'debit' === $type ? __( 'موجودی کافی نیست.', 'moaref' ) : __( 'عملیات انجام نشد.', 'moaref' ) ) );
		}
		wp_send_json_success( array( 'balance' => self::mr_format_toman( self::mr_get_balance( $user_id ) ) ) );
	}

	/* -------------------------------------------------------------------------
	 * Admin: users list columns, row actions, profile
	 * ---------------------------------------------------------------------- */

	public static function mr_users_columns( $cols ) {
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			return $cols;
		}
		$cols['moaref_code']     = __( 'کد معرف', 'moaref' );
		$cols['moaref_referrer'] = __( 'معرف', 'moaref' );
		$cols['moaref_count']    = __( 'تعداد معرفی', 'moaref' );
		$cols['moaref_wallet']   = __( 'کیف پول', 'moaref' );
		return $cols;
	}

	public static function mr_users_column_value( $value, $column, $user_id ) {
		if ( 0 !== strpos( (string) $column, 'moaref_' ) ) {
			return $value;
		}
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			return '';
		}
		switch ( $column ) {
			case 'moaref_code':
				return esc_html( self::mr_get_code( $user_id ) );
			case 'moaref_referrer':
				$r = (int) get_user_meta( $user_id, self::META_REFERRER, true );
				$u = $r ? get_userdata( $r ) : false;
				return $u ? '<a href="' . esc_url( get_edit_user_link( $r ) ) . '">' . esc_html( $u->display_name ) . '</a>' : '—';
			case 'moaref_count':
				return esc_html( number_format_i18n( (int) get_user_meta( $user_id, self::META_REF_COUNT, true ) ) );
			case 'moaref_wallet':
				$uid = (int) $user_id;
				return '<strong class="moaref-balance" id="moaref-balance-' . $uid . '">' . esc_html( self::mr_format_toman( self::mr_get_balance( $uid ) ) ) . '</strong>'
					. '<div class="moaref-quick" id="moaref-quick-' . $uid . '" style="display:none;margin-top:6px;">'
					. '<select class="moaref-q-type"><option value="credit">' . esc_html__( '+ افزایش', 'moaref' ) . '</option><option value="debit">' . esc_html__( '− کاهش', 'moaref' ) . '</option></select> '
					. '<input type="text" class="moaref-q-amount" inputmode="numeric" placeholder="' . esc_attr__( 'تومان', 'moaref' ) . '" dir="ltr" style="width:110px;" /> '
					. '<button type="button" class="button button-small button-primary moaref-q-save" data-user="' . $uid . '">' . esc_html__( 'ثبت', 'moaref' ) . '</button> '
					. '<button type="button" class="button button-small moaref-q-cancel" data-user="' . $uid . '">' . esc_html__( 'انصراف', 'moaref' ) . '</button>'
					. '<span class="moaref-q-msg" style="display:block;margin-top:4px;"></span>'
					. '</div>';
		}
		return $value;
	}

	public static function mr_user_row_actions( $actions, $user ) {
		if ( current_user_can( self::mr_admin_cap() ) ) {
			$actions['moaref_wallet_quick'] = '<a href="#" class="moaref-q-open" data-user="' . (int) $user->ID . '">' . esc_html__( 'ویرایش سریع کیف پول', 'moaref' ) . '</a>';
			$actions['moaref_wallet']       = '<a href="' . esc_url( self::mr_wallet_page_url( array( 'user' => (int) $user->ID ) ) ) . '">' . esc_html__( 'تراکنش‌های کیف پول', 'moaref' ) . '</a>';
		}
		return $actions;
	}

	public static function mr_users_list_script() {
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			return;
		}
		?>
		<script>
		(function ($) {
			var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
				nonce   = <?php echo wp_json_encode( wp_create_nonce( 'moaref_wallet_quick' ) ); ?>;

			$(document).on('click', '.moaref-q-open', function (e) {
				e.preventDefault();
				var id = $(this).data('user');
				$('#moaref-quick-' + id).show().find('.moaref-q-amount').val('').trigger('focus');
			});
			$(document).on('click', '.moaref-q-cancel', function () {
				$('#moaref-quick-' + $(this).data('user')).hide().find('.moaref-q-msg').text('');
			});
			$(document).on('keydown', '.moaref-q-amount', function (e) {
				if (e.key === 'Enter') { e.preventDefault(); $(this).siblings('.moaref-q-save').trigger('click'); }
			});
			$(document).on('click', '.moaref-q-save', function () {
				var $btn = $(this), id = $btn.data('user'), $box = $('#moaref-quick-' + id), $msg = $box.find('.moaref-q-msg');
				$btn.prop('disabled', true);
				$msg.css('color', '').text('<?php echo esc_js( __( 'در حال ثبت…', 'moaref' ) ); ?>');
				$.post(ajaxUrl, {
					action: 'moaref_wallet_quick',
					nonce: nonce,
					user_id: id,
					type: $box.find('.moaref-q-type').val(),
					amount: $box.find('.moaref-q-amount').val()
				}).done(function (res) {
					if (res && res.success) {
						$('#moaref-balance-' + id).text(res.data.balance);
						$msg.css('color', '#1e7e34').text('<?php echo esc_js( __( 'ثبت شد ✓', 'moaref' ) ); ?>');
						$box.find('.moaref-q-amount').val('');
					} else {
						$msg.css('color', '#b32d2e').text(res && res.data && res.data.message ? res.data.message : '<?php echo esc_js( __( 'خطا', 'moaref' ) ); ?>');
					}
				}).fail(function () {
					$msg.css('color', '#b32d2e').text('<?php echo esc_js( __( 'خطا در ارتباط با سرور', 'moaref' ) ); ?>');
				}).always(function () {
					$btn.prop('disabled', false);
				});
			});
		})(jQuery);
		</script>
		<?php
	}

	public static function mr_profile_wallet_box( $user ) {
		if ( ! current_user_can( self::mr_admin_cap() ) ) {
			return;
		}
		?>
		<h2><?php esc_html_e( 'کیف پول و کد معرف', 'moaref' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr><th><?php esc_html_e( 'موجودی کیف پول', 'moaref' ); ?></th><td><strong><?php echo esc_html( self::mr_format_toman( self::mr_get_balance( $user->ID ) ) ); ?></strong>
				&nbsp;<a class="button" href="<?php echo esc_url( self::mr_wallet_page_url( array( 'user' => (int) $user->ID ) ) ); ?>"><?php esc_html_e( 'مدیریت کیف پول', 'moaref' ); ?></a></td></tr>
			<tr><th><?php esc_html_e( 'کد معرف', 'moaref' ); ?></th><td><code dir="ltr"><?php echo esc_html( self::mr_get_code( $user->ID ) ); ?></code></td></tr>
		</table>
		<?php
	}
}

endif;
