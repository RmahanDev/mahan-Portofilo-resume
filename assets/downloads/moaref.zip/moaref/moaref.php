<?php
/**
 * Plugin Name:       Moaref – کد معرف و کیف پول
 * Description:       کد معرف اختصاصی برای هر کاربر، هدیه برای کاربر جدید، کمیسیون درصدی خرید برای معرف (با سطح‌بندی)، کش‌بک خرید، مهلت روزی، و کیف پول تومانی با مدیریت از پیشخوان. سازگار با ووکامرس و TeraWallet.
 * Version:           4.1.0
 * Requires at least: 4.9
 * Requires PHP:      7.0
 * Author:            ماهان رضائی
 * Author URI:        https://co.shainika.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       moaref
 * Domain Path:       /languages
 *
 * @package Moaref
 *
 * ساخته شده توسط ماهان رضائی - co.shainika.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MOAREF_VERSION' ) ) {
	return; // افزونه دو بار بارگذاری شده (مثلاً دو پوشه مختلف از همین افزونه)
}

define( 'MOAREF_VERSION', '4.1.0' );
define( 'MOAREF_FILE', __FILE__ );
define( 'MOAREF_DIR', plugin_dir_path( __FILE__ ) );

/*
 * اگر نسخه «اسنیپت» همین سیستم (Code Snippets) هنوز فعال باشد، کلاس قبلاً تعریف شده است.
 * در این حالت افزونه کاری نمی‌کند تا هوک‌ها دو بار ثبت نشوند و فقط به مدیر هشدار می‌دهد.
 * داده‌ها (تنظیمات، کیف پول، کدهای معرف) بین اسنیپت و افزونه مشترک است و چیزی از دست نمی‌رود.
 */
if ( class_exists( 'Moaref_Referral' ) ) {
	add_action(
		'admin_notices',
		function () {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			echo '<div class="notice notice-warning"><p><strong>Moaref:</strong> نسخه اسنیپت «سیستم کد معرف و کیف پول» هنوز در افزونه Code Snippets فعال است. آن اسنیپت را غیرفعال کنید تا افزونه جایگزینش شود. (تنظیمات و موجودی کیف پول کاربران حفظ می‌شود.)</p></div>';
		}
	);
	return;
}

require_once MOAREF_DIR . 'includes/class-moaref-referral.php';

add_action( 'plugins_loaded', array( 'Moaref_Referral', 'mr_init' ), 5 );

// ترجمه‌ها (رشته‌ها به فارسی نوشته شده‌اند؛ برای زبان‌های دیگر فایل .mo را در پوشه languages بگذارید)
add_action(
	'init',
	function () {
		load_plugin_textdomain( 'moaref', false, dirname( plugin_basename( MOAREF_FILE ) ) . '/languages' );
	}
);

// سازگاری با ذخیره‌سازی سفارش‌های ووکامرس (HPOS): همه دسترسی‌ها به سفارش از طریق WC_Order انجام می‌شود
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', MOAREF_FILE, true );
		}
	}
);

// لینک «تنظیمات» در صفحه افزونه‌ها
add_filter(
	'plugin_action_links_' . plugin_basename( MOAREF_FILE ),
	function ( $links ) {
		if ( current_user_can( Moaref_Referral::mr_admin_cap() ) ) {
			array_unshift(
				$links,
				'<a href="' . esc_url( admin_url( 'users.php?page=moaref-referral' ) ) . '">تنظیمات</a>',
				'<a href="' . esc_url( admin_url( 'users.php?page=moaref-wallet' ) ) . '">کیف پول</a>'
			);
		}
		return $links;
	}
);
